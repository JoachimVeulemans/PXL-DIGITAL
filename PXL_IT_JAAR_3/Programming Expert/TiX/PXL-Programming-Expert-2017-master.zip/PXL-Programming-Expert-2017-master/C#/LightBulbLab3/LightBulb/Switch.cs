﻿using System;

namespace LightBulb
{
    public class Switch
    {
        public Action Toggle;

        public bool IsOn { get; set; }

        public void Flip()
        {
            IsOn = !IsOn;
            Toggle?.Invoke();
        }
    }
}
