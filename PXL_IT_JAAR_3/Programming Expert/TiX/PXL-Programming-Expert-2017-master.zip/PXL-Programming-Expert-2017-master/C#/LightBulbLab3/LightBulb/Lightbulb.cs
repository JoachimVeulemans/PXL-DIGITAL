﻿namespace LightBulb
{
    public class Lightbulb
    {
        public string Color { get; set; }
        public bool IsOn { get; private set; }

        public Lightbulb(params Switch[] switches)
        {
            // Attach Switch
            foreach (var lightSwitch in switches)
            {
                lightSwitch.Toggle += Toggle;
            }
        }

        private void Toggle()
        {
            IsOn = !IsOn;
        }

        public override string ToString()
        {
            var state = IsOn ? "On" : "Off";
            return $"Lightbulb(Color: {Color}, IsOn: {state})";
        }
    }
}