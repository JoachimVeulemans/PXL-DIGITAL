﻿using System;

namespace Sensor
{
    public class TemperatureUpdateEventArgs : EventArgs
    {
        public double Temperature { get; }

        public TemperatureUpdateEventArgs(double temperature)
        {
            Temperature = temperature;
        }
    }
}