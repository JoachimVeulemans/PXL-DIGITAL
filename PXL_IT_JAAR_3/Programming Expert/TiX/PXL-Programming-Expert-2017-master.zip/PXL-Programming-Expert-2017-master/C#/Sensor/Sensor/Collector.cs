﻿namespace Sensor
{
    public abstract class Collector
    {
        protected Collector(TemperatureSensor sensor)
        {
            sensor.TemperatureUpdate += OnTemperatureUpdate;
        }

        protected abstract void OnTemperatureUpdate(object sender, TemperatureUpdateEventArgs e);
    }
}
