﻿using System;

namespace Sensor
{
    /// <summary>
    /// Collects all readings and prints the maximum value.
    /// </summary>
    public class MaximumTemperatureCollector : Collector
    {
        private double _maximumTemperature = double.MinValue;

        public MaximumTemperatureCollector(TemperatureSensor sensor)
            : base(sensor)
        {
        }

        protected override void OnTemperatureUpdate(object sender, TemperatureUpdateEventArgs e)
        {
            if (e.Temperature <= _maximumTemperature)
                return;

            _maximumTemperature = e.Temperature;

            Console.WriteLine("Maximum Temperature: {0}", _maximumTemperature);
        }
    }
}