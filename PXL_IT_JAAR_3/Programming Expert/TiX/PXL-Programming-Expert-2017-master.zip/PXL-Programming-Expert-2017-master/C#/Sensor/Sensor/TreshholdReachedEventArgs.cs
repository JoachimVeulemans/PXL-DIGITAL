﻿using System;

namespace Sensor
{
    public class TreshholdReachedEventArgs : EventArgs
    {
        public double Treshold { get; }
        public double Temperature { get; }

        public TreshholdReachedEventArgs(double treshold, double temperature)
        {
            Treshold = treshold;
            Temperature = temperature;
        }
    }
}