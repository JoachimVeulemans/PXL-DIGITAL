﻿using System;

namespace Sensor
{
    public static class Program
    {
        private const double TresholdTemperature = 35.0;

        public static void Main(string[] args)
        {
            Console.Title = "Temperature Sensor";

            var sensor = new TemperatureSensor();

            var averageTemperatureCollector = new AverageTemperatureCollector(sensor);
            var minimumTemperatureCollector = new MinimumTemperatureCollector(sensor);
            var maximumTemperatureCollector = new MaximumTemperatureCollector(sensor);
            var tresholdTemperatureCollector = new TresholdTemperatureCollector(sensor, TresholdTemperature);

            tresholdTemperatureCollector.TreshholdReached +=
                (sender, e) => Console.WriteLine("Treshold of {0} reached: {1}", e.Treshold, e.Temperature);

            Console.ReadLine();
        }
    }
}