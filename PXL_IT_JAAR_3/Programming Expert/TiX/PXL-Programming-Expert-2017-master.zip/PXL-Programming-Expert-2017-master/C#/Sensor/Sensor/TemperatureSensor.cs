﻿using System;
using System.Threading;

namespace Sensor
{
    public class TemperatureSensor
    {
        private const double MaximumTemperature = 40.0;
        private const int TimerTimeoutPeriod = 1000;

        public EventHandler<TemperatureUpdateEventArgs> TemperatureUpdate;

        public double Temperature { get; private set; }

        private readonly Random _random;
        private readonly Timer _timer;

        public TemperatureSensor()
        {
            _random = new Random();
            _timer = new Timer(TimerTick, null, 0, TimerTimeoutPeriod);
        }

        private void TimerTick(object state)
        {
            Temperature = _random.NextDouble() * MaximumTemperature;

            TemperatureUpdate?.Invoke(this, new TemperatureUpdateEventArgs(Temperature));
        }

    }
}
