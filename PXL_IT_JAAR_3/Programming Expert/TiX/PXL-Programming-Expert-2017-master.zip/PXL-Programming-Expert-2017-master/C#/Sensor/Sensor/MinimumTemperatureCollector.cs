﻿using System;

namespace Sensor
{
    /// <summary>
    /// Collects all readings and prints the minimum value.
    /// </summary>
    public class MinimumTemperatureCollector : Collector
    {
        private double _minimumTemperature = double.MaxValue;

        public MinimumTemperatureCollector(TemperatureSensor sensor)
            : base(sensor)
        {
        }

        protected override void OnTemperatureUpdate(object sender, TemperatureUpdateEventArgs e)
        {
            if (e.Temperature >= _minimumTemperature)
                return;

            _minimumTemperature = e.Temperature;

            Console.WriteLine("Minimum Temperature: {0}", _minimumTemperature);
        }
    }
}