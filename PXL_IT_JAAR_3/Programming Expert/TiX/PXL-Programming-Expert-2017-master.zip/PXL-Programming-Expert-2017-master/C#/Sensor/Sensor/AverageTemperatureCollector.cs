﻿using System;

namespace Sensor
{
    /// <summary>
    /// Collects all readings and prints a rolling average.
    /// </summary>
    public class AverageTemperatureCollector : Collector
    {
        private double _temperatureSum;
        private int _temperatureCount;

        public AverageTemperatureCollector(TemperatureSensor sensor)
            : base(sensor)
        {
        }

        protected override void OnTemperatureUpdate(object sender, TemperatureUpdateEventArgs e)
        {
            _temperatureSum += e.Temperature;
            _temperatureCount++;

            var average = _temperatureSum / _temperatureCount;

            Console.WriteLine("Temperature Average: {0}", average);
        }
    }
}