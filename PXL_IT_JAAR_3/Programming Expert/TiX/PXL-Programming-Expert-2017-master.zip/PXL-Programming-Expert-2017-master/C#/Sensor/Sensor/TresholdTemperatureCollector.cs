﻿using System;

namespace Sensor
{
    /// <summary>
    /// Collects all readings and raises an event when a certain threshold is reached.
    /// </summary>
    public class TresholdTemperatureCollector : Collector
    {
        public EventHandler<TreshholdReachedEventArgs> TreshholdReached;

        private readonly double _treshold;

        public TresholdTemperatureCollector(TemperatureSensor sensor, double treshold)
            : base(sensor)
        {
            _treshold = treshold;
        }

        protected override void OnTemperatureUpdate(object sender, TemperatureUpdateEventArgs e)
        {
            if (e.Temperature < _treshold)
                return;

            TreshholdReached?.Invoke(this, new TreshholdReachedEventArgs(_treshold, e.Temperature));
        }
    }
}