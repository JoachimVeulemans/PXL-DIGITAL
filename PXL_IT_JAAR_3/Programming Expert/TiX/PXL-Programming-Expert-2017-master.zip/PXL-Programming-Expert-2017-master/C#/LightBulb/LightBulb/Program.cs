﻿using System;

namespace LightBulb
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            var switch1 = new Switch();
            var switch2 = new Switch();

            var lightBulb1 = LightBulbFactory.Create(switch1, switch2);
            var lightBulb2 = LightBulbFactory.Create(switch1);

            Console.WriteLine(lightBulb1);
            Console.WriteLine(lightBulb2);

            switch1.Flip();
            Console.WriteLine();
            Console.WriteLine(lightBulb1);
            Console.WriteLine(lightBulb2);

            switch2.Flip();
            Console.WriteLine();
            Console.WriteLine(lightBulb1);
            Console.WriteLine(lightBulb2);

            switch1.Flip();
            Console.WriteLine();
            Console.WriteLine(lightBulb1);
            Console.WriteLine(lightBulb2);

            switch1.Flip();
            Console.WriteLine();
            Console.WriteLine(lightBulb1);
            Console.WriteLine(lightBulb2);


            Console.ReadKey();
        }
    }
}
