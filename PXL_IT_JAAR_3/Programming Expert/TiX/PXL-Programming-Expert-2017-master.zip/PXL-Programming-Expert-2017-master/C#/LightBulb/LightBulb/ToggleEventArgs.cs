﻿using System;

namespace LightBulb
{
    public class ToggleEventArgs : EventArgs
    {
        public bool IsOn { get; }

        public ToggleEventArgs(bool isOn)
        {
            IsOn = isOn;
        }
    }
}
