﻿namespace LightBulb
{
    public class Lightbulb
    {
        public string Color { get; set; }
        public bool IsOn { get; private set; }

        public Lightbulb(params Switch[] switches)
        {
            // Attach Switch
            foreach (var lightSwitch in switches)
            {
                lightSwitch.Toggle += OnToggled;
            }
        }

        private void OnToggled(object sender, ToggleEventArgs args)
        {
            IsOn = !IsOn;
        }

        public override string ToString()
        {
            var state = IsOn ? "On" : "Off";
            return $"Lightbulb(Color: {Color}, IsOn: {state})";
        }
    }
}