﻿using System;

namespace LightBulb
{
    public static class LightBulbFactory
    {
        private static readonly Random Rng = new Random(Environment.TickCount);
        private static readonly string[] ColorsList = { "Red", "Purple", "Orange", "Yellow", "Green", "Blue", "Pink", "Cyan", "White" };

        public static Lightbulb Create(params Switch[] switches)
        {
            // Pick a random color.
            var randomChoice = Rng.Next(ColorsList.Length);

            return new Lightbulb(switches)
            {
                Color = ColorsList[randomChoice]
            };
        }
    }
}
