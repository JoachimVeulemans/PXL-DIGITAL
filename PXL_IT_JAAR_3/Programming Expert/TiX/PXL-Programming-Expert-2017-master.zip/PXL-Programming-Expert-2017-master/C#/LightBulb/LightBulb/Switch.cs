﻿using System;

namespace LightBulb
{
    public class Switch
    {
        public EventHandler<ToggleEventArgs> Toggle;

        public bool IsOn { get; set; }

        public void Flip()
        {
            IsOn = !IsOn;
            Toggle?.Invoke(this, new ToggleEventArgs(IsOn));
        }
    }
}
