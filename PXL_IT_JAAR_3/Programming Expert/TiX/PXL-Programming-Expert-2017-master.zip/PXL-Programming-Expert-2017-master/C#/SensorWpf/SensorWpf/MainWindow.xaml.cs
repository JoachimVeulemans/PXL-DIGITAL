﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SensorWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const int MinimumTemperature = -20;
        private const int MaximumTemperature = 40 + 1;

        public static readonly Mediator Mediator = new Mediator();

        private readonly Random _random = new Random();
        private BackgroundWorker _backgroundWorker;

        public MainWindow()
        {
            InitializeComponent();

            _backgroundWorker = new BackgroundWorker
            {
                WorkerSupportsCancellation = true,
                WorkerReportsProgress = true
            };

            _backgroundWorker.DoWork += (s, e) =>
            {
                var worker = (BackgroundWorker) s;
                while (true)
                {
                    if (worker.CancellationPending)
                    {
                        e.Cancel = true;
                        break;
                    }

                    var temperature = _random.Next(MinimumTemperature, MaximumTemperature);

                    worker.ReportProgress(0, temperature);

                    Thread.Sleep(1000);
                }
            };

            _backgroundWorker.ProgressChanged += (s, e) =>
            {
                var temperature = (int) e.UserState;

                Mediator.OnTemperatureChanged(_backgroundWorker, temperature);
            };

            _backgroundWorker.RunWorkerAsync();
        }
    }
}