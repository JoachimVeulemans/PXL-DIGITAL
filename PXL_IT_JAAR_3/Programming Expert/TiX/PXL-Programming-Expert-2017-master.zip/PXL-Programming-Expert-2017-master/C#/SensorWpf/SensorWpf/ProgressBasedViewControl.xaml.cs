﻿using System.Windows.Controls;

namespace SensorWpf
{
    /// <summary>
    /// Interaction logic for ProgressBasedView.xaml
    /// </summary>
    public partial class ProgressBasedViewControl : UserControl
    {
        public ProgressBasedViewControl()
        {
            InitializeComponent();

            MainWindow.Mediator.TemperatureChanged += (s, e) => { progressTemperature.Value = e.Temperature; };
        }
    }
}