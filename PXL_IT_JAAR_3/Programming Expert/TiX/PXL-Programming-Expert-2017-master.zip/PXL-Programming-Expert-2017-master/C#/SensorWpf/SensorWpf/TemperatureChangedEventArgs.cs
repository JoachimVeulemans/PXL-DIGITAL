﻿using System;

namespace SensorWpf
{
    public class TemperatureChangedEventArgs : EventArgs
    {
        public int Temperature { get; set; }
    }
}
