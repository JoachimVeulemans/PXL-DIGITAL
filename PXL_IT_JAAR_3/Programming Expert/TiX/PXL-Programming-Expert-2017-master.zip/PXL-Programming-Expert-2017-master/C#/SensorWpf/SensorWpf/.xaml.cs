﻿using System.Windows.Controls;
using System.Windows.Media;

namespace SensorWpf
{
    /// <summary>
    /// Interaction logic for TextbasedViewControl.xaml
    /// </summary>
    public partial class TextbasedViewControl : UserControl
    {
        public TextbasedViewControl()
        {
            InitializeComponent();

            MainWindow.Mediator.TemperatureChanged += (s, e) =>
            {
                temperatureText.Content = $"{e.Temperature} °C";
                
                if (e.Temperature < 10)
                {
                    Background = Brushes.DodgerBlue;
                }
                else if (e.Temperature <= 25)
                {
                    Background = Brushes.Orange;
                }
                else
                {
                    Background = Brushes.Red;
                }
            };
        }
    }
}
