﻿using System;

namespace SensorWpf
{
    public class Mediator
    {
        public EventHandler<TemperatureChangedEventArgs> TemperatureChanged;

        public void OnTemperatureChanged(object sender, int temperature)
        {
            TemperatureChanged?.Invoke(sender, new TemperatureChangedEventArgs
            {
                Temperature = temperature,
            });
        }
    }
}
