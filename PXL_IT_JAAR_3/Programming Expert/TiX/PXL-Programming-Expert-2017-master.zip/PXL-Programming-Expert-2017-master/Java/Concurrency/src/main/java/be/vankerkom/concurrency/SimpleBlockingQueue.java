package be.vankerkom.concurrency;

import java.util.LinkedList;
import java.util.List;

public class SimpleBlockingQueue<T> {

    private final List<T> queue = new LinkedList<T>();

    public void put(T element) {
        synchronized (queue) {
            queue.add(element);
            queue.notify();
        }
    }

    public T get() throws InterruptedException {
        while (true) {
            synchronized (queue) {
                if (queue.isEmpty()) {
                    queue.wait();
                }else{
                    return queue.remove(0);
                }
            }
        }
    }

}
