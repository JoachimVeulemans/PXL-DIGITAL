package be.vankerkom.concurrency;

public class ConsumerThread extends Thread {

    private SimpleBlockingQueue queue;
    private boolean wasInterrupted;
    private boolean reachedAfterGet;

    public ConsumerThread(SimpleBlockingQueue queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            queue.get();
            reachedAfterGet = true;
        } catch (InterruptedException e) {
            wasInterrupted = true;
        }
    }

    public boolean wasInterrupted() {
        return wasInterrupted;
    }

    public boolean reachedAfterGet() {
        return reachedAfterGet;
    }
    
}
