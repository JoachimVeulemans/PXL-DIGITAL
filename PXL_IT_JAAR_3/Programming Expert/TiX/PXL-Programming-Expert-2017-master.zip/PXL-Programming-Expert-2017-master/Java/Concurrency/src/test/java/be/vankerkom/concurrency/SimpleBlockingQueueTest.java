package be.vankerkom.concurrency;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class SimpleBlockingQueueTest {

    @org.junit.Test
    public void testPutOnEmptyQueueBlocks() throws Exception {
        // Arrange
        SimpleBlockingQueue queue = new SimpleBlockingQueue();
        ConsumerThread consumerThread = new ConsumerThread(queue);

        // Act
        consumerThread.start();

        // Assert
        assertFalse(consumerThread.reachedAfterGet());
        assertFalse(consumerThread.wasInterrupted());

        // Act
        queue.put(5);

        // Assert
        consumerThread.join();

        assertTrue(consumerThread.reachedAfterGet());
        assertFalse(consumerThread.wasInterrupted());
    }

}