package be.pxl.cafe.cups;

import be.pxl.cafe.ICupCoffee;

public class Cappucino implements ICupCoffee {

}
