package be.pxl.cafe.cups;

import be.pxl.cafe.ICupCoffee;
import be.pxl.cafe.IOerecht;

public class Regular implements ICupCoffee, IOerecht {

    @Override
    public void mix() {
        IOerecht.super.mix();
    }
}
