package be.pxl.cafe.cups;

import be.pxl.cafe.ICupCoffee;

public class Late implements ICupCoffee {

}
