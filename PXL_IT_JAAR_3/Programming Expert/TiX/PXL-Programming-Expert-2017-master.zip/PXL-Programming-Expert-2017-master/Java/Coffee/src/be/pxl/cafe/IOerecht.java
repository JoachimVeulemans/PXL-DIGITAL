package be.pxl.cafe;

public interface IOerecht {
    default void mix() {
        System.out.println("Oerecht: Mix");
    }
}
