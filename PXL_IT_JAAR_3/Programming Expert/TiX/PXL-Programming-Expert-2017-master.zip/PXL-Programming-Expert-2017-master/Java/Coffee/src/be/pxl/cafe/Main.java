package be.pxl.cafe;

import be.pxl.cafe.cups.Cappucino;
import be.pxl.cafe.cups.Late;
import be.pxl.cafe.cups.Regular;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<ICupCoffee> coffeeList = new ArrayList<>();

        coffeeList.add(new Cappucino());
        coffeeList.add(new Late());
        coffeeList.add(new Regular());

        coffeeList.forEach(cup -> {
            cup.mix();
            cup.brew();
        });
    }
}
