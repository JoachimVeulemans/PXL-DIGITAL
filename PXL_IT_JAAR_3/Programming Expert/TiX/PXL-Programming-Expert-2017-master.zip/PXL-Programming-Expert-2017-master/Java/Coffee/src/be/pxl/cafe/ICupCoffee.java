package be.pxl.cafe;

public interface ICupCoffee {
    default void brew() {
        System.out.println("Brew: " + getClass().getSimpleName());
    }
    default void mix() {
        System.out.println("Mix: " + getClass().getSimpleName());
    }
}
