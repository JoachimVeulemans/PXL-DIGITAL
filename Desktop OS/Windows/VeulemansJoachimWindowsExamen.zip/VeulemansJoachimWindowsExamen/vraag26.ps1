﻿$folderpath = $args[0]
$folderName = $args[1]

Set-Content .\mijnOplossingen\examenOplossingen.txt (Get-ChildItem .\mijnOplossingen)

Compress-Archive -Path .\$folderpath\*.* -CompressionLevel Fastest -DestinationPath $folderName