public class Main {
    public static void main(String[] args) {
        try {
            long seconds = System.currentTimeMillis();
            DanceGroup danceGroup = new DanceGroup();

            System.out.print("De beginvolgorde van de dans is ");
            PrintOrder(danceGroup);

            DanceService.ExecuteDances(danceGroup, "dance.txt");

            System.out.print("De eindvolgorde van de dans is ");
            PrintOrder(danceGroup);
            System.out.println(System.currentTimeMillis() - seconds);

        } catch (DanceGroup.DancerDoesNotExistException ddne) {
            System.out.println("Er wordt een dancer aangeroepen die niet bestaat!");
        } catch (DanceService.TypeOfMoveDoesNotExistException tomdne) {
            System.out.println("Er wordt een beweging aangeroepen die niet bestaat!");
        }
    }

    private static void PrintOrder(DanceGroup danceGroup) {
        danceGroup.getDancers().forEach((integer, s) -> System.out.print(s));
        System.out.println();
    }
}
