import java.util.HashMap;
import java.util.Map;

public class DanceGroup {
    private HashMap<Integer, String> dancers = new HashMap<>();
    private static final Integer NUMBER_OF_DANCERS = 16;

    public DanceGroup() {
        for (int dancer = 0; dancer < NUMBER_OF_DANCERS; dancer++) {
            dancers.put(dancer, Character.toString((char)(dancer + 97)));
        }
    }

    public HashMap<Integer, String> getDancers() {
        return dancers;
    }

    public void Spin(Integer numberofDancers) {
        HashMap<Integer, String> newDancersList = new HashMap<>();

        for (int i = 0; i < dancers.size() - numberofDancers; i++) {
            newDancersList.put(i + numberofDancers, dancers.get(i));
        }

        for (int i = 0; i < numberofDancers; i++) {
            newDancersList.put(i, dancers.get(dancers.size() - numberofDancers + i));
        }

        dancers = newDancersList;
    }

    public void Exchange(Integer dancer1Position, Integer dancer2Position) throws DancerDoesNotExistException {
        CheckIfDancerExists(dancer1Position);
        CheckIfDancerExists(dancer2Position);

        String tempNameOfDancer = dancers.get(dancer1Position);
        dancers.replace(dancer1Position, dancers.get(dancer1Position), dancers.get(dancer2Position));
        dancers.replace(dancer2Position, dancers.get(dancer2Position), tempNameOfDancer);
    }

    private void CheckIfDancerExists(Integer dancer1Position) throws DancerDoesNotExistException {
        if (!dancers.containsKey(dancer1Position)) {
            throw new DancerDoesNotExistException();
        }
    }

    public void Partner(Character nameOfDancer1, Character nameOfDancer2) throws DancerDoesNotExistException {
        Exchange(getPositionOfDancer(nameOfDancer1.toString()), getPositionOfDancer(nameOfDancer2.toString()));
    }

    private Integer getPositionOfDancer(String nameOfDancer) throws DancerDoesNotExistException {
        for (Map.Entry<Integer, String> dancer : dancers.entrySet()) {
            if (dancer.getValue().equals(nameOfDancer)) {
                return dancer.getKey();
            }
        }
        throw new DancerDoesNotExistException();
    }

    public class DancerDoesNotExistException extends Throwable {
        public DancerDoesNotExistException() {
        }
    }
}
