import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DanceService {
    public static DanceGroup ExecuteDances(DanceGroup danceGroup, String file) throws TypeOfMoveDoesNotExistException, DanceGroup.DancerDoesNotExistException {

        List<String> dances = GetListOfDances(file);
        for (String move : dances) {
            ExecuteMove(move, danceGroup);
        }

        return danceGroup;
    }

    private static List<String> GetListOfDances(String file) {
        List<String> moves = new ArrayList<>();
        Path path = Paths.get(System.getProperty("user.dir"));
        Path filePath = path.resolve(file);

        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line = reader.readLine();
            moves.addAll(Arrays.asList(line.split(",")));
        } catch (IOException e) {
            System.out.println("Er heeft zich een fout bij het inlezen van het bestand voorgedaan.");
        }

        return moves;
    }

    private static void ExecuteMove(String move, DanceGroup danceGroup) throws TypeOfMoveDoesNotExistException, DanceGroup.DancerDoesNotExistException {
        switch (move.charAt(0)) {
            case 's':
                danceGroup.Spin(Integer.parseInt(move.substring(1)));
                break;
            case 'x':
                danceGroup.Exchange(Integer.parseInt(move.substring(1).split("/")[0]), Integer.parseInt(move.split("/")[1]));
                break;
            case 'p':
                danceGroup.Partner(move.charAt(1), move.charAt(3));
                break;
            default:
                throw new TypeOfMoveDoesNotExistException();
        }
    }

    public static class TypeOfMoveDoesNotExistException extends Throwable {
        public TypeOfMoveDoesNotExistException() {
        }
    }
}
