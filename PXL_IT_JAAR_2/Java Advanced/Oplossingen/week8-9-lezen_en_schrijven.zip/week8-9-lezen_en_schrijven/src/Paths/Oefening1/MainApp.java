package Paths.Oefening1;

import java.nio.file.Path;
import java.nio.file.Paths;

public class MainApp {
    public static void main(String[] args) {
        Path userHomePath = Paths.get(System.getProperty("user.home"));
        Path fase2Path = userHomePath.resolve("Opdrachten/Opdracht1/Fase2");
        System.out.println(fase2Path.toString());
    }
}
