package Paths.Oefening2;

import java.nio.file.Path;
import java.nio.file.Paths;

public class MainApp {
    public static void main(String[] args) {
        Path userHomePath = Paths.get(System.getProperty("user.home"));
        Path fase2Path = userHomePath.resolve("Opdrachten/Opdracht1/Fase2");
        System.out.println(fase2Path.toString());
        System.out.println(fase2Path.getFileName());
        System.out.println(fase2Path.getName(0));
        System.out.println(fase2Path.getNameCount());
        System.out.println(fase2Path.subpath(0, 2));
        System.out.println(fase2Path.getParent());
        System.out.println(fase2Path.getRoot());
    }
}
