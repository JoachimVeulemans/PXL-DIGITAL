package OefeningLargeFiles;

import java.nio.file.Path;
import java.nio.file.Paths;

public class MainApp {
    public static void main(String[] args) {
        Path userHomePath = Paths.get(System.getProperty("user.home"));
        Path root = userHomePath.getRoot();




    }
}
