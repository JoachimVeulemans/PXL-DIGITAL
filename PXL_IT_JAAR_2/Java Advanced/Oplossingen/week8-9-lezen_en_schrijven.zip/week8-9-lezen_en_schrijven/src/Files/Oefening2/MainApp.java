package Files.Oefening2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class MainApp {
    public static void main(String[] args) {

        Path homeFolder = Paths.get(System.getProperty("user.home"));
        Path filename = Paths.get("bijlage1.txt");
        Path outputfilename = Paths.get("output.txt");

        Path filePath = homeFolder.resolve(filename);
        Path outputFilePath = homeFolder.resolve(outputfilename);

        File file = new File(Paths.get(System.getProperty("user.home")) + "\bijlage1.txt");
        System.out.println(file);


        try {
            List<String> fruitsString = Files.readAllLines(filePath);

            Set<String> fruits = new TreeSet<>(fruitsString);
            fruits.forEach(System.out::println);

            //FileInputStream fileInputStream = new FileInputStream(file);
            for (int i = 0; i < fruits.size(); i++) {
                // int occurrences = Collections.frequency(fruits, fruits.);
            }

            Files.write(outputFilePath, fruits);


        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }
}
