package Files.Oefening1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class MainApp {
    public static void main(String[] args) {

        Path homeFolder = Paths.get(System.getProperty("user.home"));
        Path filename = Paths.get("bijlage1.txt");
        Path outputfilename = Paths.get("output.txt");

        Path filePath = homeFolder.resolve(filename);
        Path outputFilePath = homeFolder.resolve(outputfilename);


        try {
            List<String> fruitsString = Files.readAllLines(filePath);
            Map<String, Integer> fruitCount = new HashMap<>();

            Set<String> fruits = new TreeSet<>(fruitsString);
            fruits.forEach(System.out::println);

            Files.write(outputFilePath, fruits);

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }
}
