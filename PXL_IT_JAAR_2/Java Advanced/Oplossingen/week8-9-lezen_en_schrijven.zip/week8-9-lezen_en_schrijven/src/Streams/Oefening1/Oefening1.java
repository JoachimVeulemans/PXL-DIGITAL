package Streams.Oefening1;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidParameterException;
import java.util.*;

public class Oefening1 {
    public static void main(String[] args) {
        //TODO IN JDK

        Path filePath = null;
        Map<String, String> phoneNumber = new TreeMap<>();

        if (args.length == 2) {
            filePath = Paths.get(args[0]).resolve(args[1]);
        } else {
            System.out.println("De meegegeven parameters zijn niet correct");
            throw new InvalidParameterException();
        }

        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
                String[] phoneParts = line.split(";");
                phoneNumber.put(phoneParts[0], "");
                for (int i = 1; i < phoneParts.length; i++) {
                    phoneNumber.put(phoneParts[0], phoneNumber.get(phoneParts[0]).concat(";" + phoneParts[i]));
                }
            }
            System.out.println("Tom zijn nummer: " + phoneNumber.get("Tom"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
