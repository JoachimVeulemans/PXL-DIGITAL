package be.pxl.ja.opgave1;

public enum ActivityTracker {
	ENDOMODO, STRAVA;

}
