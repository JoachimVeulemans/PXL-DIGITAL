package Collections.Opdracht1;

import java.awt.*;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Deque;
import java.util.List;

public class Deck {
    private Deque<Card> deck = new ArrayDeque<>();

    public Deck() {
        generateDeck();
        Collections.shuffle( deck);
    }

    private void generateDeck() {
        for (Color color: Color.values()) {
            for (Value value: Value.values()) {
                deck.add(new Card(color, value));
            }
        }
    }

    public int getDeckSize() {
        return deck.size();
    }

    public Card dealCard() {
        return deck.pollFirst();
    }

    public String showDeck() {
        return deck.stream()
                .map(Card::toString)
                .reduce("", (a, b) -> a + b);
    }
}
