package Collections.Opdracht1;

public enum Color {
	HEART,
	DIAMOND,
	CLUB,
	SPADE;
}
