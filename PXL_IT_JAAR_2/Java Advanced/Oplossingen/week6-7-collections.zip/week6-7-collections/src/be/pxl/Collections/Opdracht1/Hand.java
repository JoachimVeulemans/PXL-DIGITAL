package Collections.Opdracht1;

import java.util.HashSet;

public class Hand {
    HashSet<Card> deck = new HashSet<>();

    public void addCard(Card card) {
        deck.add(card);
    }

    public String showHand() {
        return deck.stream()
                .map(Card::toString)
                .reduce("", (a, b) -> a + b);
    }

    public boolean hasColor(Color color) {
        return deck.stream()
                .anyMatch(card -> card.getColor() == color);
    }
}
