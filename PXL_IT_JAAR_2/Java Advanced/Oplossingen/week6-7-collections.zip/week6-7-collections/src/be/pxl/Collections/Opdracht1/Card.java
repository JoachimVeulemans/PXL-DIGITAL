package Collections.Opdracht1;

public class Card {
    private Color color;
    private Value value;

    public Card(Color color, Value value) {
        this.color = color;
        this.value = value;
    }

    @Override
    public String toString() {
        return color + "_" + value;
    }

    public Color getColor() {
        return color;
    }

    public Value getValue() {
        return value;
    }
}
