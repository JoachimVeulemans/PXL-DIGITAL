package be.pxl.generics.opdracht2;

public abstract class Player {
	private String name;
	
	public Player(String name) {
		setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
