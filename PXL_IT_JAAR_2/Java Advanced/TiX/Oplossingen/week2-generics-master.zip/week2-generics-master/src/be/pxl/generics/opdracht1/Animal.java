package be.pxl.generics.opdracht1;

public abstract class Animal {
	
	public Animal() {
		
	}
	
	
}
