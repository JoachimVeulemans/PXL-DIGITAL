package be.pxl.generics.opdracht1;

public class Bunny extends Animal {

	public Bunny() {
		// TODO Auto-generated constructor stub
	}

}
