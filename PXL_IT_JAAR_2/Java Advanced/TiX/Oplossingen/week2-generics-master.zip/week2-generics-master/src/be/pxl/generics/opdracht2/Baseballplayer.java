package be.pxl.generics.opdracht2;

public class Baseballplayer extends Player {

	public Baseballplayer(String name) {
		super(name);
	}

}
