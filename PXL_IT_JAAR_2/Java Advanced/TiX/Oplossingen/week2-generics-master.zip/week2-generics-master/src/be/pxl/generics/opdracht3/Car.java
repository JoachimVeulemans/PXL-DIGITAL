package be.pxl.generics.opdracht3;

public class Car extends Vehicle implements Motorized {

}
