package be.pxl.generics.opdracht2;

public class VolleybalPlayer extends Player {

	public VolleybalPlayer(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
