package be.pxl.generics.opdracht3;

public abstract class Vehicle {

}
