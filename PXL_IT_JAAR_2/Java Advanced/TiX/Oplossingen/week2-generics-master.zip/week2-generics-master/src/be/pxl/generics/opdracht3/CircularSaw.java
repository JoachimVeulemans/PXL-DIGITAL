package be.pxl.generics.opdracht3;

public class CircularSaw implements Motorized {

}
