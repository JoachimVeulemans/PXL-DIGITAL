package be.pxl.generics.opdracht1;

public class Dove extends Animal {

	public Dove() {
		// TODO Auto-generated constructor stub
	}

}
