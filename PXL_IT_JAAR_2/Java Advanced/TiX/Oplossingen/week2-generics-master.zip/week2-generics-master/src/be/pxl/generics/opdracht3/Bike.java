package be.pxl.generics.opdracht3;

public class Bike extends Vehicle {

}
