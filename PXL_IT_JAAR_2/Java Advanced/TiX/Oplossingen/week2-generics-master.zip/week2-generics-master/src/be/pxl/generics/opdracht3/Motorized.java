package be.pxl.generics.opdracht3;

public interface Motorized {

}
