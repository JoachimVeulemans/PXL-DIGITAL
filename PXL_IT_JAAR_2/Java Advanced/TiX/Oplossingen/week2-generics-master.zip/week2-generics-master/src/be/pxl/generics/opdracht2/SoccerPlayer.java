package be.pxl.generics.opdracht2;

public class SoccerPlayer extends Player {

	public SoccerPlayer(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
