package be.pxl.computerstore.util;

public class TooManyPeripheralsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
