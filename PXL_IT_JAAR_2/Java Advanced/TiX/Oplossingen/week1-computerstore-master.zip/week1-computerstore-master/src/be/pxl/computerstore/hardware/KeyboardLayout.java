package be.pxl.computerstore.hardware;

public enum KeyboardLayout {
	QWERTY, AZERTY;
}
