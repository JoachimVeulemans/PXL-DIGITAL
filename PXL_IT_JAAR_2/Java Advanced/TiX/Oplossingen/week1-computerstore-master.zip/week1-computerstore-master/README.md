# week1-computerstore
Skeleton for the computer store project (week 1)
