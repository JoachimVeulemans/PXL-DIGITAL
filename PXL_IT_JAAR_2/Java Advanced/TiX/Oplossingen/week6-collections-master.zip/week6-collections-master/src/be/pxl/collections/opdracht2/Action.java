package be.pxl.collections.opdracht2;

public enum Action {
	MOVE,
	TURN,
	ATTACK,
	TALK,
	NONE
}
