package be.pxl.week3.opdracht2;

public interface DangerousMonster extends Monster {
	public void destroy(Monster monster);
}
