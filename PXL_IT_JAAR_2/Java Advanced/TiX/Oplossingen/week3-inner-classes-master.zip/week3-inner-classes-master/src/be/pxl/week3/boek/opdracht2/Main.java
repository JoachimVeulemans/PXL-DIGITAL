package be.pxl.week3.boek.opdracht2;

public class Main {
	public static void main(String[] args) {
		new Musician().play();
		//new Musician().new Instrument().makeNoise();
	}

}
