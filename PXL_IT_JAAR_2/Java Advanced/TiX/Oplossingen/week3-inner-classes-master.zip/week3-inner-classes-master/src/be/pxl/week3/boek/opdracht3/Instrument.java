package be.pxl.week3.boek.opdracht3;

public interface Instrument {
	public void makeNoise();
}
