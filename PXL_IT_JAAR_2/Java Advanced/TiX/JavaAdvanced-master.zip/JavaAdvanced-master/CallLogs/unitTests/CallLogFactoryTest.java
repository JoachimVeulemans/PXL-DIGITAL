import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CallLogFactoryTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void readCallLogsFromFile() {
    }

    @Test
    void readCallLogsFromFile1() {
    }

    @Test
    void readCallLogsFromFile2() {
    }
}