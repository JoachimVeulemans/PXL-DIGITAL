import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class QueueServiceTest {
    QueueService sut;

    @BeforeEach
    void setUp() {
        sut = new QueueService();
    }

    @Test
    void addToQueue() {

    }

    @Test
    void getQueue() {

    }

    @Test
    void getNextInLine() {

    }

    @Test
    void removeFromQueue() {

    }

    @Test
    void printQueue() {

    }

    @AfterEach
    void tearDown() {
        sut = null;
    }

}