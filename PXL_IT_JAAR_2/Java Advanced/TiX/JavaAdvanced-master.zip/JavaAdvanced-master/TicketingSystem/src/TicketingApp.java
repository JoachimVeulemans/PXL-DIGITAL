public class TicketingApp {
    public static void main(String[] args) {

    }
}
