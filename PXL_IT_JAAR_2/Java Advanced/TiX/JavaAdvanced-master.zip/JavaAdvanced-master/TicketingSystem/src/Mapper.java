public interface Mapper<T> {
    T map(String[] args);
}
