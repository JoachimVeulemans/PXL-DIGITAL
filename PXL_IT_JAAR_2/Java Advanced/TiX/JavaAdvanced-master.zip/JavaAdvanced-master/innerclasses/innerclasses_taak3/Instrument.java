package innerclasses_taak3;

public interface Instrument {
    void makeNoise();
}
