package innerclasses_taak1;

public class MusicianApp {

    public static void main(String[] args) {
        new Musician().new Instrument().makeNoise();
    }
}
