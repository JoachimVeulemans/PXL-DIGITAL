package innerclasses_taak1;

public class Musician {
    void play() {
        Instrument instrument = new Instrument();
        instrument.makeNoise();
    }

    public class Instrument {
        public void makeNoise() {
            System.out.println("jhghfkdfgid");
        }
    }
}
