package lambda_opdracht1;

/*
  Schrijf de functionele interface NumberFilter met als enige methode boolean check(int number).
*/
public interface NumberFilter {
    boolean check(Integer number);
}
