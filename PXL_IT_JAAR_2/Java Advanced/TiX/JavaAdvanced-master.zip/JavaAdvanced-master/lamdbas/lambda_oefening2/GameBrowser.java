package lambda_oefening2;

public class GameBrowser {
}
