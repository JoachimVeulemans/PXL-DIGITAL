package lambda_oefening1;

@FunctionalInterface
public interface DisplayOnly {
    void print(User user);
}
