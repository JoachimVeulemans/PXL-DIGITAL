package collections_opdracht2;

public enum Action {
    SHITPOST,
    JERK,
    GAME,
    CODE,
    CRASH,
    BURN,
    EAT,
    WATCHDANKMEMES
}
