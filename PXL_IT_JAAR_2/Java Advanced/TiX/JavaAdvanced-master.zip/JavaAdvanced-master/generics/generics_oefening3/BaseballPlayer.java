package generics_oefening3;

public class BaseballPlayer extends Player {
    public BaseballPlayer(String name) {
        super(name);
    }
}
