package generics_oefening3;

public class SoccerPlayer extends Player {
    public SoccerPlayer(String name) {
        super(name);
    }
}
