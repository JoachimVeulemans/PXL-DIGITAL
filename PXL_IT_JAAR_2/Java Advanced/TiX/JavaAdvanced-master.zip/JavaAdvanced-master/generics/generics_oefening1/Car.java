package generics_oefening1;

public class Car extends Vehicle implements Motorized {

}
