package generics_oefening1;

public class CircularSaw implements Motorized {

}
