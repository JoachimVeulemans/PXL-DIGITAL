package generics_oefening1;

public class Bike extends Vehicle {

}
