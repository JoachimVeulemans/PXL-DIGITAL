package generics_oefening1;

public interface Motorized {

}
