package generics_oefening1;

public abstract class Vehicle {

}
