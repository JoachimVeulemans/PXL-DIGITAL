package generics_oefening1.opgave_c;

import generics_oefening1.Car;

public class TestWorkingPlace {
    public static void main(String[] args) {
        WorkingPlace<Car> carWorkingPlace = new WorkingPlace<>();
        //WorkingPlace<Bike> bikeWorkingPlace = new WorkingPlace<>();
        //WorkingPlace<Vehicle> vehicleWorkingPlace = new WorkingPlace<>();
        //WorkingPlace<CircularSaw> otherWorkPlace = new WorkingPlace<>();
        //WorkingPlace<Motorized> motorizedWorkingPlace = new WorkingPlace<>();
    }
}
