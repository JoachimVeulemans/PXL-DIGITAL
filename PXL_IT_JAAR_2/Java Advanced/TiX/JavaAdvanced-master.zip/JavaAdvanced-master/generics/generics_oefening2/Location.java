package generics_oefening2;

public enum Location {
    NEAR_THE_RIVER,
    IN_THE_VILLAGE,
    IN_THE_FOREST
}
