package generics_oefening2;

public class ChessPiece implements Moveable {
    @Override
    public <T> void move(T location) {

    }

    @Override
    public Location getCurrentLocation() {
        return null;
    }
}
