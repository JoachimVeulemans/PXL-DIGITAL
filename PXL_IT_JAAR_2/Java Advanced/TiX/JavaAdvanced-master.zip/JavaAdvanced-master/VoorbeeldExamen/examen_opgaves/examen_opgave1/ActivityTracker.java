package examen_opgave1;

public enum ActivityTracker {
    ENDOMODO, STRAVA

}
