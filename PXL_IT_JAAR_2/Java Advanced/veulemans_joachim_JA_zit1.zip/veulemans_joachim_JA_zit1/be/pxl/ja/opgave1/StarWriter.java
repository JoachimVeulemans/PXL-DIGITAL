package be.pxl.ja.opgave1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class StarWriter extends Thread {

    private List<Star> stars;
    private Path outputFile;

    public StarWriter(Path outputFile, List<Star> stars) {
        this.stars = stars;
        this.outputFile = outputFile;
    }

    @Override
    public void run() {
        if (!outputFile.toFile().exists()) {
            try {
                outputFile.toFile().createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        AtomicInteger minX = new AtomicInteger();
        stars
                .stream()
                .sorted((o1, o2) -> o1.getX() - o2.getX())
                .limit(1)
                .forEach(star -> minX.set(star.getX()));
        AtomicInteger maxX = new AtomicInteger();
        stars
                .stream()
                .sorted((o1, o2) -> o2.getX() - o1.getX())
                .limit(1)
                .forEach(star -> maxX.set(star.getX()));

        AtomicInteger minY = new AtomicInteger();
        stars
                .stream()
                .sorted((o1, o2) -> o1.getY() - o2.getY())
                .limit(1)
                .forEach(star -> minY.set(star.getY()));
        AtomicInteger maxY = new AtomicInteger();
        stars
                .stream()
                .sorted((o1, o2) -> o2.getY() - o1.getY())
                .limit(1)
                .forEach(star -> maxY.set(star.getY()));

        try (BufferedWriter bw = Files.newBufferedWriter(outputFile)) {
            for (int yline = minY.get(); yline <= maxY.get(); yline++) {
                for (int xline = minX.get(); xline <= maxX.get(); xline++) {
                    int finalXline = xline;
                    int finalYline = yline;
                    long starOnPos = stars
                            .stream()
                            .filter(star -> star.getX() == finalXline)
                            .filter(star -> star.getY() == finalYline)
                            .count();
                    if (starOnPos > 0) {
                        bw.write("#");
                    } else {
                        bw.write(".");
                    }
                }
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
