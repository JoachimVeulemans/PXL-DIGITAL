package be.pxl.ja.opgave2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

public class LotteryDrawing {

    public static void main(String[] args) {
        List<LotteryTicket> lotteryTickets = new ArrayList<>();
        Path path = Paths.get(System.getProperty("user.dir")).resolve("resources");
        AtomicReference<LocalDateTime> time = new AtomicReference<>();
        List<Integer> winningNumbers = new ArrayList<>();
        // EACH FILE IN DIR
        try (Stream<Path> filePathStream= Files.walk(path, 1)) {
            filePathStream.forEach(filePath -> {
                if (Files.isRegularFile(filePath)) {
                    fileFound(filePath, time, lotteryTickets, winningNumbers);
                }
            });
        } catch (IOException e) {
            System.out.println("Er ging iets fout in het zoeken naar bestanden!");
        }

        // UITPRINT
        System.out.println("Datum trekking: " + LotteryTicketUtility.getDateTimeFormatter().format(time.get()));
        System.out.println("Winnende nummbers: " + winningNumbers.stream().map(value -> value.toString()).reduce((acc, el) -> acc + "-" + el ).get());
        System.out.println("Aantal verkochte loten: " + lotteryTickets.stream().count());
        System.out.println("Percentage quickpick: " + LotteryTicketUtility.getPercentageQuickPick(lotteryTickets) + "%");
        System.out.println("Winnend lot: " + LotteryTicketUtility.findWinningLotteryTicket(lotteryTickets, winningNumbers));
        System.out.println("Hoogste ticket number: " + LotteryTicketUtility.findLargestTicketNumber(lotteryTickets));
        System.out.println("5 juist: " + LotteryTicketUtility.countNumberOfLotteryTicketsWithAmountOfNumbersValid(lotteryTickets, winningNumbers, 5));
        System.out.println("4 juist: " + LotteryTicketUtility.countNumberOfLotteryTicketsWithAmountOfNumbersValid(lotteryTickets, winningNumbers, 4));
        System.out.println("3 juist: " + LotteryTicketUtility.countNumberOfLotteryTicketsWithAmountOfNumbersValid(lotteryTickets, winningNumbers, 3));
        System.out.println("Top verkooppunten:");
        LotteryTicketUtility.printFiveBestSellingPoints(lotteryTickets);
    }

    private static void fileFound(Path filePath, AtomicReference<LocalDateTime> time, List<LotteryTicket> lotteryTickets, List<Integer> winningNumbers) {
        try (BufferedReader br = Files.newBufferedReader(filePath)) {
            time.set(LocalDateTime.parse(br.readLine(), LotteryTicketUtility.getDateTimeFormatter()));
            String winning = br.readLine();
            for (String number : winning.split("-")) {
                winningNumbers.add(Integer.parseInt(number));
            }
            String line = br.readLine();
            while (line != null) {
                String[] lotteryTicketLine = line.split(";");
                lotteryTickets.add(LotteryTicketUtility.mapToLotteryTicket(lotteryTicketLine));

                line = br.readLine();
            }
        } catch (IOException e) {
            System.out.println("Kon het bestand niet vinden!");
        }
    }
}
