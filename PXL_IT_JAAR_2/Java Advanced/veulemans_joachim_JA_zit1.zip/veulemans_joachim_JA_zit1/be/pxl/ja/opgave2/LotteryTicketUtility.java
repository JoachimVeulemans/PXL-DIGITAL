package be.pxl.ja.opgave2;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class LotteryTicketUtility {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public static DateTimeFormatter getDateTimeFormatter() {
        return DATE_TIME_FORMATTER;
    }

    public static LotteryTicket mapToLotteryTicket(String[] data) {
        LotteryTicket lotteryTicket = new LotteryTicket();
        lotteryTicket.setDateTime(LocalDateTime.parse(data[0], LotteryTicketUtility.getDateTimeFormatter()));
        lotteryTicket.setSellingPoint(data[1]);
        for (String number : data[2].split("-")) {
            lotteryTicket.addLotteryNumber(Integer.parseInt(number));
        }
        lotteryTicket.setTicketNumber(Integer.parseInt(data[3]));
        lotteryTicket.setQuickpick(data.length == 5 && data[4].toUpperCase().contains("Q"));
        return lotteryTicket;
    }

    public static double getPercentageQuickPick(List<LotteryTicket> lotteryTickets) {
        long numberOfQuickpickLotteryTickets = lotteryTickets
                .stream()
                .filter(lotteryTicket -> lotteryTicket.isQuickpick())
                .count();
        return numberOfQuickpickLotteryTickets * 100.0 / lotteryTickets.stream().count();
    }

    public static int findLargestTicketNumber(List<LotteryTicket> lotteryTickets) {
        int max = lotteryTickets
                .stream()
                .sorted((o1, o2) -> o2.getTicketNumber() - o1.getTicketNumber())
                .findFirst().get().getTicketNumber();
        return max;
    }

    public static LotteryTicket findWinningLotteryTicket(List<LotteryTicket> lotteryTickets, List<Integer> winningNumbers) {
        return lotteryTickets
                .stream()
                .filter(lotteryTicket -> lotteryTicket.getLotteryNumbers().equals(winningNumbers))
                .findFirst().get();
    }

    public static long countNumberOfLotteryTicketsWithAmountOfNumbersValid(List<LotteryTicket> lotteryTickets, List<Integer> winningNumbers, int amount) {
        int count = 0;
        for (LotteryTicket lotteryTicket : lotteryTickets) {
            int amountOfNumbersCorrect = 0;
            List<Integer> numbers = lotteryTicket.getLotteryNumbers();
            for (Integer number: numbers) {
                if (winningNumbers.contains(number)) {
                    amountOfNumbersCorrect++;
                }
            }
            if (amountOfNumbersCorrect == amount) {
                count++;
            }
        }
        return count;
    }

    public static void printFiveBestSellingPoints(List<LotteryTicket> lotteryTickets) {
        // Ik weet dat dit niet de beste oplossing is maar ik kreeg het niet opgelost met streams. Het is beter dan niets toch?
        HashMap<String, Integer> top5 = new HashMap<>();
        for (LotteryTicket lotteryTicket : lotteryTickets) {
            if (top5.containsKey(lotteryTicket.getSellingPoint())) {
                top5.put(lotteryTicket.getSellingPoint(), top5.get(lotteryTicket.getSellingPoint()).intValue() + 1);
            } else {
                top5.put(lotteryTicket.getSellingPoint(), 1);
            }
        }
        Collection<Integer> highest = top5.values();
        List<String> alreadybeen = new ArrayList<>();
        highest = highest.stream().sorted((o1, o2) -> o2 - o1).limit(5).collect(Collectors.toCollection(ArrayList::new));
        for (int i = 0; i < 5; i++) {
            for (String key : top5.keySet()) {
                if (top5.get(key).intValue() == ((ArrayList<Integer>) highest).get(i) && !alreadybeen.contains(key) && alreadybeen.size() < 5) {
                    System.out.println(key + " : " + ((ArrayList<Integer>) highest).get(i));
                    alreadybeen.add(key);
                }
            }
        }
    }
}
