package opdracht2;

public interface Monster {
	void menace();
}
