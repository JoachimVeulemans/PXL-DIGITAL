package opdracht2;

public interface DangerousMonster extends Monster {
	void destroy(Monster monster);
}
