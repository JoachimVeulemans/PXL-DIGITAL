package be.pxl.ja.week4.oefening1;

@FunctionalInterface
public interface NumberFilter {
	public boolean check(int number);
}