package be.pxl.ja.week4.oefening1;

public class NumberSelector {
	private NumberMachine numbermachine;
	
	public NumberSelector(NumberMachine machine) {
		this.numbermachine = machine;
	}
	
	public String showEvenNumbers() {
		String result = numbermachine.processNumbers(new NumberFilter() {
			@Override
			public boolean check(int number) {
				return (number%2==0);
			}
		});
		
		return result;
	}
	
	public String showNumbersAbove(int k) {
		return numbermachine.processNumbers(number -> number > k);
	}
	
	public String printHexNumbers() {
		return numbermachine.convertNumbers(t -> Integer.toHexString(t));
	}
}
