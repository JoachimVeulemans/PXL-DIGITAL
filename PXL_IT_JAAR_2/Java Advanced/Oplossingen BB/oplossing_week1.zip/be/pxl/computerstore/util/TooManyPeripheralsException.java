package be.pxl.computerstore.util;

@SuppressWarnings("serial")
public class TooManyPeripheralsException extends Exception {

	public TooManyPeripheralsException(String message) {
		super(message);
	}

}
