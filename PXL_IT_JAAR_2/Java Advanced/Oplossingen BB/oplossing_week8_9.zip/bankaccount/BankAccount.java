package be.pxl.io.bankaccount;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BankAccount implements Serializable {
	private String number;
	private String name;
	private double balance;

	public BankAccount(String number, String name, double balance) {
		this.name = name;
		this.balance = balance;
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public double getBalance() {
		return balance;
	}
	
	public void withdraw(double amount) {
		if (amount > balance) {
			return;
		}
		balance -= amount;
	}
	
	public void deposit(double amount) {
		balance += amount;
	}

	@Override
	public String toString() {
		return "BankAccount [number=" + number + ", name=" + name + ", balance=" + balance + "]";
	}

}
