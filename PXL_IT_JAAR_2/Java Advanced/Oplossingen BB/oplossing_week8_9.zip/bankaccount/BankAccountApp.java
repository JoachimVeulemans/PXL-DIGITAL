package be.pxl.io.spaarrekeningen;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class BankAccountApp {
	public static void main(String[] args) {
		BankAccount test = new BankAccount("Test", 1000);
		
		Path path = Paths.get("data/REK001.bin").toAbsolutePath();
		
		if (!Files.exists(path)) {
			try {
				Files.createDirectories(path.getParent());
				Files.createFile(path);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		try(ObjectOutputStream objectOutputStream =
	            new ObjectOutputStream(new FileOutputStream(path.toFile()))) {
			objectOutputStream.writeObject(test);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try(ObjectInputStream objectInputStream =
	            new ObjectInputStream(new FileInputStream(path.toFile()))) {
			BankAccount account = (BankAccount) objectInputStream.readObject();
			System.out.println(account);
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
