package be.pxl.io.phonedirectory;

public class PhoneDirectoryException extends Exception {

	public PhoneDirectoryException(String message) {
		super(message);
	}

}
