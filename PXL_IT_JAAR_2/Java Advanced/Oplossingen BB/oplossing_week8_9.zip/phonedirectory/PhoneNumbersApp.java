package be.pxl.io.phonedirectory;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PhoneNumbersApp {

	public static void main(String[] args) {
		new PhoneNumbersApp().run();
	}

	public void run() {
		Scanner scanner = new Scanner(System.in);
		PhoneDirectory phoneDirectory = new PhoneDirectory();
		boolean running = true;
		try {
			phoneDirectory.readPhoneData(Paths.get("phonedirectory.txt"));
		} catch (PhoneDirectoryException e) {
			System.out.println(e.getMessage());
		}

		while (running) {
			printMenu();
			int menuOption = scanner.nextInt();
			scanner.nextLine(); // remove newLine from System.in
			switch (menuOption) {
			case 1:
				doLookup(scanner, phoneDirectory);
				break;
			case 2:
				try {
					doAddEntry(scanner, phoneDirectory);
				} catch (PhoneDirectoryException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				running = false;
				break;
			default:
				System.out.println("Invalid choice!");
			}
		}

		try {
			phoneDirectory.writePhoneData(Paths.get("phonedirectory.txt"));
		} catch (PhoneDirectoryException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("\nExiting program.");
		scanner.close();

	}

	void doLookup(Scanner scanner, PhoneDirectory phoneDirectory) {
		System.out.println("\nLook up the name: ");
		String name = scanner.nextLine();
		List<String> numbers = phoneDirectory.search(name);
		if (numbers == null || numbers.isEmpty()) {
			System.out.println("\nNo such name in the directory.");
		} else {
			numbers.stream().forEach(System.out::println);
		}
	}

	void doAddEntry(Scanner scanner, PhoneDirectory phoneDirectory) throws PhoneDirectoryException {
		System.out.println("\nGive name: ");
		String name = scanner.nextLine();
		if (phoneDirectory.search(name) != null) {
			System.out.println("That name is already in the directory.");
			return;
		}
		boolean moreNumbers = true;
		List<String> numbers = new ArrayList<>();
		do {
			System.out.println("What is the number for " + name + "? (-1 to stop)");
			String number = scanner.nextLine();
			moreNumbers = !number.equals("-1");
			if (moreNumbers) {
				numbers.add(number);
			}

		} while (moreNumbers);
		phoneDirectory.addNewEntry(name, numbers);
	}

	public void printMenu() {
		System.out.println();
		System.out.println("Select the operation you want to perform:");
		System.out.println();
		System.out.println("     1.  Look up a phone number");
		System.out.println("     2.  Add an entry to the directory");
		System.out.println("     3.  Exit form this program.");
		System.out.println();
		System.out.println("Enter the number of your choice: ");
	}

}
