package be.pxl.io.phonedirectory;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PhoneDirectory {
	private Map<String, List<String>> phoneDirectory = new HashMap<>();
	public boolean changed;

	public void readPhoneData(Path path) throws PhoneDirectoryException {
		if (!Files.exists(path)) {
			return;
		}
		try (BufferedReader reader = Files.newBufferedReader(path)) {
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] parts = line.split(";");
				addNewEntry(parts[0], Arrays.asList(parts).subList(1, parts.length));
			}
		} catch (Exception e) {
			throw new PhoneDirectoryException("Problem reading from file.");
		}
	}

	public List<String> search(String name) {
		return phoneDirectory.get(name);
	}

	public void addNewEntry(String name, List<String> numbers) throws PhoneDirectoryException {
		if (phoneDirectory.get(name) != null) {
			throw new PhoneDirectoryException("Phone directory already contains data for " + name);
		}
		phoneDirectory.put(name, numbers);
		changed = true;
	}

	public void writePhoneData(Path path) throws PhoneDirectoryException {
		if (!Files.exists(path)) {
			try {
				Files.createFile(path);
			} catch (IOException e) {
				throw new PhoneDirectoryException("Problem creating file.");
			}
		}
		try (BufferedWriter writer = Files.newBufferedWriter(path)) {
			for (String key : phoneDirectory.keySet()) {
				writer.write(key);
				for (String number : phoneDirectory.get(key)) {
					writer.write(";" + number);
				}
				writer.newLine();
			}
		} catch (Exception e) {
			throw new PhoneDirectoryException("Problem writing to file.");
		}
	}

}
