<?php
interface JsonWritable
{
	public function getJSONString();
}
