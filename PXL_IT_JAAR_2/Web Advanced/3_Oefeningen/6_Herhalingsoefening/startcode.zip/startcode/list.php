<?php
// Om aan de oefening over fetch te kunnen beginnen wordt in de huidige versie van list.php altijd een JSON-string afgedrukt.
// Je mag list.php natuurlijk aanpassen aan het gevraagde in de oefening over PDO. 
print ('{"id":1,"name":"name1", "books":[{"id":1, "title": "title1"},{"id":2, "title": "title2"}]}');

