<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3</title>
</head>
<body>


<form action="oef3verwerk.php" method="get">
  bookId:
<input type="submit" value="delete"/>
</form>
</body>
</html>
