<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3verwerk</title>
</head>
<body>
<?php
$id=$_GET['book_id'];
$user='root';
$password='root';
$database='examen'; 
$pdo=null;
try {
    $pdo = new PDO( "mysql:host=localhost;dbname=$database",
                   $user, $password );
    $pdo->setAttribute( PDO::ATTR_ERRMODE,                          
                        PDO::ERRMODE_EXCEPTION );

    $statement = $pdo->exec("DELETE FROM book WHERE book.id = $id");
} catch ( PDOException $e ) {
    print 'error';
}
$pdo = null;
?>
</body>
</html>
