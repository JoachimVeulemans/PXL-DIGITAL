<?php
require_once('vendor/autoload.php');
use Util\Book;
use Util\Author;
$id=$_GET['id'];
$user='root';
$password='root';
$database='examen'; 
$pdo=null;
try {
    $pdo = new PDO( "mysql:host=localhost;dbname=$database",
                   $user, $password );
    $pdo->setAttribute( PDO::ATTR_ERRMODE,                          
                        PDO::ERRMODE_EXCEPTION );

    $statement = $pdo->query("SELECT author.name FROM author WHERE author.id=$id");
    $statement->setFetchMode(PDO::FETCH_ASSOC);
	$name=null;
    $row = $statement->fetch();
	$name =  $row['name'];
    $statement = $pdo->query("SELECT book.id, book.title FROM book WHERE book.author_id=$id");
	$books=[];
	while($row = $statement->fetch()){
		$book=new Book($row['id'], $row['title']);
		$books[]=$book;
	}
	$author=new Author($id,$name,$books);
	print($author->getJSONString());

} catch ( PDOException $e ) {
    print '{}';
}
$pdo = null;


