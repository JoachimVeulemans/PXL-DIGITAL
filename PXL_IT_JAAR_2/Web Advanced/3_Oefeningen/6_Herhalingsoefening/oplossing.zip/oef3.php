<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3</title>
</head>
<body>


<form action="oef3verwerk.php" method="get">
  bookId:
<?php
$user='root';
$password='root';
$database='examen'; 
$pdo=null;
try {
    $pdo = new PDO( "mysql:host=localhost;dbname=$database",
                   $user, $password );
    $pdo->setAttribute( PDO::ATTR_ERRMODE,                          
                        PDO::ERRMODE_EXCEPTION );

    $statement = $pdo->query("SELECT book.id FROM book");
    $statement->setFetchMode(PDO::FETCH_ASSOC);
	print("<select name='book_id'>");
	while($row = $statement->fetch()){
		print("<option value='$row[id]'>$row[id]</option>");
	}
	print("</select>");
} catch ( PDOException $e ) {
    print 'error';
}
$pdo = null;
?>
<input type="submit" value="delete"/>
</form>
</body>
</html>
