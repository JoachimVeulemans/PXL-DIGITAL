<?php
namespace Util;
class Book implements JsonWritable
{
	private $id;
	private $title;

	public function __construct($id,$title){
		$this->id=$id;
		$this->title=$title;
	}

	public function getJSONString(){
	    $json = array(
    	    'id' => $this->id,
    	    'title' => $this->title
    	);
	    return json_encode($json);
	}
}
