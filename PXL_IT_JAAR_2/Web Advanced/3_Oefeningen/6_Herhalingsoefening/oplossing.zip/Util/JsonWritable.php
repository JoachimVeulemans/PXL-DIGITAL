<?php
namespace Util;
interface JsonWritable
{
	public function getJSONString();
}
