<?php
namespace Util;
class Author implements JsonWritable
{
	private $id;
	private $name;
	private $books;

	public function __construct($id, $name, array $books){
		$this->id=$id;
		$this->name=$name;
		$this->books=$books;
	}

	public function getJSONString(){
		$booksJSON=[];
		foreach($this->books as $book){
			$booksJSON[] = $book->getJSONString();
		}
		return "{\"id\":$this->id, \"name\":\"$this->name\", \"books\":[".implode($booksJSON,",")."]}";
	}
}
