<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef5</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 19/02/2019
 * Time: 20:35
 */

if($_GET['getal'] < 0) {
    print('De ingave laat enkel positieve getallen toe en niet' . $_GET['getal']);
} else {
    require_once('wiskunde.php');
    $waarde = faculteit($_GET['getal']);
    print($_GET['getal'] . '! = ' . $waarde);
}
?>
</body>
</html>
