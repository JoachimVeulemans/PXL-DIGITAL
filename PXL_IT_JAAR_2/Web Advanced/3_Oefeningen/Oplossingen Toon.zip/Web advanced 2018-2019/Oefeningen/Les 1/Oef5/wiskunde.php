<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 19/02/2019
 * Time: 20:39
 */

function faculteit ($getal) {
    $waarde = 1;
    for ($i=$getal;$i>1;$i--) {
        $waarde = $waarde * $i;
    }
    return $waarde;
}
?>