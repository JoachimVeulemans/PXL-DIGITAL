<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 19/02/2019
 * Time: 10:25
 */


if ($_GET['ammount'] <= 0) {
    header("Location: ./ingave.html");
} else {
    print('<form>');
    print("<label>Getallen: </label><br/>");
    for($i=0;$i<$_GET['ammount'];$i++){
        print('<input name="getal[]"><br/>');
    }
    print('<button formaction="statistiek.php" formmethod="get"  style="height: 25px; width: 100px;">submit</button>');
    print('</form>');
}

?>
</body>
</html>