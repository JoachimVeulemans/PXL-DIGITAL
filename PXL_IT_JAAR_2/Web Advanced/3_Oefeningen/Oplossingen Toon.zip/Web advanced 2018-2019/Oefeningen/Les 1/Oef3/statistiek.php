<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 19/02/2019
 * Time: 10:51
 */

$highest = null;
$lowest = null;
$total = 0;
$ammount = 0;
$bsvalues = array();
foreach($_GET['getal'] as $value) {
    if (is_numeric($value)) {
        if ($highest === null and $lowest === null) {
            $highest = $value;
            $lowest = $value;
        } else {
            if($lowest > $value) {
                $lowest = $value;
            } else {
                if ($highest < $value) {
                    $highest = $value;
                }
            }
        }
        $total += $value;
        $ammount++;
    } else {
        $bsvalues[] = $value;
    }
}
$average = $total / $ammount;
print('highest value = ' . $highest . '<br/>');
print('lowest value = ' . $lowest . '<br/>');
print('average value = ' . $average . '<br/>');
print('non numeric answers = <br/>');
foreach ($bsvalues as $item) {
    print($item . '<br/>');
}
?>
</body>
</html>