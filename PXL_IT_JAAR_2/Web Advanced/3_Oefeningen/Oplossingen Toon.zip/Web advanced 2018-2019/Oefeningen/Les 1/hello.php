<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hello</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 18/02/2019
 * Time: 15:52
 */
$name = 'Sofie';
print("hello $name\n");
?>
</body>
</html>