<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef4</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 19/02/2019
 * Time: 11:10
 */

setcookie('naam', '' . $_GET['name'], time() + 60*60);
setcookie('kleur', '' . $_GET['color'] , time() + 60*60);
header("Location: ./toon.php");
?>
</body>
</html>
