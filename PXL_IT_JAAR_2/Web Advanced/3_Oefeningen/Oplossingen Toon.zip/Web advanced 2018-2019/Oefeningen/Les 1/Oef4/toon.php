<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef4</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 19/02/2019
 * Time: 11:10
 */

print('de ingegeven naam is ' . $_COOKIE['naam']);
print('<body style="background: ' . $_COOKIE['kleur'] . '"></body>');

?>
</body>
</html>