<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef2</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 18/02/2019
 * Time: 16:49
 */

function maakRij(int $min, int $max, int $stap=1){
    $returning[] = $min;
    $index = $min;
    $index += $stap;
    if ($min < $max) {
        while($index <= $max) {
            $returning[] = $index;
            $index += $stap;
        }
    } else {
        while($index >= $max) {
        $returning[] = $index;
        $index += $stap;
        }
    }
    return $returning;
}
foreach (maakRij(1,5,2) as $value){
    print($value . ' ');
}
print('<br/>');
foreach (maakRij(5,1,-2) as $value){
    print($value . ' ');
}
?>
</body>
</html>