
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef1</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 18/02/2019
 * Time: 16:20
 */

$aantalLijnen = 7;
$input = "#";
for ($i=0;$i<$aantalLijnen;$i++){
    print ($input . "<br/>");
    $input = $input . "#";
}
print('----------------------------------' . "<br/>");
$input = "#";
for ($i=0;$i<$aantalLijnen;$i++){
    for ($j=0;$j<$aantalLijnen-1-$i;$j++){
        print('&nbsp;&nbsp;');
    }
    print ($input . "<br/>");
    $input = $input . "#";
}
print('----------------------------------' . "<br/>");

$input = "#";
for ($i=0;$i<$aantalLijnen;$i++){
    for ($j=0;$j<$aantalLijnen-$i;$j++){
        print('&nbsp;&nbsp;');
    }
    print ($input . "<br/>");
    $input = $input . "##";
}
print('----------------------------------' . "<br/>");

$input = "#";
$interval = 5;
$index = 0;
for ($i=0;$i<$aantalLijnen;$i++){
    for ($j=0;$j<$aantalLijnen-$i;$j++){
        print('&nbsp;&nbsp;');
    }
    for ($k=0;$k<$i*2+1;$k++){
        if ($index%$interval === 0){
            print('@');
        } else {
            print('#');
        }
        $index++;
    }
    print ("<br/>");
}
?>
</body>
</html>