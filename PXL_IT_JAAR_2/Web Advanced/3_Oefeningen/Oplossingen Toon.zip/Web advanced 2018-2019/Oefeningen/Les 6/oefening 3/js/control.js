window.addEventListener("load", loaded);

function loaded() {
    let submitButton = document.getElementById("submit_button")   ;
    submitButton.addEventListener("click", checkTheEmail)
}

function checkTheEmail() {
    let input = document.getElementById("text_mail").value.toString();
    let output = document.getElementById("output");
    let error  = "Dit is een fout emailadres!";
    let email = input.trim().toLowerCase();
    let counter1 = 0;
    for (let i=0; i<email.length; i++){
        let char = email.charAt(i);
        if(char === '@'){
            counter1++;
        }
    }
    if(counter1 !== 1 || email.split("@")[0] === '') {
        output.innerText = error;
        return;
    }
    let emailTweedeDeel = email.split("@")[1];
    let counter2 = 0;
    for (let i=0; i<email.length; i++){
        let char = email.charAt(i);
        if(char === '.'){
            counter2++;
        }
    }
    if(counter2 !== 1) {
        output.innerText = error;
        return;
    }
    output.innerText = "Dit emailadres is correct.";
}