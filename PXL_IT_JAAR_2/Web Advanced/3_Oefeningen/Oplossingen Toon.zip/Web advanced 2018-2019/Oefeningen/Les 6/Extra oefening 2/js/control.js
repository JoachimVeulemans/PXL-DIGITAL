window.addEventListener("load", loaded);
let table;

function loaded() {
    let submitButton = document.getElementById("submit_button")   ;
    submitButton.addEventListener("click", makeATable)
}

function makeATable() {
    let rows = document.getElementById("text_rows").value;
    let columns = document.getElementById("text_columns").value;
    let output = document.getElementById("output");
    makeElementEmpty(output);
    if(!isNumeric(rows) || !isNumeric(columns) || rows > 10 || columns > 10){
        output.innerText = "foute ingave.";
        return;
    }
    table = makeTable(rows, columns);
    output.appendChild(table);
}

function makeElementEmpty(element) {
    while (element.hasChildNodes()) {
        element.removeChild(element.firstChild);
    }
}

function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function makeTable(n, m) {
    let newTable = document.createElement("table");
    for (let i = 1; i <= n; i++) {
        let tr = document.createElement("tr");
        for (let j = 1; j <= m; j++) {
            let string = i + "*" + j + "=" + i*j;
            let td = document.createElement("td");
            td.innerText = string;
            td.addEventListener("click", makeAFieldRed)
            tr.appendChild(td);
        }
        newTable.appendChild(tr);
    }
    return newTable;
}

function makeAFieldRed() {
    let source = event.target || event.srcElement;
    source.setAttribute("class", "red");
    let tr  = source.parentElement;
    counter = 0;
    let index = -1;
    for(let i=0; i<tr.childNodes.length; i++) {
        if(tr.childNodes[i].getAttribute("class") === "red"){
            counter++;
        }
        if(tr.childNodes[i] === source){
            index = i;
        }
    }
    if(counter === tr.childNodes.length){
        console.log("special message");
    }
    counter = 0;
    for (let i=0; i<table.childNodes.length; i++){
        if(table.childNodes[i].childNodes[index].getAttribute("class") === "red"){
            counter++;
        }
    }
    if(counter === table.childNodes.length){
        console.log("very special message");
    }

}

