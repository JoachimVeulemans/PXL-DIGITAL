<?php
header('Content-Type: application/json');

$name = $_GET['name'];
$user = 'root';
$password = 'root';
$database = 'oef2';
$table = 'name';
$query = 'DELETE name FROM ' . $table . ' WHERE name = :name';

if ($name != '') {
    $pdo = null;
    try {
        $pdo = new PDO('mysql:host=localhost;dbname='.$database, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $statement = $pdo->prepare($query);
        $statement->bindParam(':name', $name, PDO::PARAM_STR);
        $statement->execute();
        print("Succeeded");
    } catch (PDOException $e) {
        print ('Exception!: ' . $e->getMessage());
    }
    $pdo = null;
}
