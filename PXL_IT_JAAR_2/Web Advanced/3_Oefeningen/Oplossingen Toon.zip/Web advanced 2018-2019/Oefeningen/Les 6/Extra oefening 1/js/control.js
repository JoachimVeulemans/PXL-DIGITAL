window.addEventListener("load", loaded);

function loaded() {
    let submitButton = document.getElementById("submit_button")   ;
    submitButton.addEventListener("click", makeATable)
}

function makeATable() {
    let rows = document.getElementById("text_rows").value;
    let columns = document.getElementById("text_columns").value;
    let output = document.getElementById("output");
    makeElementEmpty(output);
    if(!isNumeric(rows) || !isNumeric(columns) || rows > 10 || columns > 10){
        output.innerText = "foute ingave.";
        return;
    }
    let table = makeTable(rows, columns);
    output.appendChild(table);
}

function makeElementEmpty(element) {
    while (element.hasChildNodes()) {
        element.removeChild(element.firstChild);
    }
}

function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function makeTable(n, m) {
    let table = document.createElement("table");
    for (let i = 1; i <= n; i++) {
        let tr = document.createElement("tr");
        for (let j = 1; j <= m; j++) {
            let string = i + "*" + j + "=" + i*j;
            let td = document.createElement("td");
            td.innerText = string;
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    return table;
}