"use strict";

import WereldObject from "./WereldObject";

require('./WereldObject.js');

export default class Hero extends WereldObject {
    constructor(point){
        super(point);
    }

    moveDown(){
        let y = super.getY();
        super.setY(y + 1);
    }

    moveUp(){
        let y = super.getY();
        super.setY(y + 1);
    }

    moveLeft(){
        let x = super.getX();
        super.setX(x - 1);
    }

    moveRight(){
        let x = super.getX();
        super.setX(x + 1);
    }
}