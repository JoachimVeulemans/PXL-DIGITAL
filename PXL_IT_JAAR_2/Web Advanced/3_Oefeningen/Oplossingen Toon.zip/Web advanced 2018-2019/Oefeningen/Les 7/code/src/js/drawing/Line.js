"use strict";

import Point from "./Point";

export default class Line{
    constructor(point1,point2){
        if (!(point1 instanceof Point)) {
            throw new Error("Parameter is not a number!");
        }
        if(!(point2 instanceof Point)){
            throw new Error("Parameter is not a number!");
        }
        this.point1=point1;
        this.point2=point2;
    }

    getPoint1(){
        return this.point1;
    }
    getPoint2(){
        return this.point2;
    }

    toString() {
        return `${this.point1.toString()},${this.point2.toString()}`;
    }
}