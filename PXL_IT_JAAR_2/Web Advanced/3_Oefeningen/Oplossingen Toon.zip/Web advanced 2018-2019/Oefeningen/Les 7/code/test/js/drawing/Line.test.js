import Point from '../../../src/js/drawing/Point';
import Line from '../../../src/js/drawing/Line';
describe('constructor',
    () => {
        it('should generate a Line-object for valid args',
            () => {
                let point1 = new Point(1,1);
                let point2 = new Point(2,2);
                let line = new Line(point1, point2);
                expect(line).toBeInstanceOf(Line)
            }
        )
        it('should throw error when 1st parameter is not a Point',
            () => {
                let point2 = new Point(2,2);
                expect(() => {
                    new Line("aa", point2);
                }).toThrow(Error)
            })
        it('should throw error when 2nd parameter is not a number',
            () => {
                let point1 = new Point(2,2);
                expect(() => {
                    new Line(point1, "aaa");
                }).toThrow(Error)
            })
    }
);

test('getPoint1 to return the correct value',
    () => {
        let point1 = new Point(1,1);
        let point2 = new Point(2,2);
        let line = new Line(point1, point2);
        let x = line.getPoint1();
        expect(x).toBe(point1);
    });

test('getPoint1 to return the correct value',
    () => {
        let point1 = new Point(1,1);
        let point2 = new Point(2,2);
        let line = new Line(point1, point2);
        let x = line.getPoint2();
        expect(x).toBe(point2);
    });

test('toString to return the correct value', () => {
    let point1 = new Point(1,1);
    let point2 = new Point(2,2);
    let line = new Line(point1, point2);
    let returnedString = line.toString();
    expect(returnedString).toBe(`${point1.toString()},${point2.toString()}`);
});

