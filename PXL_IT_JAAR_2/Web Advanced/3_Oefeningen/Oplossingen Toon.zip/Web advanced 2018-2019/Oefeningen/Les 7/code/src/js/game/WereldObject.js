"use strict";

import Point from "../drawing/Point";

export default class WereldObject{
    constructor(point){
        if (!(point instanceof Point)) {
            throw new Error("Parameter is not a number!");
        }
        this.location=point;
    }

    getX(){
        return this.location.getX();
    }

    setX(x){
        if (isNaN(x)) {
            throw new Error("Parameter is not a number!");
        }
        this.location.x = x;
    }

    getY(){
        return this.location.getY();
    }

    setY(y){
        if (isNaN(y)) {
            throw new Error("Parameter is not a number!");
        }
        this.location.y = y;
    }

    toString() {
        return `${this.location.toString()}`;
    }
}