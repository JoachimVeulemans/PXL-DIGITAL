"use strict";

export default class Date {
    constructor(day, month, year){
        if (isNaN(day) || isNaN(month) || isNaN(year) || day > 31 || month > 12 || day < 1 || month < 1) {
            throw new Error("Parameter is not a number!");
        }
        this.day = day;
        this.month = month;
        this.year = year;
    }

    static get MONTHS() {
        return ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep','oct', 'nov', 'dec'];
    }
    getLongMonth(){
        return Date.MONTHS[this.month-1];
    }

    toString(){
        return `${this.day}/${this.month}/${this.year}`;
    }

    toStringMonth(){
        return `${this.day}/${this.getLongMonth()}/${this.year}`;
    }
}