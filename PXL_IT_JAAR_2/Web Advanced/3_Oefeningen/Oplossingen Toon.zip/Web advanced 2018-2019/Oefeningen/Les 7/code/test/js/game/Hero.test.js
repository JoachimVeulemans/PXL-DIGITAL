import Point from "../../../src/js/drawing/Point";
import Hero from "../../../src/js/game/Hero";

test('moveLeft to decrement the X value',
    () => {
        let point1 = new Point(1,1);
        let hero = new Hero(point1);
        hero.moveLeft();
        let x = hero.getX();
        expect(x).toBe(0);
    });

test('moveRight to increment the X value',
    () => {
        let point1 = new Point(1,1);
        let hero = new Hero(point1);
        hero.moveRight();
        let x = hero.getX();
        expect(x).toBe(2);
    });