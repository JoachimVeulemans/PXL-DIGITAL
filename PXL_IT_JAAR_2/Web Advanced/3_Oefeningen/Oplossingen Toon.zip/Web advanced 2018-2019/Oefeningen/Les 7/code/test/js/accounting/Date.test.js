import Date from "../../../src/js/accounting/Date";

test('toString returns correct value',
    () => {
        let date = new Date(21,12,2012);
        let string = date.toString();
        expect(string).toBe("21/12/2012");
    });

test('toStringMonth returns correct value',
    () => {
        let date = new Date(21,12,2012);
        let string = date.toStringMonth();
        expect(string).toBe("21/dec/2012");
    });