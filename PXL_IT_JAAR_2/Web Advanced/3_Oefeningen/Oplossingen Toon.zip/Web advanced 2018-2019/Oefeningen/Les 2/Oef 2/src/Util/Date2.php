<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 15:52
 */
class Date {
    private static $day;
    private static $month;
    private static $year;

    private static $MONTHS = array("jan","feb","mar","apr","may","jun","jul","aug", "sep", "okt", "nov", "dec");

    private function __construct($day = 1, $month = 1, $year=2008) {
        $tempday = $day % 31;
        $tempmonth = $month % 12;
        $this->day = $day;
        $this->month = $month;
        $this->year = $year;
    }

    public static function make($day = 1, $month = 1, $year=2008) {
        self::$day = $day;
        self::$month = $month;
        self::$year = $year;
    }

    public static function changeDay($ammount) {
        return new self(self::$day + $ammount, self::$month, self::$year);
    }

    public static function changeMonth($ammount) {
        return new self(self::$day, self::$month + $ammount, self::$year);
    }

    public static function changeYear($ammount) {
        return new self(self::$day , self::$month, self::$year + $ammount);
    }
    /*
    public function __toString()
    {
        return $this->day . "/" . $this->month . "/" . $this->year;
    }

    public function printMonth(){
        print($this->day . "/" . self::$MONTHS[$this->month - 1] . "/" . $this->year);
    }*/
}