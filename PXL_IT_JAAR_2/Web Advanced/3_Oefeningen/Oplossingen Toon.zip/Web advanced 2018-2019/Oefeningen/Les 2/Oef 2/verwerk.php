<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Les2 Oef2</title>
</head>
<body>

<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 15:40
 */
require_once 'src/Util/Date.php';
$date = new Date($_GET['day'], $_GET['month'], $_GET['year']);
$date->printMonth();
print('<br/>');
print($date);

?>
</body>
</html>

