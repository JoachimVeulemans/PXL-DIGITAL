<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 15:24
 */
class Date {
    private $day;
    private $month;
    private $year;

    private static $MONTHS = array("jan","feb","mar","apr","may","jun","jul","aug", "sep", "okt", "nov", "dec");

    public function __construct($day = 1, $month = 1, $year=2008) {
        $this->day = $day;
        $this->month = $month;
        $this->year = $year;
    }

    public function __toString()
    {
        return $this->day . "/" . $this->month . "/" . $this->year;
    }

    public function printMonth(){
        print($this->day . "/" . self::$MONTHS[$this->month - 1] . "/" . $this->year);
    }
}