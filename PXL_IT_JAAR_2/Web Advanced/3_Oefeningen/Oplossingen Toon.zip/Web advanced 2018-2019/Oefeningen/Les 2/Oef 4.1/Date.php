<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 15:24
 */
class Date {
    private $day;
    private $month;
    private $year;

    private static $MONTHS = array("jan","feb","mar","apr","may","jun","jul","aug", "sep", "okt", "nov", "dec");
    private static $DAYSOFTHEMONTH = array(31,28,31,30,31,30,31,31,30,31,30,31);

    public function __construct($day = 1, $month = 1, $year=2008) {
        if (!is_numeric($day) || !is_numeric($month) || $month<1 || $month>12 || !is_numeric($year) || $day > self::$DAYSOFTHEMONTH[$month-1] || $year < 0 ) {
            throw new DateException("U heeft een ongeldig jaar ingegeven of 29 februari in een schrikkeljaar");
        }
        $this->day = $day;
        $this->month = $month;
        $this->year = $year;
    }

    public function __toString()
    {
        return $this->day . "/" . $this->month . "/" . $this->year;
    }

    public function printMonth(){
        print($this->day . "/" . self::$MONTHS[$this->month - 1] . "/" . $this->year);
    }
}