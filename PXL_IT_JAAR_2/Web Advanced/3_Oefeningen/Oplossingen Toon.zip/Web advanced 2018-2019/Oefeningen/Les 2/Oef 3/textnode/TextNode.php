<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 16:10
 */
class TextNode
{
    private $nextNode;
    private $text;
    private function __construct($text)
    {
        // ... de eigenschap nextNode krijgt waarde null
        // ... de eigenschap text krijgt een waarde
        $this->nextNode = null;
        $this->text = $text;
    }
    public static function makeNode($text)
    {
        // ... roep de constructor aan en geef dit object terug
        return new self($text);
    }
    // de functie addNode voegt een TextNode toe op het einde van
    //een keten van nodes
    public function addNode($text)
    {
        // kijk of nextNode gelijk is aan null
        // indien ja: maak een nieuwe node aan en ken die toe aan
        //nextNode
        if($this->nextNode==null){
            $this->nextNode=self::makeNode($text);
        }
        else{
            // indien nee: roep de methode addNode aan op nextNode
            $this->nextNode->addNode($text);
        }
    }
    public function printAll()
    {
        print($this->text);
        if($this->nextNode !=null){
            $this->nextNode->printAll();
        }
    }

    public function printElementAt($i) {
        if($i < 0 || ($i !== 0 && $this->nextNode === null)) {
            return;
        }
        if ($i === 0) {
            print($this->text);
        } else {
            $this->nextNode->printElementAt($i - 1);
        }

    }
}