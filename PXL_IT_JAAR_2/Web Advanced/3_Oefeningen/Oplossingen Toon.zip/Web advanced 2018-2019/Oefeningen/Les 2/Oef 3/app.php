<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 16:15
 */

require_once 'textnode/TextNode.php';
$nodes = TextNode::makeNode("a");
$nodes->addNode("b");
$nodes->addNode("c");
//$nodes->printAll();
$nodes->printElementAt(2);
$nodes->printAll();