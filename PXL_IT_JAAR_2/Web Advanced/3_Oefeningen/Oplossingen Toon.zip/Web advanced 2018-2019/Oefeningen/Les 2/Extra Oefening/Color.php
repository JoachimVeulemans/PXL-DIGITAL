<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 16:53
 */

class Color
{
    private $rgb;

    public static function BLACK(){
        return new self("0x000000");
    }

    public static function WHITE(){
        return new self("0xFFFFFF");
    }

    public static function RED(){
        return new self("0xFF0000");
    }

    public static function GREEN(){
        return new self("0x00FF00");
    }

    public static function BLUE(){
        return new self("0x0000FF");
    }

    public static function YELLOW(){
        return new self("0xFFFF00");
    }

    private function __construct($rgb) {
        $this->rgb = $rgb;
    }
    public function getRgb() {
        return $this->rgb;
    }
    public function __toString() {
        return $this->getRgb();
    }
}