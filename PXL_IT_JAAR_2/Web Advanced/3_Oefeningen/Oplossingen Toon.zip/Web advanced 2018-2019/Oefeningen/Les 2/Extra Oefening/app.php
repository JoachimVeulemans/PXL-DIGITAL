<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 17:10
 */

require_once 'ColouredPoint.php';
require_once 'Color.php';

$point = ColouredPoint::make(1,2, Color::RED());
$point->print();
