<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 16:51
 */

require_once 'Point.php';

class ColouredPoint extends Point {

    private static $color;

    // Volgens de opgave zou deze constructor private moeten zijn, maar aangezien dat de constructor overerft
    // van de klasse Point en deze wilt overriden, moet deze constructor ook public zijn, dit is de enige fout die hier
    // nog in de oefening zit
    public function __construct($x, $y)
    {
        parent::__construct($x, $y);
    }

    public static function make($x, $y, Color $color){
        self::$color = $color;
        return new self($x, $y);
    }

    public function print() {
        print(parent::__toString() . " color: " . self::__toString());
    }

    public function __toString()
    {
        return self::$color;
    }
}