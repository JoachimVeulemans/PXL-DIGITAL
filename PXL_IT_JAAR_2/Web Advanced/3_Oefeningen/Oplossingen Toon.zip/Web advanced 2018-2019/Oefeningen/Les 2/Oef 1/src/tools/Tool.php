<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 14:26
 */

namespace tools;
interface Tool {
        public function doSomething();
}