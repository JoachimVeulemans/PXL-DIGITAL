<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 14:44
 */
require_once 'vendor/autoload.php';

use tools\Broom;
use workers\Handyman;

$broom = new Broom();
$henry = new Handyman($broom);
$henry->work();

//composer dump-autoload -o