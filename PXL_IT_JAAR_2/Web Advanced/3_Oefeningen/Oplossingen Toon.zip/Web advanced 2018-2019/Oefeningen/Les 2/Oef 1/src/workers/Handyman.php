<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 25/02/2019
 * Time: 14:34
 */
namespace workers;
use tools\Tool;
class Handyman implements Worker {
    private $tool;

    public function __construct(Tool $tool) {
        $this->tool = clone $tool;
    }

    public function work()
    {
        $this->tool->doSomething();
    }
}