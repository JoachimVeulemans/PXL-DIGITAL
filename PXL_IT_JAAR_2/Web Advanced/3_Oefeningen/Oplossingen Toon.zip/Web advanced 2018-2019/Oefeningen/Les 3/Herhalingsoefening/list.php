<?php

require 'vendor/autoload.php';

use util\Author;
use util\Book;

$id = $_GET['id'];
$user = 'root';
$password = 'root';
$database = "examen";
$query1 = "SELECT * FROM book WHERE author_id = :id";
$query2 = "SELECT * FROM author WHERE id = :id";
try {
    $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement = $pdo->prepare($query1);
    $statement->bindParam(':id', $id, PDO::PARAM_INT);
    $statement->setFetchMode(PDO::FETCH_ASSOC);
    $statement->execute();

    $books = array();

    while ($row = $statement->fetch()) {
        $books[] = new Book($row['id'], $row['title']);
    }

    $statement2 = $pdo->prepare($query2);
    $statement2->bindParam(':id', $id, PDO::PARAM_INT);
    $statement2->setFetchMode(PDO::FETCH_ASSOC);
    $statement2->execute();

    if ($statement2->rowCount() > 0) {
        $row = $statement2->fetch();
        $author = new Author($row['id'], $row['name'], $books);
        print($author->getJSONString());
    } else {
        print("{}");
    }


} catch (PDOException $exception) {
    print("{}". "<br/>");
}
$pdo = null;