<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3verwerk</title>
</head>
<body>
<?php
$id = $_GET['id'];
print($id);
$user = 'root';
$password = 'root';
$database = "examen";
$query1 = "DELETE FROM book WHERE id = :id";

try {
    $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement = $pdo->prepare($query1);
    $statement->bindParam(':id', $id, PDO::PARAM_INT);
    $statement->execute();
} catch (PDOException $exception) {
    print ('Exception: ' . $exception->getMessage());
}
?>
</body>
</html>
