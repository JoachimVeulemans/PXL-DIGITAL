<?php
namespace util;
interface JsonWritable
{
	public function getJSONString();
}
