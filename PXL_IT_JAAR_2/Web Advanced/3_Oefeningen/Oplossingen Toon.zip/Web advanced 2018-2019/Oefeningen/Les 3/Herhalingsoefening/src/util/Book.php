<?php
namespace util;
class Book implements JsonWritable
{
	private $id;
	private $title;

	public function __construct($id,$title){
	// id, naam en books worden toegekend
        $this->id = $id;
        $this->title = $title;
	}

	public function getJSONString(){
	    //{"id":1,"name":"name1", "books":[{"id":1, "title": "title1"},{"id":2, "title": "title2"}]}
	// de JSON-voorstelling van het object wordt teruggeven.
        return '{"id":' . $this->id . ', "title": "' . $this->title . '"}';
	}

	public function __toString()
    {
        return $this->getJSONString();
    }
}
