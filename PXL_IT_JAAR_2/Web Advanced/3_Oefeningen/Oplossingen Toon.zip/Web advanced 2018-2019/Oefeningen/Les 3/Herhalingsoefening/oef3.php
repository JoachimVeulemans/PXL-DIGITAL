<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3</title>
</head>
<body>


<form action="oef3verwerk.php" method="get">
  bookId:
<select name="id">
    <?php
    $user = 'root';
    $password = 'root';
    $database = "examen";
    $query1 = "SELECT * FROM book";
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $statement = $pdo->query($query1);
        $statement->setFetchMode(PDO::FETCH_ASSOC);

        $books = array();

        while ($row = $statement->fetch()) {
            print("<option value='" . $row['id'] . "'>" . $row['id'] . "</option>");
        }
    } catch (PDOException $exception) {
        print ('Exception: ' . $exception->getMessage());
    }
    ?>
</select>
<input type="submit" value="delete"/>
</form>
</body>
</html>
