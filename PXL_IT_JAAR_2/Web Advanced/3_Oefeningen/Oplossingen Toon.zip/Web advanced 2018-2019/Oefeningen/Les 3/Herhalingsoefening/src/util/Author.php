<?php
namespace util;
class Author implements JsonWritable
{
	private $id;
	private $name;
	private $books;

	public function __construct($id, $name, array $books){
	// id, naam en books worden toegekend
        $this->id = $id;
        $this->name = $name;
        $this->books = $books;
	}

	public function getJSONString(){
	    //print ('{"id":1,"name":"name1", "books":[{"id":1, "title": "title1"},{"id":2, "title": "title2"}]}');
	// de JSON-voorstelling van het object wordt teruggeven.
        return '{"id":' . $this->id .',"name":"' . $this->name . '", "books":[' . implode(",", $this->books) . ']}';
	}
}
