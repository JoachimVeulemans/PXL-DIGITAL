<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Les3 PDO Oef1</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 4/03/2019
 * Time: 14:23
 */
$query = $_GET['naam'];
print('query = ' . $query . '<br/>');

$user = 'root';
$password = 'root';
$database = $_GET['DatabaseInput'];
print('databank = ' . $database . '<br/>');
$pdo = null;
if ((stristr($query, "drop") === false and stristr($query, "truncate") === false and stristr($query, "delete") === false)) {
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $statement = $pdo->query($query);
        $statement->setFetchMode(PDO::FETCH_ASSOC);

        if ($statement->rowCount() > 0) {
            /*$columnNames = [];
            for($i=0; $i < $statement->columnCount(); $i++) {
                $columnData = $statement->getColumnMeta($i);
                $columnName = $columnData['name'];
                $columnNames[] = $columnName;
            }*/

            while ($row = $statement->fetch()) {
                print(implode(" ", $row));
                print ('<br/>');
            }
        }


    } catch (PDOException $exception) {
        print ('Exception: ' . $exception->getMessage());
    }
    $pdo = null;
} else {
    print("VERKEERDE QUERRY!!!");
}
?>
</body>
</html>

