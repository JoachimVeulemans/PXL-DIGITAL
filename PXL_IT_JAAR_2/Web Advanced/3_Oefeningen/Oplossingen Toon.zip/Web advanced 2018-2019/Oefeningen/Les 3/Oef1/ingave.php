<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Les3 PDO Oef1</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 4/03/2019
 * Time: 13:59
 */

$user = 'root';
$password = 'root';
$pdo = null;
try{
    $pdo = new PDO("mysql:host=localhost;", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement = $pdo->query('SHOW DATABASES');
    $statement->setFetchMode(PDO::FETCH_ASSOC);
    /*print ("" . $statement->getColumnMeta(1));
    print("<form>");
    print ("<label>Databank </label>");
    print("<select name='databases'>");*/
    while ($row = $statement->fetch()) {
        $databases[] = $row['Database'];
        //print ("<option value='" . $row['Database'] . "'>" . $row['Database'] . "</option>");
    }/*
    print("</select>");
    print("</form>");*/
} catch (PDOException $exception) {
    print('Exception: ' . $exception->getMessage());
}
$pdo = null;
?>

<form>
    <label>Databank </label>
    <select name="DatabaseInput">
        <?php
        for($i=0;$i<count($databases); $i++) {
            print ("<option value='" . $databases[$i] . "'>" . $databases[$i] . "</option>");
        }
        ?>
    </select><br/>
    <p>SQL-QUERY (drop, delete en truncate niet toegelaten)</p>
    <textarea name="naam" cols="48" rows="5">
    </textarea>
    <br/>
    <button formmethod="get" name="clickButton" formaction="verwerking.php">click me</button>
</form>
</body>
</html>

