<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Les3 PDO Oef2</title>
    <style>
        a {
            text-decoration: none;
            color: #FFFFFF;
        }
        nav {
            padding-left: 10px;
            background: dimgrey;
            color: #FFFFFF;
            font-family: Arial;
        }
        nav a{
            display: inline-block;
            padding: 5px;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        nav a:hover {
            background: darkgreen;
            text-decoration: none;
        }
        table {
            border: solid black 1px;
        }
        td {
            border: solid black 1px;
        }
        th {
            background: gold;
            color: navy;
            border: solid black 1px;
        }
    </style>
</head>
<body>
<nav>
    <a href="overzicht.php">Overzicht</a>
    <a href="toevoegen.php">Toevoegen</a>
    <a href="wijzig.php">Wijzig</a>
    <a href="verwijder.php">Verwijder</a>
</nav>
<main>
    <form>
        <label>Geef hier het id van de persoon die je wilt wijzigen: </label>
        <input name="Id" type="number"><br/>
        <label>Geef hier de nieuwe naam in: </label>
        <input name="Naam" type="text"><br>
        <button formaction="change.php" formmethod="get">confirm</button>
    </form>
    <?php
    /**
     * Created by PhpStorm.
     * User: Toon
     * Date: 4/03/2019
     * Time: 15:09
     */
    $query = "Select * from gebruikers";
    $user = 'root';
    $password = 'root';
    $database = "Oefeningen week 3 PDO";
    $pdo = null;
    if ((stristr($query, "drop") === false and stristr($query, "truncate") === false and stristr($query, "delete") === false)) {
        try {
            $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $statement = $pdo->query($query);
            $statement->setFetchMode(PDO::FETCH_ASSOC);


            if ($statement->rowCount() > 0) {
                $columnNames = [];
                for($i=0; $i < $statement->columnCount(); $i++) {
                    $columnData = $statement->getColumnMeta($i);
                    $columnName = $columnData['name'];
                    $columnNames[] = $columnName;
                }
                print("<table>");
                print('<tr><th>' . implode('</th><th>', $columnNames) . '</th></tr>');
                while ($row = $statement->fetch()) {
                    print('<tr><td>' . implode("</td><td>", $row) . '</td></tr>');
                    //print ('<br/>');
                }
                print("</table>");
            }


        } catch (PDOException $exception) {
            print ('Exception: ' . $exception->getMessage());
        }
        $pdo = null;
    } else {
        print("VERKEERDE QUERRY!!!");
    }
    ?>
</main>
</body>
</html>