<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 4/03/2019
 * Time: 15:53
 */

$Id = $_GET['Id'];

$query = "DELETE FROM `gebruikers` WHERE Id = ?";
$user = 'root';
$password = 'root';
$database = "Oefeningen week 3 PDO";
try {
    $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement = $pdo->prepare($query);
    $statement->bindParam(1, $Id, PDO::PARAM_INT);
    $nr = $statement->execute();
    print("$nr rows deleted");
    print("<a href='overzicht.php' style='padding: 5px; padding-top: 10px; padding-bottom: 10px;'>Terug naar overzicht</a>");
} catch (PDOException $exception) {
    print ('Exception: ' . $exception->getMessage());
}
$pdo = null;