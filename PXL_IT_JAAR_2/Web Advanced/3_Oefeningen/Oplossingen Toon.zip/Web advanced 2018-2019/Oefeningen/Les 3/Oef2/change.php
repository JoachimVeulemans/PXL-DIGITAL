<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 4/03/2019
 * Time: 15:53
 */

$Id = $_GET['Id'];
$name = $_GET['Naam'];

$query = "UPDATE `gebruikers` SET `Naam` = ? WHERE `Id` = ?";
$user = 'root';
$password = 'root';
$database = "Oefeningen week 3 PDO";
try {
    $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $statement = $pdo->prepare($query);
    $statement->bindParam(2, $Id, PDO::PARAM_INT);
    $statement->bindParam(1, $name, PDO::PARAM_STR);
    $nr = $statement->execute();
    print("$nr rows modified");
    print("<a href='overzicht.php' style='padding: 5px; padding-top: 10px; padding-bottom: 10px;'>Terug naar overzicht</a>");
} catch (PDOException $exception) {
    print ('Exception: ' . $exception->getMessage());
}
$pdo = null;