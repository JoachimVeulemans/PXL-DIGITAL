<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 18/03/2019
 * Time: 14:19
 */

namespace accounting;

class Product {
    private $id;
    private $price;

    public function __construct(int $id, float $price)
    {
        if ($id < 0 || $price < 0){
            throw new \InvalidArgumentException("price or id was negative");
        } else {
            $this->id = $id;
            $this->price=$price;
        }
    }

    /**
     * @return mixed
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getPrice() :float
    {
        return $this->price;
    }



}