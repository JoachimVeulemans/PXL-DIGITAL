<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 18/03/2019
 * Time: 14:23
 */

namespace accounting;

class ShoppingCart implements PriceInterface {
    private $products;

    public function __construct()
    {
        $this->products = [];
        // sudo apt install php7.0-zip
        // composer require --dev phpunit/phpunit ^6
        // composer dump-autoload -o
        // vendor/bin/phpunit --bootstrap vendor/autoload.php test/accounting/TestProduct.php
        // vendor/bin/phpunit --bootstrap vendor/autoload.php test/accounting/TestShoppingCart.php
    }

    public function addProduct($product) {
        if ($product instanceof Product) {
            $this->products[] = $product;
        } else {
            throw new \InvalidArgumentException("This is not a product");
        }

    }

    public function productInCart($product){
        return in_array($product ,$this->products);
    }

    public function getProductCount() {
        return count($this->products);
    }

    public function calculatePrice(): float
    {
        $total = 0;
        foreach ($this->products as $item) {
            $total = $total + $item->price;
        }
        return $total;
    }
}