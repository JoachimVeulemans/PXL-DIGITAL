<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 18/03/2019
 * Time: 14:46
 */

use PHPUnit\Framework\TestCase;

class TestShoppingCart extends TestCase{

    public function invalidProductsProvider()
    {
        return [[-5], [null]];
    }

    public function validProductProvider()
    {
        return [[new \accounting\Product(5, 12.0)], [new \accounting\Product(1, 15.0)]];
    }

    public function validProductArrayProvider()
    {
        return [[new \accounting\Product(5, 12.0), new \accounting\Product(1, 15.0)], [new \accounting\Product(5, 19.0), new \accounting\Product(1, 19.0)]];
    }

    /**
     * @dataProvider invalidProductsProvider
     * @expectedException InvalidArgumentException
     */
    public function testAddProduct_invalidProduct_InvalidArgumentException($product) {
        $shoppingCart = new \accounting\ShoppingCart();
        $shoppingCart->addProduct($product);
    }

    /**
     * @dataProvider validProductProvider
     */
    public function testAddProduct_validProduct_isInArray($product) {
        $shoppingCart = new \accounting\ShoppingCart();
        $shoppingCart->addProduct($product);
        $this->assertTrue($shoppingCart->productInCart($product));
    }

    /**
     * @dataProvider validProductArrayProvider
     */
    public function testCalculatePrice_validProduct_totalPrice($productArray) {
        $shoppingCart = new \accounting\ShoppingCart();
        $total = 0;
        foreach ($productArray as $product) {
            $shoppingCart->addProduct($product);
            $total += $product->getPrice();
        }
        $this->assertEquals($total, $shoppingCart->calculatePrice());
    }
}