<?php
/**
 * Created by PhpStorm.
 * User: Toon
 * Date: 18/03/2019
 * Time: 14:08
 */

namespace accounting;

interface PriceInterface {
    public function calculatePrice(): float;
}