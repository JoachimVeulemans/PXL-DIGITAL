// Naam:  Benjamin Klingeleers


window.onload=Send;

function Send() {
    var buttonSend = document.getElementById("buttonclick");
    buttonSend.onclick=handleClick;
}


function handleClick(){

    var letters = document.getElementById("txtnaam").value;
    if(letters.match(/^[A-Za-z]+$/)) {
        const URL = 'http://192.168.33.22/examen/oefening4/telefoons.json';
        fetch(URL)
            .then( response => { response.json(); })
            .then( (data) => {  if (data.name.startsWith(letters)) {
                    writeOutput(data.name + " " + data.tel);
                } } )
            .catch((exception) => {
                writeOutput(exception);
            } );
    }
}


function writeOutput(text) {
    var textNode = document.createTextNode(text + "\n");
    var output = document.getElementById("divOutput");
    output.appendChild(textNode);
}



