<?php 
// Naam:  Benjamin Klingeleers
$user = 'root';
$password = 'root';

if(isset($_GET['submit_1'])){
?>
		<form action='app.php' method='get'>
<?php
			$database=$_GET['database'];
			$table=$_GET['table'];
		    $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
            $pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $databaseStatement = $pdo->query('DESCRIBE ' . $table);
            $databaseStatement->setFetchMode(PDO::FETCH_ASSOC);
            if($databaseStatement->rowCount() > 0) {
                while ($row = $databaseStatement->fetch()) {
                    print ('<input type="checkbox" name="column" value=' . $row['Field'] . ' > ' . $row['Field'] . ' </input>');
                }
            }
            print ('<input type="hidden" name="table" value="' . $table . '"/> ');
            print ('<input type="hidden" name="database" value="' . $database . '" /> ');



?>

			<input type='submit' name='submit_2'/>

		</form>

<?php
	}elseif(isset($_GET['submit_2'])){
			$database=$_GET['database'];
			$table=$_GET['table'];
			$columns=$_GET['column'];

             $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
             $pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
             $databaseStatement = $pdo->query('SELECT ' . $columns .  ' FROM ' . $table );
             $databaseStatement->setFetchMode(PDO::FETCH_ASSOC);
             if($databaseStatement->rowCount() > 0) {
                 while($row = $databaseStatement->fetch()) {
                     print ('<tr><td>' . implode('</td><td>', $row) . '</td></tr>');
                     print ('<br> </br>');
                 }
             }
			
}else{
?>
		<form action='app.php' method='get'>
			database:<input type='text' name='database'/><br/>
			table:<input type='text' name='table'/><br/>
			<input type='submit' name='submit_1'/>
		</form>
<?php
	}
?>
