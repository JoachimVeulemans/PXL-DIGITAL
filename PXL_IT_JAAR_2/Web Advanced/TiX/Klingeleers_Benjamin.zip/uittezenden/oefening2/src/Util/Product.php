<?php
// Naam: Benjamin Klingeleers
namespace Util;
class Product implements Comparable
{

    private $id;
    private $name;

public function __construct($id, $name){
  if (is_numeric($id) && $id > 0){
  if (is_string($name) && $name.length > 2){
$this->id = $id;
$this->name = $name;
} else {
    throw new InvalidArgumentException("Name klopt niet");
}

} else {
    throw new InvalidArgumentException("ID klopt niet");
}


}

public static function create($id, $name){
    return new self($id, $name);
}

public function getID(){
    return $this->id;
}

public function getName(){
    return $this->name;
}

public function equals(Comparable $other){
    $hulpvar = True;
    if ($other instanceof Product && $other . name === this . name) {
        return hulpvar;
    } else {
        $hulpvar = False;
        return hulpvar;
    }

}
}
