<?php
// Naam: Benjamin Klingeleers
namespace Util;
class Purchase{
  private $products;


  public function __construct(){
    $this->products = [];
  }

  public static function create (){
    return new self();
  }

  public function addProduct(Product $product){
    array_push($products, $product);
  }

  public function getNumberOfProducts() {
    return count($this->products);
  }

  public function getProductAt ($id)
  {
      if ($id < 0 && $id >= count($this->products) && is_int($id)) {
          return $this->products[$id];
      } else {
          throw InvalidArgumentException("ID klopt niet");
      }
  }


}
