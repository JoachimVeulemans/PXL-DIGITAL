// Naam: Gijs Claes
window.addEventListener("load", handleWindowLoad);

function handleWindowLoad() {
    let btn = document.getElementById("buttonclick");
    btn.addEventListener("click", handleClick);
}


function handleClick(){
    let letters = document.getElementById("txtnaam").value;
    if(letters.match(/^[A-Za-z]+$/)) {

        const URL = 'telefoons.json';
        fetch(URL)
            .then((response) => {
                return response.json();
            })
            .then((data) => {
                writeOutput(data);
            })
            .catch((exception) => {
                writeOutput("Exception:" + exception.toString())
            });

    }

}

function writeOutput(dataArray){
    let text = "";

    let letters = document.getElementById("txtnaam").value;
    dataArray.forEach( function (data) {
        if(data.name.startsWith(letters)){
            text += "<tr><td>" + data.name +"</td><td>" + data.tel +"</td></tr>";
        }
    });

    var output=document.getElementById("results");
    output.innerHTML = text;

}



