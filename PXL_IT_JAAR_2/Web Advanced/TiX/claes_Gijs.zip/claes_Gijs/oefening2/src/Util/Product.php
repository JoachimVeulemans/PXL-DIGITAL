<?php
// Naam: Gijs Claes
namespace Util;
use Prophecy\Exception\InvalidArgumentException;

class Product implements Comparable{

    private $price = 0.0;

    public function getPrice(): float
    {
        return $this->price;
    }

    public function getName(): string
    {
        return $this->name;
    }
    private $name = "";

    public function __construct($price, $name)
    {
        $this->price = $price;
        $this->name = $name;
    }

    public static function create($price, $name)
    {
        if(!is_numeric($price) || $price < 0.0 || !is_string($name) || strlen($name) < 2){
            throw new \InvalidArgumentException("er is een onjuiste waarde ingegeven (de prijs mag niet negatief zijn, de naam moet een string zijn van minstens 2 karaters)");
        }

        return new self($price, $name);
    }

    public function equals(Comparable $other){
        if((get_class($other) !== Product::class) && ($other !== $this)){
            return false;
        } else {
            return true;
        }
    }


}
