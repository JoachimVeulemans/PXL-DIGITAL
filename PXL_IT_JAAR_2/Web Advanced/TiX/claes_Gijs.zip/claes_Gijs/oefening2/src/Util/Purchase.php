<?php
// Naam: Gijs Claes
namespace Util;
use Prophecy\Exception\InvalidArgumentException;
use Util\Product;

class Purchase{
    private $products;

    public function __construct()
    {
        $this->products = [];
    }

    public static function create()
    {
        return new self();
    }

    public function addProduct(Product $product){
        array_push($this->products, $product);
    }

    public function getNumberOfProducts(){
        return count($this->products);
    }

    public function getProductAt($index){
        if(!is_integer($index) || ($index < 0) || ($index >= count($this->products))){
            throw new \InvalidArgumentException("foute index");
        }

        return $this->products[$index];
    }

    public function getTotalPrice() : int{
        $sum = 0;

        foreach ($this->products as $item){
            $sum += $item->getPrice();
        }

        return $sum;
    }
}


