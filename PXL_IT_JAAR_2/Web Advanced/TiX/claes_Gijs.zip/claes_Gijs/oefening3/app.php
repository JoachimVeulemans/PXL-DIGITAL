<?php
// Naam: 
$user = 'root';
$password = 'root';


if (isset($_GET['submit_1'])) {
    ?>
    <form action='app.php' method='get'>
        <?php
        $database = $_GET['database'];
        $table = $_GET['table'];

        $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $statement = $pdo->query("SELECT * FROM " . $table);
        $statement->setFetchMode(PDO::FETCH_ASSOC);

        $columnNames = [];
        for ($i = 0; $i < $statement->columnCount(); $i++) {
            $columnData = $statement->getColumnMeta($i);
            $columnName = $columnData['name'];
            $columnNames[] = $columnName;
        }

        foreach ($columnNames as $column) {
            print ($column . " <input type='checkbox' name='column[]' value='$column'>");
        }
        ?>
        <input type="hidden" name="database" value="<?php echo $database ?>">
        <input type="hidden" name="table" value="<?php echo $table ?>">
        <input type='submit' name='submit_2'/>
    </form>

    <?php
} elseif (isset($_GET['submit_2'])) {
    $database = $_GET['database'];
    $table = $_GET['table'];
    $columns = $_GET['column'];

    $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $queryText = join(', ' , $columns);

    $statement = $pdo->query("SELECT $queryText FROM $table");
    $statement->setFetchMode(PDO::FETCH_ASSOC);

    print("<table>");
    while($row = $statement->fetch()) {
        print('<tr><td>'.implode('</td><td>',$row).
            '</td></tr>');
    }
    print("</table>");

} else {
    ?>
    <form action='app.php' method='get'>
        database:<input type='text' name='database'/><br/>
        table:<input type='text' name='table'/><br/>
        <input type='submit' name='submit_1'/>
    </form>
    <?php
}
?>
