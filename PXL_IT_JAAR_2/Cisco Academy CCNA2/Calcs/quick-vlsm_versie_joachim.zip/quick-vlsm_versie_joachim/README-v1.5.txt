This is the fourth release of Quick-VLSM. The changes in this version are a check to make sure that a positive integer was entered for the number of addresses in a network and also, donation buttons were added to the different pages. I spent MANY hours making this tool and any financial help will be greatly appreciated if this tool helped you, so please donate!! Please e-mail me at lchanady@gmail.com with the subject "VLSM Calculator" with your feedback and/or any bugs you find. Also e-mail me if you use this to address a network and let me know if the network works when you are done. I am very much anticipating any feedback I can get and I would like to know if my hours of work on this project has helped anyone.

If you are a JavaScript programmer and have good knowledge of how VLSM works and you think you can make my program better or add more features, feel free to do so and then send the finished product to me and you will be listed as a co-developer of the project on the next release. I have absolutely no problem with anyone changing my program as long as you follow my 2 simple rules:

1. Please e-mail me with any changes you make.
2. Please do not advertise the program as your own after (or before) making the changes. If you would like your name on the project, simply e-mail me with the changes you have made, I will look over them, and if they are helpful, you will be listed as a co-developer on the project and given credit for your changes.

To Install:

Extract ALL files in the archive (the calculator will not work if run from within the archive, it must be extracted!) to a folder on the hard drive or a web server. Run index.htm to start. That's it! Have Fun.
