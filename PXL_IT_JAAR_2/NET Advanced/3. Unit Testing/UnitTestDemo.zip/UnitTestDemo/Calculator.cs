﻿using System;

namespace UnitTestDemo
{
    public class Calculator
    {
        public Calculator()
        {
        }

        public int Add(int a, int b)
        {
            if (a < 0 || b < 0)
            {
                throw new ArgumentException();
            }
            return a + b;
        }
    }
}
