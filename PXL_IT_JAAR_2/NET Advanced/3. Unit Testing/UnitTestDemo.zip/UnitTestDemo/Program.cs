﻿using System;

namespace UnitTestDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var calculator = new Calculator();
            Console.WriteLine($"1 + 3 = {calculator.Add(1, 3)}");
        }
    }
}
