use PXLForLifeDb
go
insert into Charities (name, description) values
('Mobile School', 'Mobile School is een organisatie die zich wereldwijd inzet voor straatkinderen. Wij ontwikkelen mobiele schoolkarretjes en verzorgen de opleiding van straathoekwerkers. Momenteel rijden er 51 mobiele schooltjes in 26 landen, verspreid over vier continenten: Latijns-Amerika, Azi�, Afrika en Europa.');
insert into Charities (name, description) values
('Open thuis Limburg vzw', 'Open Thuis vzw organiseert vrijetijds- en dagactiviteiten voor jongeren en volwassenen met een beperking en kansengroepen. Wekelijks gaan een 70-tal deelnemers gedurende een halve of hele dag aan de slag op activiteitenboerderij De Akkerboom of het Prisma A�telier.');
insert into Charities (name, description) values
('Menno''s Droom', 'Onze organisatie zet zich in voor gezinnen, die met kanker bij een kind geconfronteerd worden. Menno�s Droom biedt een onvergetelijke verwenvakantie aan gezinnen met een kind met kanker. Voor kinderen... die even aan iets anders willen denken dan hun ''ziek zijn''. Voor broers en zusjes... die samen willenspelen, lachen en verrast worden. Voor ouders... die er even onbezorgd tussenuit willen. Voor gezinnen... die samen even alles willen vergeten, verwend worden en vooral... ontspannen.');
insert into Charities (name, description) values
('Firefighters 4 Nepal', 'Firefighters 4 Nepal (F4N) is een VZW van Belgische brandweermannen die zich inzet voor hun collega''s in Nepal. Zij moet het stellen met sterk verouderd of ontbrekend materiaal en geen opleiding. F4N Voorziet hen in tweedehands moderner materiaal en opleiding op Belgisch niveau. Om dit nog duurzamer te maken voorzien de Belgische brandweermannen in instructeursopleidingen zodat de Nepalese brandweermannen meer en meer zelfstandig kunnen instaan voor alles.');
insert into Charities (name, description) values
('Brothers Of Solidarity','Brothers Of Solidarity is een vzw die zich inzet voor de Belgische daklozen ongeacht hun nationaliteit. Alle zondagen bereiden wij een verse maaltijd, die we dan uitdelen in Brussel. Ook voorzien wij hen van de nodige verzorgingsproducten en kledij. Wekelijks maken wij voedselpakketten voor mensen die te kampen hebben met financi�le problemen.');
insert into Charities (name, description) values
('Pleegzorg Limburg vzw','Ook dicht bij ons zijn er kinderen en jongeren of volwassenen met een beperking die het moeilijk hebben. Vaak omdat hun ouders voor korte of lange tijd niet voor hen kunnen zorgen. Pleeggezinnen geven hen een nieuwe thuis. Daar kunnen ze vooral zichzelf zijn en krijgen ze de kans om te groeien richting toekomst. Pleegzorg bestaat in veel verschillende vormen. Als pleeggezin kan je niet alleen kinderen of jongeren opvangen. Ook pleeggasten, volwassenen met een beperking of een psychiatrische problematiek, kunnen terecht bij gastgezinnen. www.pleegzorglimburg.be');

insert into Cities (ZipId, CityName)
values(9100, 'Sint-Niklaas');
insert into Cities (ZipId, CityName)
values(3600,'Genk');
insert into Cities (ZipId, CityName)
values(3000,'Leuven');
insert into Cities (ZipId, CityName)
values(3971,'Heppen');
insert into Cities (ZipId, CityName)
values(3500,'Hasselt');
insert into Cities(ZipId, CityName)
values(2320,'Hoogstraten');

insert into actions(name,date,cityId,CharityId,Yield)
values('Duwmee',CAST('2018-12/18' As datetime),(select Id from Cities where CityName='Sint-Niklaas'),1,15000);
insert into actions(name,date,cityId,CharityId,Yield)
values('Brunch for mobile school',CAST('2018-11-18' as datetime),(select Id from Cities where CityName='Sint-Niklaas'),1,2500);
insert into actions(name,date,cityId,CharityId,Yield)
values('Gitaardeuntjes for mobile school',CAST('2018-12-16' as datetime),(select Id from Cities where CityName='Leuven'),1,850);
insert into actions(name,date,cityId,CharityId,Yield)
values('Mater dei genk draagt zorg voor pleegzorg',CAST('2018-12-13' as datetime),(select Id from Cities where CityName='Genk'),6,1200);
insert into actions(name,date,cityId,CharityId,Yield)
values('Care for a home',CAST('2018-09-23' as datetime),(select Id from Cities where CityName='Heppen'),6,1750);
insert into actions(name,date,cityId,CharityId,Yield)
values('Kaarsen voor Menno door Trixxo Hasselt',CAST('2018-12-06' as datetime),(select Id from Cities where CityName='Hasselt'),3,3480);
insert into actions(name,date,cityId,CharityId,Yield)
values('Snoepen voor Menno''s droom',CAST('2018-12-15' as datetime),(select Id from Cities where CityName='Hasselt'),3,1950);
insert into actions(name,date,cityId,CharityId,Yield)
values('Zwemmathon',CAST('2018-11-24' as datetime),(select Id from Cities where CityName='Hoogstraten'),3,5820);






