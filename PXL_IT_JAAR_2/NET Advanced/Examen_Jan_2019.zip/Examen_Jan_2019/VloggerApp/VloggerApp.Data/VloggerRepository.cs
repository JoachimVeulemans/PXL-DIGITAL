﻿using System.Collections.Generic;
using System.Data.SqlClient;
using VloggerApp.Data.DomainClasses;
using VloggerApp.Data.Interfaces;

namespace VloggerApp.Data
{
    public class VloggerRepository : IVloggerRepository
    {
        private IConnectionFactory connectionFactory;

        public VloggerRepository(IConnectionFactory connectionFactory)
        {
            this.connectionFactory = connectionFactory;
        }

        public IList<Vlogger> FindVloggers(int minimumNumberOfFollowers, string searchTerm)
        {
            //TODO: find the vloggers that match the search criteria (paramaters)
            //Only vloggers with a number of followers >= minimumNumberOfFollowers are returned
            //Only vloggers who's name or real name contains the searchTerm are returned (Tip: WHERE column LIKE ‘%someSearchTerm%’)
            //Avoid SQL injection
            //Performance is important
            var vloggers = new List<Vlogger>();

            SqlConnection connection = connectionFactory.CreateSqlConnection();
            string selectStatement = "SELECT * FROM dbo.Vloggers " +
                                     "WHERE (Name LIKE '%' + @searchTerm + '%' " +
                                     "OR RealName LIKE '%' + @searchTerm + '%') " +
                                     "AND NumberOfFollowers > @minimumNumberOfFollowers";
            var selectCommand = new SqlCommand(selectStatement, connection);

            selectCommand.Parameters.AddWithValue("@searchTerm", searchTerm);
            selectCommand.Parameters.AddWithValue("@minimumNumberOfFollowers", minimumNumberOfFollowers);

            SqlDataReader reader = null;
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();

                int idOrdinal = reader.GetOrdinal("Id");
                int nameOrdinal = reader.GetOrdinal("Name");
                int realNameOrdinal = reader.GetOrdinal("RealName");
                int descriptionOrdinal = reader.GetOrdinal("Description");
                int numberOfFollowersOrdinal = reader.GetOrdinal("NumberOfFollowers");

                while (reader.Read())
                {
                    var vlogger = new Vlogger()
                    {
                        Id = reader.IsDBNull(idOrdinal) ? int.MinValue : reader.GetInt32(idOrdinal),
                        Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                        RealName = reader.IsDBNull(realNameOrdinal) ? null : reader.GetString(realNameOrdinal),
                        Description = reader.IsDBNull(descriptionOrdinal) ? null : reader.GetString(descriptionOrdinal),
                        NumberOfFollowers = reader.IsDBNull(numberOfFollowersOrdinal) ? int.MinValue : reader.GetInt32(numberOfFollowersOrdinal)
                    };
                    vloggers.Add(vlogger);
                }

            }
            finally
            {
                connection?.Close();
                reader?.Close();
            }

            return vloggers;
        }
    }
}