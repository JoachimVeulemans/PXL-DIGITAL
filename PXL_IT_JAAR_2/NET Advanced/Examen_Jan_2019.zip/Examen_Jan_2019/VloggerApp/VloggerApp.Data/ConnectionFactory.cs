﻿using System.Configuration;
using System.Data.SqlClient;
using VloggerApp.Data.Interfaces;

namespace VloggerApp.Data
{
    public class ConnectionFactory : IConnectionFactory
    {
        public SqlConnection CreateSqlConnection()
        {
            //TODO: create a SqlConnection instance that uses a "VloggerConnection" connection string from the app.config of the UI
            return new SqlConnection(ConfigurationManager.ConnectionStrings["VloggerDBConnection"].ConnectionString);
        }
    }
}
