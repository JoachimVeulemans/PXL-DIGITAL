﻿using System.Data.SqlClient;

namespace VloggerApp.Data.Interfaces
{
    public interface IConnectionFactory
    {
        SqlConnection CreateSqlConnection();
    }
}