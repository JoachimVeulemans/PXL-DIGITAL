﻿using System.Collections.Generic;
using VloggerApp.Data.DomainClasses;

namespace VloggerApp.Data.Interfaces
{
    public interface IVloggerRepository
    {
        IList<Vlogger> FindVloggers(int minimumNumberOfFollowers, string searchTerm);
    }
}