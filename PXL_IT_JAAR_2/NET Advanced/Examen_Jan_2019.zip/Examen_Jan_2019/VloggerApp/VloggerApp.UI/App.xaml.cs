﻿using System.Windows;
using VloggerApp.Data;

namespace VloggerApp.UI
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            var connectionFactory = new ConnectionFactory();
            var vloggerRepository = new VloggerRepository(connectionFactory);

            var mainWindow = new MainWindow(vloggerRepository);
            mainWindow.Show();
        }
    }
}
