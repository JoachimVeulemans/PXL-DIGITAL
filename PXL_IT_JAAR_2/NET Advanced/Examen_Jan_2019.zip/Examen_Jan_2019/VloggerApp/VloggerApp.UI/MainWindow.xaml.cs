﻿using System;
using System.Windows;
using VloggerApp.Data.Interfaces;

namespace VloggerApp.UI
{
    public partial class MainWindow : Window
    {
        private IVloggerRepository vloggerRepository;

        public MainWindow(IVloggerRepository vloggerRepository)
        {
            this.vloggerRepository = vloggerRepository;

            InitializeComponent();
        }

        private void FindVloggersButton_Click(object sender, RoutedEventArgs e)
        {
            int numberOfFollowers = 0;
            //TODO: retrieve the matching vloggers and make them the datasource of the ListView
            if (!NumberOfFollowersTextBox.Text.Equals(""))
            {
                numberOfFollowers = Convert.ToInt32(NumberOfFollowersTextBox.Text);
            }

            string searchTerm = SearchTextBox.Text;
            VloggersListView.ItemsSource = vloggerRepository.FindVloggers(numberOfFollowers, searchTerm);
        }
    }
}
