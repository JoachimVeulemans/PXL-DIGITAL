﻿using System;
using NUnit.Framework;
using VloggerApp.UI.Converters;

namespace VloggerApp.Tests
{
    [TestFixture]
    public class EnsureTextConverterTests
    {
        private EnsureTextConverter sut;

        [SetUp]
        public void SetUpFizzBuzzService()
        {
            sut = new EnsureTextConverter();
        }

        [Test]
        public void ConvertShouldDoNothingWithANonEmptyValue()
        {
            //Arrange
            var value = Guid.NewGuid().ToString();

            //Act
            var result = sut.Convert(value, null, null, null);

            //Assert
            Assert.That(result, Is.EqualTo(value));
        }

        [TestCase("")]
        [TestCase(null)]

        [Test]
        public void ConvertShouldReturn3QuestionMarksWhenValueIsNullOrEmpty(string emptyValue)
        {
            //Arrange

            //Act
            var result = sut.Convert(emptyValue, null, null, null);

            //Assert
            Assert.That(result, Is.EqualTo("???"));
        }
    }
}
