﻿/* Check if database already exists and delete it if it does exist*/
IF EXISTS(SELECT 1 FROM master.dbo.sysdatabases WHERE name = 'VloggerDb') 
BEGIN
DROP DATABASE VloggerDb
END
GO

CREATE DATABASE VloggerDb
GO

USE VloggerDb
GO

CREATE TABLE [dbo].[Vloggers] (
    [Id] INT IDENTITY (1, 1) NOT NULL,
	[Name] NVARCHAR(max) NOT NULL,
    [RealName] NVARCHAR(max) NULL,
    [Description] NVARCHAR(max) NULL,
    [NumberOfFollowers] INT NOT NULL
);

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'PewDiePie', N'Felix Arvid Ulf Kjellberg', N'Irritante Zweed (25) die games becommentarieert met een luid, hees stemmetje. Ondertussen doet hij ook andere dingen, zoals zijn borsthaar ontharen met Veet.', 77322635)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'Acid ', null, N'De populairste Vlaamse Vlogger is de West-Vlaamse Nathan. Hij vlogt dagelijks onder de naam Acid. School en Youtube combineren blijkt dat goed te lukken want Nathan gaat richting de 199.000 abonnees. Mocht hij voor elke abonnee een euro krijgen…', 198362)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'Zaka', N'Ben Zakaria', N'Maakte drie jaar geleden zijn eerste filmpje over de ramadan, en zit intussen al aan meer dan 45.000 abonnees. ', 45001)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'UP2D8', null, N'Samir, jongeman met blauw haar, overloopt snel en flitsend het internetnieuws van de week. De ideale schoonzoon van de vlogwereld. Spreekt tenminste een beetje AN.', 28398)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'Achterklap', N'Ergin Arslanbas', N'Ergin, een Limburger met Turks-Italiaanse roots en rebel van de Vlaamse vlogwereld. Lacht je uit met je Facebook-profiel. Gaat ook vaak op stap naar verlaten gebouwen.', 94007)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'Waddupitskev', null, N'Kevser, Vlaamse Turkse die jongeren en moslims bekijkt door een funny bril. Gaat nu ook internationaal, want is begonnen in het Engels.', 12314)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'Unagize ', N'Rayan Aghassaiy', N'Zijn Youtube-kanaal Unagize staat vol video’s met uitdagende en aantrekkelijke titels. ', 176848)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'Kastiop ', N'Kacper Przybylski', N'Doet zowat alles op zijn Youtube-kanaal Kastiop. “Ik maak vlogs, praatvideo’s, challenges, Q&A’s en nog meer gekke shizzle”, zoals Kacper het zelf zegt.', 124459)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'Lifestylespot ', N'Pauline Rensonnet', N'Vlogt over lifestyle en mode. De studente communicatiemanagement van Thomas More is niet alleen actief op Youtube, ze houdt alles wat ze doet ook bij op haar blog.', 30245)

INSERT INTO [dbo].[Vloggers] ([Name],[RealName],[Description],[NumberOfFollowers])
VALUES (N'EnzoKnol', null, N'Een Nederlandstalige vlogger op YouTube en stemacteur. Zijn vaste publiek bestaat voornamelijk uit tieners.', 2094509)
