﻿using System;

namespace PXLForLife.Domain
{
    public class Action
    {
        /* TODO: Add your code here */
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public int CityId { get; set; }
        public int CharityId { get; set; }
        public decimal Yield { get; set; }

    }
}
