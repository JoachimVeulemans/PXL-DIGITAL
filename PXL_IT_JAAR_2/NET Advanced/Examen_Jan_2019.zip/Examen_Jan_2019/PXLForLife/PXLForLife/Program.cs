﻿using Microsoft.EntityFrameworkCore;
using PXLForLife.Data;
using PXLForLife.Domain;
using System;
using System.Linq;
using Action = PXLForLife.Domain.Action;

namespace PXLForLife
{
    class Program
    {
        private static PXLForLifeContext context;

        static void Main(string[] args)
        {
            /* TODO: Migrate the database */
            context = new PXLForLifeContext();
            context.CreateOrUpdateDatabase();

            GetTotalOfAllActionsGroupedByCharity();

            Console.ReadLine();
        }

        private static void GetTotalOfAllActionsGroupedByCharity()
        {
            /* TODO: Create a query that retrieved all actions grouped by charity
               TODO: Call the PrintActionsOfCharity method for each group of actions
             */
            var allActions = context.actions.ToList();
            var allCharities = context.charities.ToList();

            var actionsGroupedByCharity = from action in allActions
                join charity in allCharities on action.CharityId equals charity.Id
                orderby charity.Id
                group action by charity
                into actionsGroup
                select new
                {
                    Actions = actionsGroup
                };

            foreach (var charity in actionsGroupedByCharity)
            {
                PrintActionsOfCharity(charity.Actions);
            }

        }

        private static void PrintActionsOfCharity(IGrouping<Charity, Action> actionsOfCharity)
        {
            /* TODO: Uncomment the code below
               TODO: Use the Linq extension method 'Sum' to calculate the total yield for a charity
             */

            var charity = actionsOfCharity.Key;
            Console.WriteLine($"Key: {charity.Id} - Name: {charity.Name}");
            Console.WriteLine(charity.Description);
            Console.WriteLine();

            foreach (var action in actionsOfCharity)
            {
                Console.WriteLine($"\t{action.Date.ToShortDateString()}: {action.Name} : {action.Yield} euro");
            }

            Console.WriteLine();

            var totalYield = actionsOfCharity.Sum(a => a.Yield);
            Console.WriteLine($"Total Yield:  {totalYield}");
            Console.WriteLine();
        }
    }
}