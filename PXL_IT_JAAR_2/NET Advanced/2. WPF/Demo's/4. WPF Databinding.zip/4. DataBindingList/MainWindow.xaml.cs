﻿using System.Windows;

namespace DataBindingList
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly EmployeeRepository _employeeRepository;

        public MainWindow()
        {
            InitializeComponent();
            _employeeRepository = new EmployeeRepository();
            employeesComboBox.ItemsSource = _employeeRepository.GetAll();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            _employeeRepository.DeleteLast();                
        }
    }
}
