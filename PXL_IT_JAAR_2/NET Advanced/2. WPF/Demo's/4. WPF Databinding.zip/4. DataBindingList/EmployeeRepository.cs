﻿using System.Collections.ObjectModel;

namespace DataBindingList
{
    public class EmployeeRepository
    {
        private readonly ObservableCollection<Employee> _allEmployees;

        public EmployeeRepository()
        {
            _allEmployees = new ObservableCollection<Employee>();
            _allEmployees.Add(new Employee() { Name = "Washington", Title = "President 1" });
            _allEmployees.Add(new Employee() { Name = "Adams", Title = "President 2" });
            _allEmployees.Add(new Employee() { Name = "Jefferson", Title = "President 3" });
            _allEmployees.Add(new Employee() { Name = "Madison", Title = "President 4" });
            _allEmployees.Add(new Employee() { Name = "Monroe", Title = "President 5" });
        }

        public ObservableCollection<Employee> GetAll()
        {
            return _allEmployees;
        }

        public void DeleteLast()
        {
            if (_allEmployees.Count > 0)
            {
                _allEmployees.RemoveAt(_allEmployees.Count - 1);
            }
        } 
    }
}
