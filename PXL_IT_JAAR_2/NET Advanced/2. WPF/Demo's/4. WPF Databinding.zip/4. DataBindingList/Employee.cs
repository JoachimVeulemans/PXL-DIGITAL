﻿namespace DataBindingList
{
    public class Employee
    {
        public string Name { get; set; }

        public string Title { get; set; }
    }
}
