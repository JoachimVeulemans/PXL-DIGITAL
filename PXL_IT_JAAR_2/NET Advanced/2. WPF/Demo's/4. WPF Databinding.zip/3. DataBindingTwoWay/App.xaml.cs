﻿using System.Windows;

namespace DataBindingTwoWay
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
