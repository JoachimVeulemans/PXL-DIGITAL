﻿using System.Windows;

namespace DataBindingTwoWay
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly Employee _displayedEmployee;
        public MainWindow()
        {            
            InitializeComponent();
            _displayedEmployee = new Employee()
            {
                Name = "Joe",
                Title = "QA"
            };
            DataContext = _displayedEmployee;
        }
    }
}
