﻿namespace DataBindingOneWay
{
    public class Employee
    {
        public string Name { get; set; }
        public string Title { get; set; }

        public static Employee CreateSomeEmployee()
        {
            var someEmployee = new Employee()
            {
                Name = "Tom",
                Title = "Developer"
            };
            return someEmployee;
        }
    }
}
