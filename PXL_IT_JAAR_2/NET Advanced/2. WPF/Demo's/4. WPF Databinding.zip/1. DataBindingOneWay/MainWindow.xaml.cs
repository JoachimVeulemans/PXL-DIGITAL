﻿using System.Windows;

namespace DataBindingOneWay
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
            //set the DataContext of the MainWindow
            this.DataContext = Employee.CreateSomeEmployee();
        }
    }
}
