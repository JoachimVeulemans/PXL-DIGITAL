﻿using System;
using System.Windows;

namespace DataConverter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Employee displayedEmployee = new Employee("Jesse", "Evangelist", new DateTime(2001, 7, 10));
            DataContext = displayedEmployee;
        }
    }
}
