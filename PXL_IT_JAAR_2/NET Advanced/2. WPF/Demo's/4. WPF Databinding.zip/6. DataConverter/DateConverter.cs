﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace DataConverter
{
    class DateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            DateTime date = (DateTime)value;
            return date.ToString("dd/MM/yyyy");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string dateAsText = value as String;
            DateTime date;
            if (DateTime.TryParseExact(dateAsText, "dd/MM/yyyy", culture, DateTimeStyles.None, out date))
            {
                return date;
            }
            throw new Exception("Unable to convert string to date time");
        }
    }
}
