﻿using System.Windows;

namespace INPCDemo
{
    public partial class MainWindow : Window
    {
        private readonly Employee _displayedEmployee;

        public MainWindow()
        {
            InitializeComponent();
            _displayedEmployee = new Employee()
            {
                Name = "Joe",
                Title = "QA"
            };
            DataContext = _displayedEmployee;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _displayedEmployee.Name = "Jesse";
            _displayedEmployee.Title = "Evangelist";
        }
    }
}
