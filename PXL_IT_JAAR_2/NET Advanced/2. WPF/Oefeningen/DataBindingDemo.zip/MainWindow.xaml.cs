﻿using System.Windows;

namespace DataBindingDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Employee _employee;

        public MainWindow()
        {
            InitializeComponent();

            _employee = Employee.CreateSomEmployee();
            this.DataContext = _employee;
        }

        private void PromoteButton_Click(object sender, RoutedEventArgs e)
        {
            _employee.Title = "Manager";
        }
    }
}
