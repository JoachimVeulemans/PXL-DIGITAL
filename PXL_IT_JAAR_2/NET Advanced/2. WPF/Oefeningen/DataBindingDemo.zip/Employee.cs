﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace DataBindingDemo
{
    public class Employee : INotifyPropertyChanged
    {
        private string _title;

        public string Name { get; set; }
        public string Title
        {
            get => _title;
            set
            {
                if (_title == value) return;
                _title = value;
                // OnPropertyChanged(nameof(Title));
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public static Employee CreateSomEmployee()
        {
            return new Employee
            {
                Name = "John",
                Title = "Developer"
            };
        }
    }
}
