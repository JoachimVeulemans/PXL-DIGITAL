﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Layout_Oef6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void changeColorButton_Click(object sender, RoutedEventArgs e)
        {
            //de linkerbovenrechthoek krijgt dezelfde kleur als de rechterrechthoek
            firstRectangle.Fill = secondRectangle.Fill;
        }

        private void narrowWindowButton_Click(object sender, RoutedEventArgs e)
        {
            //het ganse venster versmalt, de rechthoeken… versmallen mee, in de status balk wordt de breedte van het venster getoond.
            if (!(this.Width - 10 < 0) && !(this.Height - 10 < 0))
            {
                this.Width -= 10;
                this.Height -= 10;
            }
            statusBarTextBlock.Text = "De breedte is momenteel: " + Convert.ToString(this.Width);
        }

        private void removeRectanglesButton_Click(object sender, RoutedEventArgs e)
        {
            // de rechthoeken verdwijnen van het scherm.
            innerGrid.Children.Clear();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            // SHOW creators
            MessageBox.Show("Created by Ian Angillis & Joachim Veulemans");
            statusBarTextBlock.Text = "Created by Ian Angillis & Joachim Veulemans";
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
