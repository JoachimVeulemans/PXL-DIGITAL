﻿using Movies.Domainclasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Movies.Datalayer;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;

namespace Movies
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MovieRepository _repo;  //Use this repository to access the data

        
        public MainWindow()
        {
            InitializeComponent();

            _repo = new MovieRepository();

            //TODO: use databinding to show all movies in the combobox
            
            movieComboBox.ItemsSource = _repo.GetAllMovies();
            
        }

        private void MovieSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //This event happens when a new movie is selected from the combobox
            //TODO: show info about the director
            directorNameTextBlock.DataContext = _repo.GetDirectorOfMovie(movieComboBox.SelectedIndex);
            //TODO: show the actors of the movie
            actorsListView.ItemsSource = _repo.GetAllActorsInMovie(movieComboBox.SelectedIndex);
        }

        private void CreateMovie(object sender, RoutedEventArgs e)
        {
            //This event happens when the user clicks the "Create Movie" button
            //TODO: open an instance of the movie creation window
            MovieCreationWindow movieCreationWindow = new MovieCreationWindow(_repo);
            movieCreationWindow.Show();
            
        }

    }
}
