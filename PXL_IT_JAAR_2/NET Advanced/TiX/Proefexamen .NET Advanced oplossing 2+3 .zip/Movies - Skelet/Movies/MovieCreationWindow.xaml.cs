﻿using Movies.Domainclasses;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Movies.Datalayer;
using System.ComponentModel;

namespace Movies
{
    /// <summary>
    /// Interaction logic for MovieCreationWindow.xaml
    /// </summary>
    public partial class MovieCreationWindow : Window
    {
        MovieRepository _repo;
        private ObservableCollection<Actor> actorsInMovie = new ObservableCollection<Actor>();



        public MovieCreationWindow(MovieRepository repo)
        {
            InitializeComponent();

            _repo = repo;
            //TODO: fill director combobox with all directors
            directorComboBox.ItemsSource = _repo.GetAllDirectors();
            directorComboBox.DisplayMemberPath = "FullName";
            //TODO: fill actor combobox with all actors
            actorComboBox.ItemsSource = _repo.GetAllActors();
            actorComboBox.DisplayMemberPath = "FullName";
            actorListView.ItemsSource = actorsInMovie;
        }
        

        private void AddMovie(object sender, RoutedEventArgs e)
        {
            //This event happens when the user clicks the "Add Movie" button
            //TODO: build an instance of a movie and add it to the database
            Movie movie = CreateMovie();
            _repo.AddMovie(movie);
            //TODO: make sure the main window refreshes its list of movies
            _repo.Dispose();
            Close();
            MainWindow w = new MainWindow(); //nieuw MainWindow starten om nieuwe data te laden, geen ideale oplossing
            w.Show();
        }

        private void AddActor(object sender, RoutedEventArgs e)
        {
            //This event happens when the user clicks the "Add Actor" button.
            //TODO: add the chosen actor to the list of actors for this movie.
            actorsInMovie.Add((Actor)actorComboBox.SelectedItem);
        }

        private Movie CreateMovie()
        {
            Movie movie = new Movie { Title = movieTitleTextBox.Text, Cast = actorsInMovie, Director = (Director)directorComboBox.SelectedItem };
            return movie;
        }
    }

}
