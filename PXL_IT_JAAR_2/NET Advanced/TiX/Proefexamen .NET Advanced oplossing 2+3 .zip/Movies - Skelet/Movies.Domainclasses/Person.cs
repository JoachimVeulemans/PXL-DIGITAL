﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movies.Domainclasses
{
    public class Person
    {
        //Your code here
        public int Id { get; set; }
        public string FullName { get; set; }
    }
}
