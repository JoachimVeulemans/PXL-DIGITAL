﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Movies.Domainclasses
{
    public class Movie : INotifyPropertyChanged
    {
        //Your code here
        private ICollection<Actor> _cast;

        public int Id { get; set; }
        public string Title { get; set; }
        public virtual Director Director { get; set; }

        public virtual ICollection<Actor> Cast
        {
            get => _cast;
            set => _cast = value;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string caller = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(caller));
            }

        }
    }
}
