﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movies.Domainclasses
{
    public class Director : Person
    {
        //Your code here
        private ICollection<Movie> _movies;


        public virtual ICollection<Movie> Movies
        {
            get => _movies;
            set => _movies = value;
        }
    }
}
