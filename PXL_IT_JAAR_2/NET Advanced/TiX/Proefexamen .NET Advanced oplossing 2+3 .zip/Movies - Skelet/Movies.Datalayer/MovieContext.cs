﻿using Movies.Domainclasses;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movies.Datalayer
{
    public class MovieContext : DbContext
    {
        public MovieContext()
        {
            Database.Log = (message) => { Debug.WriteLine(message); }; //logs generated SQL by EF in the Debug output
            Database.SetInitializer(new MovieDBInitializer());
        }
        //TODO: Your code here
        public DbSet<Actor> Actors { get; set; }
        public DbSet<Director> Directors { get; set; }
        public DbSet<Movie> Movies { get; set; }
        //public DbSet<Person> Persons { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Movie>().HasRequired(d => d.Director).WithMany(d => d.Movies);
            modelBuilder.Entity<Movie>().HasMany(a => a.Cast).WithMany(t => t.Movies);
            base.OnModelCreating(modelBuilder);
        }

    }

    

}

