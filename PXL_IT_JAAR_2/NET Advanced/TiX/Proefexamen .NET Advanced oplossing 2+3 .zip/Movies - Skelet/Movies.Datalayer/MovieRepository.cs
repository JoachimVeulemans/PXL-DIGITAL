﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Movies.Domainclasses;

namespace Movies.Datalayer
{
    public class MovieRepository
    {
        private MovieContext _dbContext;


        public MovieRepository()
        {
            _dbContext = new MovieContext();
        }

        public List<Movie> GetAllMovies()
        {
            //Your code here
            return _dbContext.Movies.ToList();
        }

        public Director GetDirectorOfMovie(int movieId)
        {
            //Your code here
            return GetAllMovies()[movieId].Director;
        }

        public List<Actor> GetAllActorsInMovie(int movieId)
        {
            //Your code here
            return GetAllMovies()[movieId].Cast.ToList();
        }

        public List<Director> GetAllDirectors()
        {
            //Your code here
            return _dbContext.Directors.ToList();
        }

        public List<Actor> GetAllActors()
        {
            //Your code here
            return _dbContext.Actors.ToList();
        }

        public void AddMovie(Movie movie)
        {
            //Your code here
            _dbContext.Movies.Add(movie);
            _dbContext.SaveChanges();
        }

        public void Dispose()
        {
            _dbContext.Dispose();
        }
    }
}
