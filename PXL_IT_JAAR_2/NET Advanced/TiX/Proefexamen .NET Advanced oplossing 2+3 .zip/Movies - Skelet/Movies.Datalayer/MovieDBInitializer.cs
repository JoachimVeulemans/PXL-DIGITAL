﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Movies.Domainclasses;

namespace Movies.Datalayer
{
    public class MovieDBInitializer:DropCreateDatabaseIfModelChanges<MovieContext>
    {
        protected override void Seed(MovieContext context)
        {
            List<Director> directors = new List<Director>()
            {
                new Director() {FullName="Martin Scorcese" },
                new Director() {FullName="David Fincher" }
            };

            List<Actor> actors = new List<Actor>()
            {
                new Actor() {FullName="Andrew Garfield" },
                new Actor() {FullName= "Leonardo Dicaprio" },
                new Actor() {FullName="Mark Ruffalo" }
            };

            //Create some movies
            List<Movie> movies = new List<Movie>()
            {
                new Movie() {Title="Silence",
                Cast = new List<Actor>() {actors[0] },
                Director = directors[0]
                },
                new Movie() {Title = "The Wolf of Wallstreet",
                Cast = new List<Actor>() {actors[1] },
                Director = directors[0]
                },
                new Movie() {Title = "Shutter Island",
                Cast = new List<Actor>() {actors[1], actors[2] },
                Director = directors[0]
                },
                new Movie() {Title="The Social Network",
                Cast = new List<Actor>() {actors[0] },
                Director = directors[1]}
            };
            foreach(Movie m in movies)
            {
                context.Movies.Add(m);
            }
            base.Seed(context);
        }
    }
}
