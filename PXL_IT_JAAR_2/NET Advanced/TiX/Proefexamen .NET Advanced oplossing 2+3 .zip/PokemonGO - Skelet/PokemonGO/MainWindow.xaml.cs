﻿using PokemonData;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PokemonGO
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Player _selectedPlayer;

        public MainWindow()
        {
            InitializeComponent();

            listOfPlayers.ItemsSource = PlayerRepository.GetPlayers();
            listOfPlayers.SelectedIndex = 0;
            testtextbox.Text = PlayerRepository.GetPlayers()[0].Name;
        }

        private void OnPlayerSelect(object sender, SelectionChangedEventArgs e)
        {
            //TODO: show the backpack (inventory) of the selected player in the inventory panel
            listOfPokemon.ItemsSource = PokemonRepository.GetPokemonFromPlayer(listOfPlayers.SelectedIndex + 1);
            inventoryPanel.DataContext = InventoryRepository.GetInventory(listOfPlayers.SelectedIndex + 1);
        }

        private void AddPokeball(object sender, RoutedEventArgs e)
        {
            //TODO: update number of pokeballs in backpack of the selected player
            InventoryRepository.UpdatePokeBalls(listOfPlayers.SelectedIndex + 1, 1);
            inventoryPanel.DataContext = InventoryRepository.GetInventory(listOfPlayers.SelectedIndex + 1);
        }

        private void RemovePokeball(object sender, RoutedEventArgs e)
        {
            //TODO: update number of pokeballs in backpack of the selected player
            InventoryRepository.UpdatePokeBalls(listOfPlayers.SelectedIndex + 1, -1);
            inventoryPanel.DataContext = InventoryRepository.GetInventory(listOfPlayers.SelectedIndex + 1);
        }
    }
}
