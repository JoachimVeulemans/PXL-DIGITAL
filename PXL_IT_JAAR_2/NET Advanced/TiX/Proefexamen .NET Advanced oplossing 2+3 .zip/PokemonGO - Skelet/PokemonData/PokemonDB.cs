﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonData
{
    public static class PokemonDB
    {
        //TODO: add your own connection string
        public static readonly string ConnectionString = "Data source=(localdb)\\MSSQLLocalDB; " + "Initial Catalog=PokemonGo; " + "Integrated Security=True";

        public static SqlConnection GetConnection()
        {               
            return new SqlConnection(ConnectionString);
        }
    }
}
