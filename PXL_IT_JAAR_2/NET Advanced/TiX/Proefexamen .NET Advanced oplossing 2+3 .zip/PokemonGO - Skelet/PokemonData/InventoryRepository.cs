﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonData
{
    public static class InventoryRepository
    {
        public static void UpdatePokeBalls(int inventoryId, int pokeballs)
        {
            //TODO: update the number of pokeballs for the inventory in the database
            SqlConnection connection = PokemonDB.GetConnection();
            string statement = "UPDATE PlayerInventories SET Pokeballs = Pokeballs +" + pokeballs + " WHERE Id = " + inventoryId;
            SqlCommand sqlCommand = new SqlCommand(statement, connection);
            connection.Open();
            sqlCommand.ExecuteNonQuery();
            connection.Close();
        }

        public static Inventory GetInventory(int playerId)
        {
            SqlConnection connection = PokemonDB.GetConnection();
            string statement = "SELECT * from PlayerInventories WHERE Owner = " + playerId;
            SqlCommand sqlCommand = new SqlCommand(statement,connection);
            Inventory inv = new Inventory();
            connection.Open();
            SqlDataReader reader = sqlCommand.ExecuteReader();
            reader.Read();
            inv.Id = reader.GetInt32(reader.GetOrdinal("Id"));
            inv.Owner = reader.GetInt32(reader.GetOrdinal("Owner"));
            inv.Pokeballs = reader.GetInt32(reader.GetOrdinal("Pokeballs"));
            inv.Lures = reader.GetInt32(reader.GetOrdinal("Lures"));
            inv.Coins = reader.GetInt32(reader.GetOrdinal("Coins"));
            return inv;
        }
    }
}
