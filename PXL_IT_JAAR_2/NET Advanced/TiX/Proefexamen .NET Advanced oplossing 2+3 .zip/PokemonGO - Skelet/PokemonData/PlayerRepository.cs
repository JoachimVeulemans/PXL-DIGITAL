﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonData
{
    public static class PlayerRepository
    {
        public static List<Player> GetPlayers()
        {
            //TODO: get a list of players from the database
            SqlConnection connection = PokemonDB.GetConnection();
            connection.Open();
            SqlCommand selectCommand = new SqlCommand();
            selectCommand.Connection = connection;
            string selectStatement = "SELECT Id, Name, Level, DateCreated FROM Players";
            selectCommand.CommandText = selectStatement;
            SqlDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            List<Player> playerList = new List<Player>();
            int dateOrd = reader.GetOrdinal("DateCreated");
            int lvlOrd = reader.GetOrdinal("Level");

            while (reader.Read())
            {
                Player player = new Player();
                player.Id = reader.GetOrdinal("Id");
                player.Name = reader["Name"].ToString();
                player.Level = reader.GetInt32(lvlOrd);
                player.DateCreated = reader.GetDateTime(dateOrd);
                playerList.Add(player);
            }
            reader.Close();
            connection.Close();
            return playerList;
        }
    }
}