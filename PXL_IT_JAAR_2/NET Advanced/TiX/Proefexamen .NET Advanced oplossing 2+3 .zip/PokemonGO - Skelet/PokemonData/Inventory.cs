﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PokemonData
{
    public class Inventory
    {
        public int Id { get; set; }
        public int Owner { get; set; }
        public int Pokeballs { get; set; }
        public int Lures { get; set; }
        public int Coins { get; set; }

        //TODO: Your code here
    }
}
