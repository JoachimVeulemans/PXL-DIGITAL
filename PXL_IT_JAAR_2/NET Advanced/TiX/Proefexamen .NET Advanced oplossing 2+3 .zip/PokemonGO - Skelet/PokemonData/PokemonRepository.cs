﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonData
{
    public static class PokemonRepository
    {
        public static List<Pokemon> GetPokemonFromPlayer(int playerId)
        {
            //TODO: use the stored procedure "spSelectPokemonOfPlayer" to get the pokemons of a player
            SqlConnection connection = PokemonDB.GetConnection();
            SqlCommand sqlCommand = new SqlCommand("spSelectPokemonOfPlayer", connection);
            sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@playerId", playerId);
            connection.Open();
            SqlDataReader reader = sqlCommand.ExecuteReader();
            List<Pokemon> list = new List<Pokemon>();
            while (reader.Read())
            {
                Pokemon pokemon = new Pokemon();
                pokemon.Id = reader.GetOrdinal("Id");
                pokemon.Name = reader["Name"].ToString();
                pokemon.Level = reader.GetInt32(reader.GetOrdinal("Level"));
                pokemon.Type = reader["Type"].ToString();
                pokemon.ImageSource = Pokemon.BaseImagePath + reader["Name"].ToString() + ".png";
                list.Add(pokemon);
            }
            connection.Close();
            return list;
        }
    }
}
