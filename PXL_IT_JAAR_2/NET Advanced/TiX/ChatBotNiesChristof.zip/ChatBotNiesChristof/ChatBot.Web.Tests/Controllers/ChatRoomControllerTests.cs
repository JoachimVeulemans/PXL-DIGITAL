﻿using System;
using System.Web.Mvc;
using System.Web.Routing;
using ChatBot.Web.Controllers;
using ChatBot.Web.Models.ViewModels;
using NUnit.Framework;

namespace ChatBot.Web.Tests.Controllers
{
    [TestFixture]
    public class ChatRoomControllerTests
    {
        //Tips:
        //  Use the existing ViewModel class 'ChatBotViewModel'
        //  It is NOT needed to mock anything
        //  ChatRoomController contains a public constant

        [Test]
        public void ChatBot_ShouldReturnViewWithPassedInBotNameAndStandardWelcomeMessage()
        { 
            
            // Arrange
            var controller = new ChatRoomController();
            string welcomeMessage = controller.StandardWelcomeMessage;
            var expectedViewModel = new ChatBotViewModel
            {
                BotName = Guid.NewGuid().ToString(),
                WelcomeMessage = welcomeMessage
            };

            // Act
            var result = controller.ChatBot(expectedViewModel.BotName) as ViewResult;
            var model = result.Model as ChatBotViewModel;

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(model.BotName, Is.EqualTo(expectedViewModel.BotName));
            Assert.That(model.WelcomeMessage, Is.EqualTo(welcomeMessage));
        }

        [Test]
        public void ChatBot_ShouldReturnViewWithBotNameFrankIfNoBotNameWasPassedIn()
        {
            //TIP: make sure the 'ChatBot' action method can be called without parameters
            // Arrange
            var controller = new ChatRoomController();
            string welcomeMessage = controller.StandardWelcomeMessage;

            // Act
            var result = controller.ChatBot() as ViewResult;
            var model = result.Model as ChatBotViewModel;

            // Arrange
            Assert.That(result, Is.Not.Null);
            Assert.That(model.BotName, Is.EqualTo("Frank"));
            Assert.That(model.WelcomeMessage, Is.EqualTo(welcomeMessage));
        }
    }
}
