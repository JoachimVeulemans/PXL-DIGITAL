﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http.Results;
using System.Web.Mvc;
using ChatBot.Data;
using ChatBot.Data.DomainClasses;
using ChatBot.Web.Controllers;
using Moq;
using NUnit.Framework;

namespace ChatBot.Web.Tests.Controllers
{
    [TestFixture]
    public class HomeControllerTests
    {
        private TestableHomeController _controller;

        [SetUp]
        public void Setup()
        {
            _controller = TestableHomeController.CreateInstance();
        }

        [Test]
        public void Feedback_Get_ShouldReturnViewWithNewFeedbackModel()
        {
            //Tip: you may need to change the 'Arrange' and 'Act' parts when you refactor. The 'Assert' part should not be changed.
           
            //Act
            var result = _controller.Feedback() as ViewResult;

            //Assert
            Assert.That(result, Is.Not.Null);
            var model = result.Model as Feedback;
            Assert.That(model, Is.Not.Null);
            Assert.That(model.Id, Is.EqualTo(0));
            Assert.That(model.Score, Is.EqualTo(0));
            Assert.That(model.Message, Is.Null.Or.Empty);
        }

        [Test]
        public void Feedback_Post_ShouldSaveTheFeedbackAndRedirectToIndexAction()
        {
           // Arrange
            var model = new Feedback
            {
                Id = 1,
                Message = null,
                Score = 5
            };
            _controller.FeedBackRepositoryMock.Setup(f => f.AddAsync(It.IsAny<Feedback>())).Returns(() => Task.FromResult(model));

            // Act
            //var createdResult = _controller.Feedback(model) as ViewResult;

            // Assert
        }

        [Test]
        public void Feedback_Post_ShouldReturnNaughtyViewIfModelIsInvalid()
        {
           
        }

        class TestableHomeController : HomeController
        {
            public Mock<IFeedbackRepository> FeedBackRepositoryMock { get; set; }

            public TestableHomeController(Mock<IFeedbackRepository> feedBackRepositoryMock) : base(
                feedBackRepositoryMock.Object)
            {
                FeedBackRepositoryMock = feedBackRepositoryMock;
            }

            public static TestableHomeController CreateInstance()
            {
                var feedBackRepositoryMock = new Mock<IFeedbackRepository>();
                return new TestableHomeController(feedBackRepositoryMock);
            }
        }
    }
}
