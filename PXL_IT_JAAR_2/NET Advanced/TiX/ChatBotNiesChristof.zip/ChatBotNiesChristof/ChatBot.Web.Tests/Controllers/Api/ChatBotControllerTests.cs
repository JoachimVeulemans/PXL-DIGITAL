﻿using System;
using System.Diagnostics;
using System.Web.Http.Results;
using ChatBot.Web.Controllers.Api;
using ChatBot.Web.Models.Services;
using Moq;
using NUnit.Framework;

namespace ChatBot.Web.Tests.Controllers.Api
{
    [TestFixture]
    public class ChatBotControllerTests
    {
        private TestableChatBotController _controller;

        [SetUp]
        public void Setup()
        {
            _controller = TestableChatBotController.CreateInstance();
        }

        [Test]
        public void PostQuestion_ShouldReturnResultOfAnswerGenerator()
        {
            // Arrange
            var random = Guid.NewGuid().ToString() + "?";
            _controller.AnswerGeneratorMock.Setup(g => g.Answer(It.IsAny<string>())).Returns(() => random);

            // Act
            var result = _controller.PostQuestion(random) as CreatedAtRouteNegotiatedContentResult<String>;

            // Arrange
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Content, Is.EqualTo(random));
            _controller.AnswerGeneratorMock.Verify(g => g.Answer(It.IsAny<string>()), Times.Once);
        }

        [Test]
        public void PostQuestion_ShouldReturnBadRequestWhenNoQuestionmarkIsPresent()
        {
            // Arrange
            var random = "text without question mark";

            // Act
            var result = _controller.PostQuestion(random) as BadRequestResult;

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Request, Is.EqualTo("Only questions are allowed"));
        }

        class TestableChatBotController : ChatBotController
        {
            public Mock<IAnswerGenerator> AnswerGeneratorMock { get; set; }

            public TestableChatBotController(Mock<IAnswerGenerator> answerGeneratorMock) : base(answerGeneratorMock
                .Object)
            {
                AnswerGeneratorMock = answerGeneratorMock;
            }

            public static TestableChatBotController CreateInstance()
            {
                var answerGeneratorMock = new Mock<IAnswerGenerator>();
                return new TestableChatBotController(answerGeneratorMock);
            }
        }
    }
}
