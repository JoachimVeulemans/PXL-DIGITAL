﻿using System;
using ChatBot.Web.Models.Services;
using NUnit.Framework;

namespace ChatBot.Web.Tests.Services
{
    [TestFixture]
    public class PxlAnswerGeneratorTests
    {

        [Test]
        public void Answer_ShouldReturnDontKnowWhenQuestionDoesNotContainPxl()
        {
            //Arrange
            var generator = new PxlAnswerGenerator();
            var question = Guid.NewGuid() + "?"; //a GUID can not contain 'Pxl' because it only contains hexadecimal characters (1 - 9 and A - F)
        
            //Act
            var answer = generator.Answer(question);

            //Assert
            Assert.That(answer, Is.EqualTo(generator.DontKnowAnswer));
            //("TODO: Replace the Assert.Fail statement with a meaningful assert");
        }

        [Test]
        [TestCase("PXL")]
        [TestCase("pxl")]
        [TestCase("Pxl")]
        public void Answer_ShouldReferToPxlWebsiteWhenQuestionContainsPxl(string pxl)
        {
            //Arrange
            var generator = new PxlAnswerGenerator();
            var question = Guid.NewGuid() + pxl + "?"; //note that the questions contains a variation of 'pxl'

            //Act
            var answer = generator.Answer(question);

            //Assert
            Assert.That(answer, Is.EqualTo(generator.ReferToPxlAnswer));
                //("TODO: Replace the Assert.Fail statement with a meaningful assert");
        }
    }
}