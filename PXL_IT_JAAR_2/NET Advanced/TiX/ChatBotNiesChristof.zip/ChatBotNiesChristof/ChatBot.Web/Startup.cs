﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(ChatBot.Web.Startup))]
namespace ChatBot.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}