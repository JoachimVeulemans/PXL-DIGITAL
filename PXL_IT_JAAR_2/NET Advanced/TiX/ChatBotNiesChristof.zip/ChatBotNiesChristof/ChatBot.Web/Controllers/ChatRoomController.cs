﻿using System;
using System.Web.Mvc;
using System.Web.Routing;
using ChatBot.Web.Models.ViewModels;

namespace ChatBot.Web.Controllers
{
    public class ChatRoomController : Controller
    {
        public string StandardWelcomeMessage = "Hello, how can I help you?";

        [Route("ChatRoom/HostedBy/{botname?}")]
        public ActionResult ChatBot(string botName = "Frank")
        {
            var viewModel = new ChatBotViewModel
            {
                BotName = botName,
                WelcomeMessage = StandardWelcomeMessage
            };

            return View(viewModel);
        }
    }
}