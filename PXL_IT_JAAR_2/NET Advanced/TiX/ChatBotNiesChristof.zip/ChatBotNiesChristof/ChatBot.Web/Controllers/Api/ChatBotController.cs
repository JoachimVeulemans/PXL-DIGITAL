﻿using System;
using System.Web.Http;
using ChatBot.Web.Models.Services;

namespace ChatBot.Web.Controllers.Api
{
    public class ChatBotController : ApiController
    {
        private readonly IAnswerGenerator _generator;

        public ChatBotController(IAnswerGenerator generator)
        {
            _generator = generator;
        }

        public IHttpActionResult PostQuestion([FromBody]string message) //TODO: make sure that webapi will search the message in the body of the http request
        {
            if (message.Contains("?"))
            {
                var answer = _generator.Answer(message);
                return CreatedAtRoute("DefaultApi", new { controller = "chatbot"}, answer);
            }
            else
            {
                return BadRequest("Only questions are allowed");
            }
        }
    }
}
