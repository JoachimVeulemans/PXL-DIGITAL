﻿using System;
using System.Threading.Tasks;
using System.Web.Mvc;
using ChatBot.Data;
using ChatBot.Data.DomainClasses;

namespace ChatBot.Web.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly IFeedbackRepository _repository;

        public HomeController(IFeedbackRepository repository)
        {
            _repository = repository;
        }

        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Feedback()
        {
            var model = new Feedback();
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> Feedback(Feedback model) //TODO: make this action asynchronous.
        {
            if (!ModelState.IsValid)
            {
                return View("Naughty");
            }
            await _repository.AddAsync(model);
            return View("Index");
        }
    }
}