﻿using System;

namespace ChatBot.Web.Models.Services
{
    public class PxlAnswerGenerator : IAnswerGenerator
    {
        public string ReferToPxlAnswer = "If you are interested in PXL, I recommend to visit www.pxl.be";
        public string DontKnowAnswer = "I don't know that. Do you have a school related question?";

        public string Answer(string question)
        {
            if (question.Contains("pxl") || question.Contains("Pxl") || question.Contains("PXL"))
            {
                return ReferToPxlAnswer;
            }
            else
            {
                return DontKnowAnswer;
            }
        }
    }
}