﻿namespace ChatBot.Web.Models.Services
{
    public interface IAnswerGenerator
    {
        string Answer(string question);
    }
}