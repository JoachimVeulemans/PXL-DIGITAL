﻿namespace ChatBot.Web.Models.ViewModels
{
    public class ChatBotViewModel
    {
        public string BotName { get; set; }
        public string WelcomeMessage { get; set; }
    }
}