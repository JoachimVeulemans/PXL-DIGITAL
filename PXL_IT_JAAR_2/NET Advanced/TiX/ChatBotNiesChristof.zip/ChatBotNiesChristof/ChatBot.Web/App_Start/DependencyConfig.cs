﻿using System.Web.Http;
using System.Web.Mvc;
using ChatBot.Data;
using ChatBot.Web.Models.Services;
using SimpleInjector;
using SimpleInjector.Integration.Web;
using SimpleInjector.Integration.Web.Mvc;
using SimpleInjector.Integration.WebApi;

namespace ChatBot.Web
{
    public class DependencyConfig
    {
        public static void RegisterWebApiDependencies()
        {
            //TODO: setup dependency injection for Web Api
            var container = new Container();
            container.Options.DefaultScopedLifestyle = new WebRequestLifestyle();

            container.Register(() => new ChatBotDbContext(), Lifestyle.Scoped);
            container.Register<IAnswerGenerator, PxlAnswerGenerator>(Lifestyle.Singleton);

            container.Verify();

            GlobalConfiguration.Configuration.DependencyResolver = new SimpleInjectorWebApiDependencyResolver(container);
        }

        public static void RegisterMvcDependencies()
        {
            //TODO: setup dependency injection for MVC
            var container = new Container();
            container.Options.DefaultScopedLifestyle = new WebRequestLifestyle();

            container.Register(() => new ChatBotDbContext(), Lifestyle.Scoped);
            container.Register<IFeedbackRepository, FeedbackDbRepository>(Lifestyle.Scoped);

            container.Verify();

            DependencyResolver.SetResolver(new SimpleInjectorDependencyResolver(container));
        }
    }
}