﻿using System.ComponentModel.DataAnnotations;

namespace ChatBot.Data.DomainClasses
{
    public class Feedback
    {
        public int Id { get; set; }

        [Range(0,10)]
        public int Score { get; set; }

        [Required]
        public string Message { get; set; }
    }
}