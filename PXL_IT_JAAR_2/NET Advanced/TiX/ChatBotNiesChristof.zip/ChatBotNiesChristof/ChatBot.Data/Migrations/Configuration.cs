using ChatBot.Data.DomainClasses;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace ChatBot.Data.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<ChatBot.Data.ChatBotDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(ChatBot.Data.ChatBotDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
            if (AddUser(context))
            {
                throw new ApplicationException("Could not seed user");
            }
        }

        private bool AddUser(ChatBotDbContext context)
        {
            var userManager = new UserManager<User>(new UserStore<User>(context));
            var user = new User
            {
                UserName = "dummy@pxl.be",
                Email = "dummy@pxl.be"
            };
            var result = userManager.Create(user);
            if (!result.Succeeded) return false;

            userManager.AddPassword(user.Id, "Dummy123!");
            if (!result.Succeeded) return false;

            return result.Succeeded;
        }
    }
}
