﻿using System.Threading.Tasks;
using ChatBot.Data.DomainClasses;

namespace ChatBot.Data
{
    public interface IFeedbackRepository
    {
        Task AddAsync(Feedback newFeedback);
    }
}