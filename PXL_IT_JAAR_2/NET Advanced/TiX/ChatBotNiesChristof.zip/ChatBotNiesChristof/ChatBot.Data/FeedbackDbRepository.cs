﻿using System.Data.Entity.Migrations;
using System.Threading.Tasks;
using ChatBot.Data.DomainClasses;

namespace ChatBot.Data
{
    public class FeedbackDbRepository : IFeedbackRepository //TODO: implement IFeedbackRepository
    {
        //Tip1: use async await
        //Tip2: use SaveChangesAsync() instead of SaveChanges()
        private readonly ChatBotDbContext _context;

        public FeedbackDbRepository(ChatBotDbContext context)
        {
            _context = context;
        }

        public async Task AddAsync(Feedback newFeedback)
        {
            _context.Feedback.Add(newFeedback);
            await _context.SaveChangesAsync();
        }
    }
}