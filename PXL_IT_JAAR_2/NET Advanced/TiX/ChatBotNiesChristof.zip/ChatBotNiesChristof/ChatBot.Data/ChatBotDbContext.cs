﻿using System.Data.Entity;
using ChatBot.Data.DomainClasses;
using Microsoft.AspNet.Identity.EntityFramework;

namespace ChatBot.Data
{
    public class ChatBotDbContext : IdentityDbContext<User> //TODO: inherit from some other class
    {
        public ChatBotDbContext()
            : base("DefaultConnection")
        {
        }

        public static ChatBotDbContext Create()
        {
            return new ChatBotDbContext();
        }

        public DbSet<Feedback> Feedback { get; set; }

        public static void SetInitializer()
        {
            //TODO: make sure Entity Framework creates the database if it does not exists and migrates an existing database to the latest version
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<ChatBotDbContext, Migrations.Configuration>());
        }
    }
}
