﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using SamuraiApp.Domain;

namespace SamuraiApp.Data
{
    public class SamuraiContext : DbContext
    {
        public DbSet<Samurai> Samurais { get; set; }
        public DbSet<Quote> Quotes { get; set; }
        public DbSet<Battle> Battles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // base.OnConfiguring(optionsBuilder);
            var connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SamuraiAppData;Integrated Security=True";

            var loggerFactory = new LoggerFactory(new[]
            {
                new ConsoleLoggerProvider((category, loglevel) => category == DbLoggerCategory.Database.Command.Name && loglevel == LogLevel.Information, true)

            });
            optionsBuilder.UseLoggerFactory(loggerFactory).UseSqlServer(connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SamuraiBattle>().HasKey(sb => new {sb.BattleId, sb.SamuraiId});
            modelBuilder.Entity<Samurai>().Property(s => s.Name).IsRequired();

            modelBuilder.Entity<Battle>().HasData(new Battle
            {
                Id = 1,
                Name = "The great battle",
                StartDate = new DateTime(902, 1, 30),
                EndDate = new DateTime(902, 1, 30)

            }, new Battle
            {
                Id = 2,
                Name = "The long battle",
                StartDate = new DateTime(902, 1, 30),
                EndDate = new DateTime(902, 2, 10)
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
