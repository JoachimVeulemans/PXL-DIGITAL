﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SamuraiApp.Data;
using SamuraiApp.Domain;

namespace SamuraiApp.UI
{
    class Program
    {
        private static SamuraiContext _context = new SamuraiContext();
        static void Main(string[] args)
        {
            //InsertSingleSamurai();
            //InsertMultipleSamurai();

            //ExecuteSimpleSamuraiQuery();
            //ExecuteOtherQueries();

            //InsertSamuraiWithQuotes();
            //AddQuoteToExistingSamurai();

            //AddQuoteToExistingUntrackedSamurai();
            LoadSamuraisWithQuotes();

            Console.WriteLine("Press any key to close");
            Console.ReadKey(true);
        }

        private static void LoadSamuraisWithQuotes()
        {
            var samuraiWithQuotes = _context.Samurais.Include(s => s.Quotes);
        }

        private static void AddQuoteToExistingUntrackedSamurai()
        {
            var samurai = _context.Samurais.First();
            var quote = new Quote
            {
                Text = "I bet you're happy that I've saved you",
                SamuraiId = samurai.Id
            };
            //samurai.Quotes.Add(quote);
            //_context.SaveChanges();

            using (var otherContext = new SamuraiContext())
            {
                otherContext.Quotes.Add(quote);
                otherContext.SaveChanges();
            }
        }

        private static void AddQuoteToExistingSamurai()
        {
            var samurai = _context.Samurais.First();
            samurai.Quotes.Add(new Quote
            {
                Text = "I bet you're happy that I've saved you"
            });
            _context.SaveChanges();
        }

        private static void InsertSamuraiWithQuotes()
        {
            var samurai = new Samurai
            {
                Name = "RamboSan",
                Quotes = new List<Quote>
                {
                    new Quote() {Text = "I've come to save you"},
                    new Quote() {Text = "Are you happy to see me?"}
                }
            };
            _context.Samurais.Add(samurai);
            _context.SaveChanges();
        }

        private static void ExecuteOtherQueries()
        {
            //var wesley = _context.Samurais.Where(s => s.Name == "Wesley").FirstOrDefault();
            var nameFilter = "Wesley";
            var wesley = _context.Samurais.FirstOrDefault(s => s.Name == nameFilter);
            PrintSamurai(wesley);

            var matchText = "e";
            var query = from samurai in _context.Samurais where samurai.Name.Contains(matchText) select samurai;
            foreach (var samurai in query)
            {
                PrintSamurai(samurai);
            }

        }

        private static void ExecuteSimpleSamuraiQuery()
        {
            //var allSamuraiQuery = from samurai in _context.Samurais select samurai;
            var allSamurais = _context.Samurais.ToList();

            //foreach (var samurai in allSamuraiQuery)
            foreach (var samurai in allSamurais)
            {
                PrintSamurai(samurai);
            }
        }

        private static void PrintSamurai(Samurai samurai)
        {
            Console.WriteLine($"Samurai: {samurai.Name}");
        }

        private static void InsertMultipleSamurai()
        {
            var marijke = new Samurai { Name = "Marijke" };
            var kris = new Samurai { Name = "Kris" };
            _context.Samurais.AddRange(marijke, kris);
            _context.SaveChanges();
        }

        private static void InsertSingleSamurai()
        {
            var samurai = new Samurai { Name = "Wesley" };
            _context.Samurais.Add(samurai);
            _context.SaveChanges();
        }
    }
}
