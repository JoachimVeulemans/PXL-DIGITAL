﻿using Microsoft.EntityFrameworkCore;
using SamuraiApp.Data;
using SamuraiApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SamuraiApp.UI
{
    class Program
    {
        private static SamuraiContext _context = new SamuraiContext();

        static void Main(string[] args)
        {
            // InsertSamuraiWithSingleQuote();
            // InsertSamuraiWithMultipleQuotes();
            // AddQuoteToExistingSamurai();
            // AddQuoteToExistingUntrackedSamuraiTheWrongWay();
            // AddQuoteToExistingUntrackedSamurai();

            // LoadSamuraiWithQuotes();
            // LoadHappySamurais();

            // ModifyRelatedDataWhenTracked();
            // ModifyRelatedDataWhenNotTracked();

            Console.WriteLine();
            Console.WriteLine("Press any key to close the window.");
            Console.ReadKey(true);
        }

        private static void ModifyRelatedDataWhenNotTracked()
        {
            var samurai = _context.Samurais.Include(s => s.Quotes).First();
            var quote = samurai.Quotes[0];
            quote.Text += " Did you hear that?";

            using (var otherContext = new SamuraiContext())
            {
                // otherContext.Quotes.Update(quote); //will cause all the quotes and the samurai to be updated
                otherContext.Entry(quote).State = EntityState.Modified;
                otherContext.SaveChanges();
            }
        }

        private static void ModifyRelatedDataWhenTracked()
        {
            var samurai = _context.Samurais.Include(s => s.Quotes).First();
            // samurai.Quotes[0].Text += " Did you hear that?";
            _context.Quotes.Remove(samurai.Quotes[1]);
            _context.SaveChanges();
        }

        private static void LoadHappySamurais()
        {
            var happySamurais = _context.Samurais
                .Where(s => s.Quotes.Any(q => q.Text.Contains("happy")))
                .ToList();

            foreach (var samurai in happySamurais)
            {
                PrintSamurai(samurai);
            }
        }

        private static void LoadSamuraiWithQuotes()
        {
            var samuraisWithQuotes = _context.Samurais
                .Where(s => s.Name.Contains("e"))
                .Include(s => s.Quotes)
                .ToList();

            foreach (var samurai in samuraisWithQuotes)
            {
                PrintSamurai(samurai);
            }
        }

        private static void AddQuoteToExistingUntrackedSamurai()
        {
            var samurai = _context.Samurais.First();

            var quote = new Quote
            {
                Text = "I bet you're happy that I've saved you!",
                SamuraiId = samurai.Id
            };

            using (var otherContext = new SamuraiContext())
            {
                otherContext.Quotes.Add(quote);
                otherContext.SaveChanges();
            }
        }

        private static void AddQuoteToExistingUntrackedSamuraiTheWrongWay()
        {
            var samurai = _context.Samurais.First();
            samurai.Quotes.Add(new Quote
            {
                Text = "I bet you're happy that I've saved you!"
            });

            using (var otherContext = new SamuraiContext())
            {
                otherContext.Samurais.Add(samurai);
            }
        }

        private static void AddQuoteToExistingSamurai()
        {
            var samurai = _context.Samurais.First();
            samurai.Quotes.Add(new Quote
            {
                Text = "I bet you're happy that I've saved you!"
            });
            _context.SaveChanges();
        }

        private static void InsertSamuraiWithMultipleQuotes()
        {
            var samurai = new Samurai
            {
                Name = "Kyüzo",
                Quotes = new List<Quote>
                {
                    new Quote {Text = "Watch out for my sharp sword!"},
                    new Quote {Text = "I told you to watch out for my sharp sword!"}
                }
            };
            _context.Samurais.Add(samurai);
            _context.SaveChanges();
        }

        private static void InsertSamuraiWithSingleQuote()
        {
            var samurai = new Samurai
            {
                Name = "Kambei Shimada",
                Quotes = new List<Quote>
                {
                    new Quote {Text = "I've com to save you"}
                }
            };
            _context.Samurais.Add(samurai);
            _context.SaveChanges();
        }

        private static void PrintSamurai(Samurai samurai)
        {
            Console.WriteLine($"Samurai: {samurai.Name}");
        }
    }
}
