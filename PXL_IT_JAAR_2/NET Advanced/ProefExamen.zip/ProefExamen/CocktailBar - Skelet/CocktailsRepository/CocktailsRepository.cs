﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;

namespace CocktailBarData
{
    public class CocktailsRepository
    {
        public static List<Cocktail> GetAllCocktails()
        {
            // TODO: Gebruik de nodige ADO.NET classes om alle
            // cocktails uit de database te lezen.
            var allCocktails = new List<Cocktail>();

            SqlConnection connection = CocktailsDB.GetConnection();
            string selectStatement = "SELECT * FROM Cocktails;";
            var selectCommand = new SqlCommand(selectStatement, connection);

            SqlDataReader reader = null;
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();

                int idOrdinal = reader.GetOrdinal("Id");
                int nameOrdinal = reader.GetOrdinal("Name");
                int descriptionOrdinal = reader.GetOrdinal("Description");
                int instructionsOrdinal = reader.GetOrdinal("Instructions");

                while (reader.Read())
                {
                    Cocktail cocktail = new Cocktail()
                    {
                        Id = reader.GetInt32(idOrdinal),
                        Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                        Description = reader.IsDBNull(descriptionOrdinal) ? null : reader.GetString(descriptionOrdinal),
                        Instructions = reader.IsDBNull(instructionsOrdinal) ? null : reader.GetString(instructionsOrdinal)
                    };
                    allCocktails.Add(cocktail);
                }

            }
            finally
            {
                connection?.Close();
                reader?.Close();
            }

            return allCocktails;


        }
    }
}

