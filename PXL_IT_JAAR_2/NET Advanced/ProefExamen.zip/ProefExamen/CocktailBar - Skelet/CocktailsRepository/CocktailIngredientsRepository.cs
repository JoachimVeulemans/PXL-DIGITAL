﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;

namespace CocktailBarData
{
    public static class CocktailIngredientsRepository
    {        
        public static List<CocktailIngredient> GetCocktailIngredients(int cocktailId)
        {
            // TODO: gebruik de nodige ADO.NET classes om 
            // de gegevens uit de database te lezen
            // Schrijf een SELECT query om de gegevens van de
            // CocktailIngredients tabel te lezen, samen met 
            // de naam en de eenheid van het ingredient (2 kolommen uit de Ingredients tabel)
            // Tip: null can je casten naar een nullable decimal (decimal?) als volgt: (decimal?) null

            var ingredients = new List<CocktailIngredient>();

            var connection = CocktailsDB.GetConnection();
            string selectStatement = "SELECT IngredientId, Name, Quantity, Unit FROM Ingredients " +
                                     "JOIN CocktailIngredients ON IngredientId = Ingredients.Id " +
                                     "WHERE CocktailId = 4";

            var selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.Parameters.AddWithValue("@CocktailId", cocktailId);
            SqlDataReader reader = null;
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();

                int ingredientIdOrdinal = reader.GetOrdinal("IngredientId");
                int nameOrdinal = reader.GetOrdinal("Name");
                int quantityOrdinal = reader.GetOrdinal("Quantity");
                int unitOrdinal = reader.GetOrdinal("Unit");

                while (reader.Read())
                {
                    CocktailIngredient cocktailIngredient = new CocktailIngredient()
                    {
                        CocktailId = cocktailId,
                        IngredientId = reader.GetInt32(ingredientIdOrdinal),
                        IngredientName = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                        Quantity = reader.IsDBNull(quantityOrdinal) ? (decimal?) null : reader.GetDecimal(quantityOrdinal),
                        Unit = reader.IsDBNull(unitOrdinal) ? null : reader.GetString(unitOrdinal),
                    };
                    ingredients.Add(cocktailIngredient);
                }

            }
            finally
            {
                connection?.Close();
                reader?.Close();
            }

            return ingredients;

        }
    }
}
