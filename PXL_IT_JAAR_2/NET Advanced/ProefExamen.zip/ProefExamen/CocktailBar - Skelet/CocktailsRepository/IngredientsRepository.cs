﻿using System.Collections.Generic;
using System.Data.SqlClient;

namespace CocktailBarData
{
    public class IngredientsRepository
    {
        public static List<Ingredient> GetAllIngredients()
        {
            // TODO: gebruik de nodige ADO classes om alle 
            // ingrediënten uit de database te lezen.
            var allIngredients = new List<Ingredient>();

            SqlConnection connection = CocktailsDB.GetConnection();
            string selectStatement = "SELECT * FROM Ingredients";
            var selectCommand = new SqlCommand(selectStatement, connection);

            SqlDataReader reader = null;
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();

                int idOrdinal = reader.GetOrdinal("Id");
                int nameOrdinal = reader.GetOrdinal("Name");
                int unitOrdinal = reader.GetOrdinal("Unit");

                while (reader.Read())
                {
                    Ingredient ingredient = new Ingredient()
                    {
                        Id = reader.GetInt32(idOrdinal),
                        Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                        Unit = reader.IsDBNull(unitOrdinal) ? null : reader.GetString(unitOrdinal)
                    };
                    allIngredients.Add(ingredient);
                }

            }
            finally
            {
                connection?.Close();
                reader?.Close();
            }

            return allIngredients;
        }
    }
}

