﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace CocktailBar.Converters
{
    public class ImageConverter : IValueConverter
    {
        // TODO: vul deze class aan: De naam van de image is de
        // naam van de cocktail zonder de spatie(s), met ".jpg" als extensie.
        // #opgave lezen is kut
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string name = value.ToString();

            string path = "Images/" + name.Replace(" ", "") + ".jpg";
            Uri imageUri = new Uri(path, UriKind.Relative);
            BitmapImage bitmapImage = new BitmapImage(imageUri);

            return bitmapImage;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
