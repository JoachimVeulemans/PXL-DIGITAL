﻿using CocktailBarData;
using System;
using System.Windows;
using System.Windows.Input;

namespace CocktailBar
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //TODO Voeg hier de nodige code toe: 
        // Bij het dubbelklikken op een cocktail moet er naar 
        // het CocktailDetailsWindow genavigeerd worden.
        // Wanneer er op de + wordt geklikt, moet er naar het 
        // AddCocktailWindow genavigeerd worden
        public MainWindow()
        {
            InitializeComponent();
            CocktailListView.ItemsSource = CocktailsRepository.GetAllCocktails();
        }

        private void CocktailListView_OnMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Cocktail cocktail = (Cocktail)CocktailListView.SelectedItem;
            CocktailDetailsWindow cocktailDetailsWindow = new CocktailDetailsWindow(cocktail);
            cocktailDetailsWindow.Show();
        }
    }
}
