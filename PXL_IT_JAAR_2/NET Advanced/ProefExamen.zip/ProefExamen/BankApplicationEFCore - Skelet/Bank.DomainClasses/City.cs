﻿using System.Collections.Generic;

namespace Bank.DomainClasses
{
    public class City
    {
        public string ZipCode { get; set; }
        public string Name { get; set; }

    }
}
