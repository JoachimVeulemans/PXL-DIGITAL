﻿using Bank.DomainClasses.Enums;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Security.Principal;

namespace Bank.DomainClasses
{
    public class Account
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; }
        public decimal Balance { get; set; }
        public AccountType AccountType { get; set; }
        public int  CustomerId { get; set; }
    }
}
