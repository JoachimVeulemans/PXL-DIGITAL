﻿using Bank.Business;
using Bank.DomainClasses;
using Bank.DomainClasses.Enums;
using NUnit.Framework;
using NUnit.Framework.Internal;

namespace Bank.Test
{
    [TestFixture]
    public class AccountManagerTests
    {
        private AccountManager sut;

        [SetUp]
        public void AccountManagerSetUp()
        {
            sut = new AccountManager();
        }

        [Test]
        public void ShouldCorrectlyTransferMoneyWhenBalanceIsSufficient()
        {
            var account1 = new Account
            {
                Balance = 2000
            };
            var account2 = new Account
            {
                Balance = 5000
            };

            // SHOULD NOT!
            Assert.That(() => sut.TransferMoney(account1, account2, 1000), Throws.Nothing);
        }

        [Test]
        public void ShouldThrowInvalidTransferExceptionWhenBalanceIsInsufficient()
        {
            var account1 = new Account
            {
                Balance = 0
            };
            var account2 = new Account
            {
                Balance = 5000
            };

            Assert.That(() => sut.TransferMoney(account1, account2, 1000), Throws.TypeOf<InvalidTransferException>());
        }

        [Test]
        public void ShouldThrowInvalidTransferExceptionForYouthAccountWhenAmountIsBiggerThan1000()
        {
            var account1 = new Account
            {
                Balance = 2000,
                AccountType = AccountType.YouthAccount
            };
            var account2 = new Account
            {
                Balance = 5000
            };

            Assert.That(() => sut.TransferMoney(account1, account2, 1001), Throws.TypeOf<InvalidTransferException>());
        }
    }
}
