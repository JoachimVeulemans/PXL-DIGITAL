﻿using System;
using Bank.DomainClasses;
using Bank.DomainClasses.Enums;

namespace Bank.Business
{
    public class AccountManager
    {
        public void TransferMoney(Account fromAccount, Account toAccount, decimal amount)
        {
            if (fromAccount.AccountType.Equals(AccountType.YouthAccount) && amount > 1000)
            {
                throw new InvalidTransferException("You cannot transfer more than 1000 euro from a youth account");
            }

            if (fromAccount.Balance < amount)
            {
                throw new InvalidTransferException("Insufficient balance");
            }
        }
    }
}
