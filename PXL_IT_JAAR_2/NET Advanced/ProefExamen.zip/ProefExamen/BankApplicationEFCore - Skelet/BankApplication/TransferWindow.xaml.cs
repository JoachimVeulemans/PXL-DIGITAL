﻿using Bank.Business;
using Bank.DomainClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace BankApplication
{
    /// <summary>
    /// Interaction logic for TransferWindow.xaml
    /// </summary>
    public partial class TransferWindow : Window
    {
        private Account fromAccount;
        private IList<Account> allCustomerAccounts;

        public TransferWindow(IList<Account> allCustomerAccounts, int fromAccountId)
        {
            // TODO: Geef het rekeningnummer van de opdrachtgevende rekening weer.
            // Zorg ervoor dat alle andere rekeningen van de klant in de combobox worden getoond.
            this.fromAccount = allCustomerAccounts.First(a => a.Id == fromAccountId);

            this.allCustomerAccounts = allCustomerAccounts;

            InitializeComponent();

            FromAccountTextBlock.Text = fromAccountId.ToString();
            ToAccountComboBox.ItemsSource = allCustomerAccounts.Where(a => a.Id != fromAccountId);
        }

        private void TransferButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Vul deze code aan zodat het bedrag van de ene rekening naar de andere wordt overgezet.
            // Maak hierbij gebruik van de AccountManager class.
            // Zorg dat bij een succesvolle transfer het AccountWindow op de hoogte gebracht wordt (Tip: DialogResult) 
            // zodat daar de transfer kan doorgevoerd worden in de database. 
            AccountManager AccountManager = new AccountManager();
            int index = ToAccountComboBox.SelectedIndex;
            try
            {
                AccountManager.TransferMoney(fromAccount, allCustomerAccounts[index], Decimal.Parse(AmountTextBox.Text));
            }
            catch(InvalidTransferException ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
    }
}
