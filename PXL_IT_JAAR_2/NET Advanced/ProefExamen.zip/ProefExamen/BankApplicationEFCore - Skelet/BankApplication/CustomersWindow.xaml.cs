﻿using System.Collections.Generic;
using Bank.Datalayer;
using Bank.DomainClasses;
using System.Windows;

namespace BankApplication
{
    /// <summary>
    /// Interaction logic for BankCustomersWindow.xaml
    /// </summary>
    public partial class CustomersWindow : Window
    {
        private AccountRepository accountRepository;
        private CustomerRepository customerRepository;
        private CityRepository cityRepository;
        private IList<Customer> customers;

        public CustomersWindow()
        {
            var context = new BankContext();
            accountRepository = new AccountRepository(context);
            customerRepository = new CustomerRepository(context);
            cityRepository = new CityRepository(context);
            // TODO: vul deze code aan zodat alle Customers in het overzicht worden getoond.
            // Zorg ook dat alle Cities in de combobox geselecteerd kunnen worden
            InitializeComponent();
            customers = (IList<Customer>) customerRepository.GetAll();
            CustomersDataGrid.ItemsSource = customers;
            CityComboBox.ItemsSource = cityRepository.GetAllCities();

        }

        private void ShowAccountsButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Vul deze code aan zodat er naar het AccountsWindow genavigeerd wordt.
            Customer customer = (Customer)CustomersDataGrid.SelectedItem;
            AccountsWindow accountsWindow = new AccountsWindow(customer, customerRepository, accountRepository, cityRepository);
            accountsWindow.Show();
        }

        private void SaveBankButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: vul deze code aan zodat de geselecteerde Customer in de database wordt toegevoegd / aangepast.
            CustomersDataGrid.CanUserAddRows = false;
            Customer customer = (Customer) CustomersDataGrid.SelectedItem;
            if (customer.CustomerId == 0)
            {
                customerRepository.Add(customer);
            }
            else
            {
                customerRepository.UpdateCustomer(customer.CustomerId, customer);
            }
            customerRepository.Commit();
        }

        private void AddCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            //TODO: zorg dat je een nieuwe klant in de datagrid kan toevoegen (zie Tip in opgave)
            CustomersDataGrid.CanUserAddRows = true;
        }
    }
}
