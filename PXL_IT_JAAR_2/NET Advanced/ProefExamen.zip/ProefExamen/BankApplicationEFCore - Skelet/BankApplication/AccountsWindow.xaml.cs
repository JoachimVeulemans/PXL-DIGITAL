﻿using System;
using Bank.Business;
using Bank.Datalayer;
using Bank.DomainClasses;
using Bank.DomainClasses.Enums;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace BankApplication
{
    /// <summary>
    /// Interaction logic for AccountsWindow.xaml
    /// </summary>
    public partial class AccountsWindow : Window
    {
        private AccountRepository accountRepository;
        private CustomerRepository customerRepository;
        private CityRepository cityRepository;
        private Customer customer;
        private IList<Account> accounts;

        public AccountsWindow(Customer customer, CustomerRepository customerRepository, AccountRepository accountRepository, CityRepository cityRepository)
        {
            // TODO: vul de code aan zodat alle rekeningen van de 
            // geselecteerde klant in het overzicht worden getoond
            var context = new BankContext();
            this.accountRepository = accountRepository;
            this.customerRepository = customerRepository;
            this.cityRepository = cityRepository;
            this.customer = customer;
            this.accounts = accountRepository.GetAllAccountsOfCustomer(customer.CustomerId);

            InitializeComponent();
            AccountsDataGrid.ItemsSource = accounts;
        }

        private void AddAccountButton_Click(object sender, RoutedEventArgs e)
        {
            //TODO: zorg dat je een nieuwe rekening in de datagrid kan toevoegen (zie Tip in opgave)      
            AccountsDataGrid.CanUserAddRows = true;
        }

        private void SaveAccountButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: vul deze code aan zodat de geselecteerde rekening
            // in de database wordt toegevoegd / aangepast.
            AccountsDataGrid.CanUserAddRows = false;
            Account account = (Account) AccountsDataGrid.SelectedItem;
            if (account.Id == 0)
            {
                accountRepository.AddAccountForCustomer(account, customer.CustomerId);
            }
            else
            {
                accountRepository.UpdateAccount(account.Id, account);
            }
            accountRepository.Commit();
            
        }

        private void TransferButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: vul deze code aan zodat naar het TransferWindow wordt genavigeerd. 
            // Wanneer het TransferWindow wordt gesloten wordt gesloten, moet de transfer doorgevoerd worden in de database
            // Zorg er ook voor dat de aanpassingen aan de balansen ook automatisch worden aangepast in het AccountsWindow
            // (gebruik hiervoor de INotitfyPropertyChanged interface)
            Account fromAccount = ((Account) AccountsDataGrid.SelectedItem);
            TransferWindow transferWindow = new TransferWindow(accounts, fromAccount.Id);
            transferWindow.Show();
            transferWindow.Closed += TransferWindowOnClosed;
        }

        private void TransferWindowOnClosed(object sender, EventArgs e)
        {
            Account fromAccount = ((Account)AccountsDataGrid.SelectedItem);
            accountRepository.UpdateAccount(fromAccount.Id, fromAccount);
            //accountRepository.UpdateAccount();
            // zal dit in augustus maken
            accountRepository.Commit();
        }
    }
}
