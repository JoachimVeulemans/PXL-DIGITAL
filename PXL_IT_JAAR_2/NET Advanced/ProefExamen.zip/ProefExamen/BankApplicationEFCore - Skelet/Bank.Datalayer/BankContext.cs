﻿using Bank.DomainClasses;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using System.Configuration;

namespace Bank.Datalayer
{
    public class BankContext : DbContext
    {
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<City> Cities { get; set; }

        public BankContext() { } //Constructor used by UI project

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured) //only configure the connection if the parameterless contructor was used (no options where provided).
            {
                //TODO: tell EF (Entity Framework) that is going to operate against a SQL Server database using the connection string in the app.config of the UI project
                optionsBuilder.UseSqlServer(ConfigurationManager.ConnectionStrings["BankConnectionString"].ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<LotteryGame>().Property(s => s.Name).IsRequired();
            modelBuilder.Entity<City>().HasKey(c => c.ZipCode);
            modelBuilder.Entity<Customer>().HasMany<Account>();
            modelBuilder.Entity<Customer>().HasOne<City>();
            //modelBuilder.Entity<City>().HasMany<Customer>();
            //modelBuilder.Entity<Account>().HasOne<Customer>();
            //modelBuilder.Entity<LotteryGame>().HasData(new LotteryGame
            //{
            //    Id = 1,
            //    Name = "National lottery",
            //    MaximumNumber = 45,
            //    NumberOfNumbersInADraw = 6
            //}, new LotteryGame
            //{
            //    Id = 2,
            //    Name = "Keno",
            //    MaximumNumber = 70,
            //    NumberOfNumbersInADraw = 20
            //});

            base.OnModelCreating(modelBuilder);
        }

        public void CreateOrUpdateDatabase()
        {
            this.Database.Migrate();
        }
    }
}
