﻿namespace PayablesData
{
    public class GLAccount
    {
        public int AccountNo { get; set; }

        public string Description { get; set; }
    }
}
