﻿namespace PayablesData
{
    public class State
    {
        public string StateCode { get; set; }

        public string StateName { get; set; }

        public int FirstZipCode { get; set; }

        public int LastZipCode { get; set; }
    }
}
