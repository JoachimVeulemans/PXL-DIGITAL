﻿namespace PayablesData
{
    public class Terms
    {
        public int TermsId { get; set; }

        public string Description { get; set; }

        public int DueDays { get; set; }
    }
}
