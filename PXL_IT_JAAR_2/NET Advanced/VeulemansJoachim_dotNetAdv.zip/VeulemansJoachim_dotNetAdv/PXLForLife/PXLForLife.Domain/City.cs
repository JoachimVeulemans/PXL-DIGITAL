﻿namespace PXLForLife.Domain
{
    public class City
    {
        /* TODO: Add your code here */
        public int Id { get; set; }
        public int ZipId { get; set; }
        public string CityName { get; set; }

    }
}
