﻿using System.Configuration;
using Microsoft.EntityFrameworkCore;
using PXLForLife.Domain;

namespace PXLForLife.Data
{
    public class PXLForLifeContext : DbContext
    {
        /* TODO: Add your code here */
        public DbSet<Action> actions { get; set; }
        public DbSet<Charity> charities { get; set; }
        public DbSet<City> cities { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(ConfigurationManager.ConnectionStrings["PXLForLifeConnection"].ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Charity>().Property(s => s.Description).HasMaxLength(1000);
            base.OnModelCreating(modelBuilder);
        }

        public void CreateOrUpdateDatabase()
        {
            this.Database.Migrate();
        }
    }
}
