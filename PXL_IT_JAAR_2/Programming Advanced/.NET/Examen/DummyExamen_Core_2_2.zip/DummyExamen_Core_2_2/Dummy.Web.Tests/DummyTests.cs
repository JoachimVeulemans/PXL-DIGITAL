﻿using NUnit.Framework;

namespace Dummy.Web.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void DoTest()
        {
            Assert.Fail();
        }
    }
}
