﻿$(function () {
  $messageboard = $('#messageboard');
  $messageboard.hide();

  var $maximumNumberInput = $('#maximumNumberInput');
  var $chosenNumberInput = $('#chosenNumberInput');

  function showMessage(cssClass, message) {
    $messageboard.removeClass('alert-success');
    $messageboard.removeClass('alert-danger');
    $messageboard.removeClass('alert-warning');
    $messageboard.addClass(cssClass);
    $messageboard.html(message);
    $messageboard.show();
  }

  $(gambleButton).click(function () {
    var maximumNumber = +$maximumNumberInput.val();
    var chosenNumber = +$chosenNumberInput.val();

    if (maximumNumber <= 1) {
      showMessage('alert-danger', 'The first number should be greater than 1.');
    } else if (chosenNumber <= 0) {
      showMessage('alert-danger', 'The second number should be greater than 0.');
    } else if (chosenNumber > maximumNumber) {
      showMessage('alert-danger',
        'The second number should be smaller than or equal to the first number.');
    } else {
      $.ajax({
        type: "GET",
        url: "/api/randomgenerator/nextwholenumber/between/1/and/" + maximumNumber,
        dataType: 'json',
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {
          var generatedNumber = +response;
          var message = 'The generated number is ' + generatedNumber + '.<br />';
          if (chosenNumber === generatedNumber) {
            message += 'You have chosen the same number, so you have to accept the challenge!';
            showMessage('alert-warning', message);
          } else {
            message += 'You have chosen a different number, so you are of the hook!';
            showMessage('alert-success', message);
          }
        },
        error: function (response) {
          var errorMessage = 'Error retrieving random number from API.<br />' + response.status + ' ' + response.statusText + '.<br /><br /> ' + response.responseText;
          showMessage('alert-danger', errorMessage);
        },
        complete: function () {
        }
      });
    }
  });
});