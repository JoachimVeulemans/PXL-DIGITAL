﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Dummy.Web.Areas.Identity.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}

