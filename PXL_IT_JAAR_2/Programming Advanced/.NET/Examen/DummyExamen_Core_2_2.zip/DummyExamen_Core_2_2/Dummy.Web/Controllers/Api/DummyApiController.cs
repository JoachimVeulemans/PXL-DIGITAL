﻿using Microsoft.AspNetCore.Mvc;

namespace Dummy.Web.Controllers.Api
{
    public class DummyApiController : ControllerBase
    { 
        public IActionResult DoStuff()
        {
            return Conflict();
        }
    }
}