﻿using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace MusicStoreCore.Services
{
    public class HostFileProvider : IFileProvider
    {
        private readonly IHostingEnvironment _environment;

        public HostFileProvider(IHostingEnvironment environment)
        {
            _environment = environment;
        }

        public byte[] GetFileBytes(string relativePath)
        {
            var fullPath = Path.Combine(_environment.ContentRootPath, relativePath);
            return File.ReadAllBytes(fullPath);
        }
    }
}