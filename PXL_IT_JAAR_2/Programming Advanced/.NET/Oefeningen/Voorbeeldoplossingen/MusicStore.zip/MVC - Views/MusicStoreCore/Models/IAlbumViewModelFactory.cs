﻿using MusicStoreCore.Data.DomainClasses;

namespace MusicStoreCore.Models
{
    public interface IAlbumViewModelFactory
    {
        AlbumViewModel Create(Album album, Genre genre);
    }
}