﻿namespace MusicStoreCore.Services
{
    public interface IFileProvider
    {
        byte[] GetFileBytes(string relativePath);
    }
}
