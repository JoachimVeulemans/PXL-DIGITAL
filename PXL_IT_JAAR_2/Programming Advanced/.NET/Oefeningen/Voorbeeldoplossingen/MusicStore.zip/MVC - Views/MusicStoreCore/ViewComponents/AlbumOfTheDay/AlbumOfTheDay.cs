﻿using Microsoft.AspNetCore.Mvc;
using MusicStoreCore.Models;

namespace MusicStoreCore.ViewComponents.AlbumOfTheDay
{
    public class AlbumOfTheDay:ViewComponent
    {
        private readonly AlbumViewModel _album;
        public AlbumOfTheDay()
        {
            _album = new AlbumViewModel()
            {
                Artist = "A popular artist",
                Genre = "Some genre",
                Title = "Some title"
            };
        }
        public IViewComponentResult Invoke()
        {
            return View("_Album", _album);
        }
    
    }
}
