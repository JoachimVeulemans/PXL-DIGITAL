﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace MusicStoreCore.Extensions
{
    public static class HtmlHelperExtensions
    {
        public static IHtmlContent SubTitle(this IHtmlHelper helper, string text)
        {
            var html = $"<h2>{text}</h2>";
            return new HtmlString(html);
        }
    }
}
