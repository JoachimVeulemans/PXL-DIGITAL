﻿using Microsoft.AspNetCore.Mvc;
using MusicStoreCore.Data;
using MusicStoreCore.Models;

namespace MusicStoreCore.Controllers
{
    public class StoreController : Controller
    {
        readonly IGenreRepository _genreRepository;
        readonly IAlbumRepository _albumRepository;
        private readonly IAlbumViewModelFactory _albumViewModelFactory;

        public StoreController(IGenreRepository genreRepository,
            IAlbumRepository albumRepository,
            IAlbumViewModelFactory albumViewModelFactory)
        {
            _albumRepository = albumRepository;
            _albumViewModelFactory = albumViewModelFactory;
            _genreRepository = genreRepository;
        }

        // GET: Store
        public ActionResult Index()
        {
            var genres = _genreRepository.All();
            return View(genres);
        }

        // GET: Store/Browse/5
        public ActionResult Browse(int id)
        {
            var albums = _albumRepository.GetByGenre(id);

            if (albums == null) return NotFound();

            ViewBag.Genre = _genreRepository.GetById(id).Name;

            return View(albums);
        }

        // GET: Store/Details/5
        public ActionResult Details(int id)
        {
            var album = _albumRepository.GetById(id);

            if (album == null) return NotFound();

            var genre = _genreRepository.GetById(album.GenreId);

            var model = _albumViewModelFactory.Create(album, genre);

            return View(model);
        }
    }
}