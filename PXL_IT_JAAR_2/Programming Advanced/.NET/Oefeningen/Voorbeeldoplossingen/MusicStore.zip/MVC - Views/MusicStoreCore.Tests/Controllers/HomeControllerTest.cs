using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Moq;
using MusicStoreCore.Controllers;
using MusicStoreCore.Services;
using NUnit.Framework;

namespace MusicStoreCore.Tests.Controllers
{
    public class HomeControllerTest
    {
        private Mock<IFileProvider> _fileProviderMock;
        private HomeController _controller;
        private string _routeControllerName;
        private string _routeActionName;
        byte[] _fileBytes;

        [SetUp]
        public void Setup()
        {
            _fileBytes = Guid.NewGuid().ToByteArray();
            _fileProviderMock = new Mock<IFileProvider>();
            _fileProviderMock.Setup(provider => provider.GetFileBytes(It.IsAny<string>())).Returns(_fileBytes);
            _controller = new HomeController(_fileProviderMock.Object);
            SetRandomRouteDataForController();
        }

        private void SetRandomRouteDataForController()
        {
            var routeData = new RouteData();

            _routeControllerName = Guid.NewGuid().ToString();
            routeData.Values["controller"] = _routeControllerName;

            _routeActionName = Guid.NewGuid().ToString();
            routeData.Values["action"] = _routeActionName;

            _controller.ControllerContext = new ControllerContext
            {
                RouteData = routeData
            };
        }

        [Test]
        public void Index_ReturnsDefaultView()
        {
            var result = _controller.Index() as ViewResult;
            Assert.That(result, Is.Not.Null);
            Assert.That(result.ViewName, Is.Null);
        }

        private void AssertIfControllerAndActionNameAreReturnedAsContent(IActionResult actionResult)
        {
            var contentResult = actionResult as ContentResult;

            // Assert
            Assert.That(contentResult, Is.Not.Null);
            Assert.That(contentResult.Content, Is.EqualTo($"{_routeControllerName}:{_routeActionName}"));
        }

        [Test]
        public void About_ReturnsContentContainingControllerNameAndActionName()
        {
            AssertIfControllerAndActionNameAreReturnedAsContent(_controller.About());
        }

        [Test]
        public void Details_ReturnsContentContainingControllerNameActionNameAndParamName()
        {
            // Arrange
            var random = new Random();
            var id = random.Next(1, int.MaxValue);
            _controller.RouteData.Values["id"] = id;

            // Act
            var contentResult = _controller.Details(id) as ContentResult;

            // Assert
            Assert.That(contentResult, Is.Not.Null);
            Assert.That(contentResult.Content, Is.EqualTo($"{_routeControllerName}:{_routeActionName}:{id}"));
        }

        [Test]
        public void Search_Rock_PermanentRedirect()
        {
            // Act
            var redirectResult = _controller.Search("Rock") as RedirectResult;

            // Assert
            Assert.That(redirectResult, Is.Not.Null);
            Assert.That(redirectResult.Permanent, Is.True);
            Assert.That(redirectResult.Url, Is.EqualTo(HomeController.RockUrl));
        }

        [Test]
        public void Search_Jazz_RedirectToIndexAction()
        {
            // Act
            var redirectToRouteResult = _controller.Search("Jazz") as RedirectToActionResult;

            // Assert
            Assert.That(redirectToRouteResult, Is.Not.Null);
            Assert.That(redirectToRouteResult.Permanent, Is.False);
            Assert.That(redirectToRouteResult.ActionName, Is.EqualTo("Index"));
        }

        [Test]
        public void Search_Metal_RedirectToDetailsActionWithARandomId()
        {
            // Act
            var redirectToActionResult = _controller.Search("Metal") as RedirectToActionResult;

            // Assert
            Assert.That(redirectToActionResult, Is.Not.Null);
            Assert.That(redirectToActionResult.Permanent, Is.False);
            Assert.That(redirectToActionResult.ActionName, Is.EqualTo("Details"));
            Assert.That(Convert.ToInt32(redirectToActionResult.RouteValues["id"]), Is.GreaterThanOrEqualTo(0));
        }

        [Test]
        public void Search_Classic_ContentOfSiteCssFile()
        {
            // Act
            var fileResult = _controller.Search("Classic") as FileContentResult;

            // Assert
            Assert.That(fileResult, Is.Not.Null);
            Assert.That(fileResult.ContentType, Is.EqualTo("text/css"));
            Assert.That(fileResult.FileContents, Is.EquivalentTo(_fileBytes));
            Assert.That(fileResult.FileDownloadName, Is.EqualTo("site.css"));
            _fileProviderMock.Verify(provider => provider.GetFileBytes(@"wwwroot\css\site.css"), Times.Once);
        }

        [Test]
        public void Search_UnknownGenre_ReturnsContentContainingControllerNameActionNameAndGenreParameter()
        {
            // Arrange
            var genre = Guid.NewGuid().ToString();

            _controller.RouteData.Values["genre"] = genre;

            // Act
            var contentResult = _controller.Search(genre) as ContentResult;

            // Assert
            Assert.That(contentResult, Is.Not.Null);
            Assert.That(contentResult.Content, Is.EqualTo($"{_routeControllerName}:{_routeActionName}:{genre}"));
        }

    }
}