﻿using MusicStoreCore.Data.DomainClasses;
using System;

namespace MusicStoreCore.Tests.Builders
{
    internal class GenreBuilder
    {
        private Genre _genre;

        public GenreBuilder()
        {
            var r = new Random();
            _genre = new Genre
            {
                Id = r.Next(),
                Name = Guid.NewGuid().ToString()
            };
        }

        public Genre Build()
        {
            return _genre;
        }
    }
}
