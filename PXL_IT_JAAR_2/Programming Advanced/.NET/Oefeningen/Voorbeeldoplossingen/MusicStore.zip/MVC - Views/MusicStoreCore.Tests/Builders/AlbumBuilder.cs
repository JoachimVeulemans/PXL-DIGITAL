﻿using MusicStoreCore.Data.DomainClasses;
using System;

namespace MusicStoreCore.Tests.Builders
{
    internal class AlbumBuilder
    {
        private Album _album;

        public AlbumBuilder()
        {
            var r = new Random();
            _album = new Album
            {
                Id = r.Next(),
                Title = Guid.NewGuid().ToString(),
                Artist = Guid.NewGuid().ToString()
            };
        }

        public AlbumBuilder WithGenreId(int genreId)
        {
            _album.GenreId = genreId;
            return this;
        }

        public Album Build()
        {
            return _album;
        }

    }
}
