﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Moq;
using MusicStoreCore.Controllers;
using MusicStoreCore.Data;
using MusicStoreCore.Data.DomainClasses;
using MusicStoreCore.Models;
using MusicStoreCore.Tests.Builders;
using NUnit.Framework;

namespace MusicStoreCore.Tests.Controllers
{
    [TestFixture]
    public class StoreControllerTests
    {
        private Mock<IGenreRepository> _genreRepositoryMock;
        private Mock<IAlbumRepository> _albumRepositoryMock;
        private Mock<IAlbumViewModelFactory> _albumViewModelFactoryMock;
        private StoreController _controller;
        private Random _random;

        [SetUp]
        public void Setup()
        {
            _genreRepositoryMock = new Mock<IGenreRepository>();
            _albumRepositoryMock = new Mock<IAlbumRepository>();
            _albumViewModelFactoryMock = new Mock<IAlbumViewModelFactory>();
            _controller = new StoreController(_genreRepositoryMock.Object,_albumRepositoryMock.Object , _albumViewModelFactoryMock.Object);
            _random = new Random();
        }

        [Test]
        public void Index_ShowsListOfMusicGenres()
        {
            //Arrange
            var genres = new List<Genre>
            {
                new GenreBuilder().Build()
            };

            _genreRepositoryMock.Setup(repo => repo.All()).Returns(genres);

            //Act
            var viewResult = _controller.Index() as ViewResult;

            //Assert
            Assert.That(viewResult, Is.Not.Null);

            _genreRepositoryMock.Verify(repo => repo.All(), Times.Once());

            Assert.That(viewResult.Model, Is.EquivalentTo(genres));
        }

        [Test]
        public void Browse_ShowsAlbumsOfGenre()
        {
            //Arrange
            var genre = new GenreBuilder().Build();
            var albums = new List<Album>
            {
                new AlbumBuilder().WithGenreId(genre.Id).Build()
            };

            _genreRepositoryMock.Setup(repo => repo.GetById(It.IsAny<int>())).Returns(genre);
            _albumRepositoryMock.Setup(repo => repo.GetByGenre(It.IsAny<int>())).Returns(albums);

            //Act
            var viewResult = _controller.Browse(genre.Id) as ViewResult;

            //Assert
            Assert.That(viewResult, Is.Not.Null);
            _genreRepositoryMock.Verify(repo => repo.GetById(genre.Id), Times.Once());
            _albumRepositoryMock.Verify(repo => repo.GetByGenre(genre.Id), Times.Once());
        
            Assert.That(_controller.ViewBag.Genre, Is.EqualTo(genre.Name));
            Assert.That(viewResult.Model, Is.SameAs(albums));
        }

        [Test]
        public void Browse_InvalidGenreId_ReturnsNotFound()
        {
            //Arrange
            _albumRepositoryMock.Setup(repo => repo.GetByGenre(It.IsAny<int>())).Returns(() => null);

            //Act
            var notFoundResult = _controller.Browse(_random.Next()) as NotFoundResult;

            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
        }

        [Test]
        public void Browse_ValidGenreIdButNoAlbumsForGenre_ShowsEmptyList()
        {
            //Arrange    
            var genre = new GenreBuilder().Build();
            _albumRepositoryMock.Setup(repo => repo.GetByGenre(It.IsAny<int>())).Returns(new List<Album>());
            _genreRepositoryMock.Setup(repo => repo.GetById(It.IsAny<int>())).Returns(genre);

            //Act
            var viewResult = _controller.Browse(genre.Id) as ViewResult;

            //Assert
            Assert.That(viewResult, Is.Not.Null);
            _albumRepositoryMock.Verify(repo => repo.GetByGenre(genre.Id), Times.Once());
            var model = viewResult.Model as IEnumerable<Album>;
            Assert.That(model, Is.Not.Null);
            Assert.That(model.Count(), Is.EqualTo(0));
        }

        [Test]
        public void Details_ShowsDetailsOfAlbum()
        {
            //Arrange
            var genre = new GenreBuilder().Build();
            var album = new AlbumBuilder().WithGenreId(genre.Id).Build();
            var albumViewModel = new AlbumViewModel();

            _albumRepositoryMock.Setup(repo => repo.GetById(It.IsAny<int>())).Returns(album);
            _genreRepositoryMock.Setup(repo => repo.GetById((It.IsAny<int>()))).Returns(genre);
            _albumViewModelFactoryMock.Setup(factory => factory.Create(It.IsAny<Album>(), It.IsAny<Genre>()))
                .Returns(albumViewModel);

            //Act
            var viewResult = _controller.Details(album.Id) as ViewResult;

            //Assert
            Assert.That(viewResult, Is.Not.Null);

            _albumRepositoryMock.Verify(repo => repo.GetById(album.Id), Times.Once);
            _genreRepositoryMock.Verify(repo => repo.GetById(album.GenreId), Times.Once);
            _albumViewModelFactoryMock.Verify(factory => factory.Create(album, genre), Times.Once);

            Assert.That(viewResult.Model, Is.SameAs(albumViewModel));
        }

        [Test]
        public void Details_InvalidId_ReturnsNotFound()
        {
            //Arrange
            _albumRepositoryMock.Setup(repo => repo.GetById(It.IsAny<int>())).Returns(() => null);

            //Act
            var notFoundResult = _controller.Details(_random.Next()) as NotFoundResult;

            //Assert
            Assert.That(notFoundResult, Is.Not.Null);
        }
    }
}
