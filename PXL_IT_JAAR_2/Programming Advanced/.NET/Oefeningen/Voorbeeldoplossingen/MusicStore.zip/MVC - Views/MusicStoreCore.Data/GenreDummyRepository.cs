﻿using System.Collections.Generic;
using System.Linq;
using MusicStoreCore.Data.DomainClasses;

namespace MusicStoreCore.Data
{
    public class GenreDummyRepository : IGenreRepository
    {
        private static readonly List<Genre> _genres = new List<Genre> {
            new Genre
            {
                Id = 1,
                Name = "Metal"
            },
            new Genre
            {
                Id = 2,
                Name = "Pop"
            },
            new Genre
            {
                Id = 3,
                Name = "Jazz"
            }
        };

        public IEnumerable<Genre> All()
        {
            return _genres;
        }

        public Genre GetById(int id)
        {
            return _genres.FirstOrDefault(g => g.Id == id);
        }
    }
}
