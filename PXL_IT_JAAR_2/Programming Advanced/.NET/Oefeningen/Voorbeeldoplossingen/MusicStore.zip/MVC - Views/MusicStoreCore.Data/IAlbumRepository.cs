﻿using MusicStoreCore.Data.DomainClasses;
using System.Collections.Generic;

namespace MusicStoreCore.Data
{
    public interface IAlbumRepository
    {
        IEnumerable<Album> GetByGenre(int genreId);
        Album GetById(int id);
    }
}
