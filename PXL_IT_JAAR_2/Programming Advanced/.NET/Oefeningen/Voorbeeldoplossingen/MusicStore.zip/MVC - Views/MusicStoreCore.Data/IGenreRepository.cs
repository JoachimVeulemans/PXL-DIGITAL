﻿using MusicStoreCore.Data.DomainClasses;
using System.Collections.Generic;

namespace MusicStoreCore.Data
{
    public interface IGenreRepository
    {
        IEnumerable<Genre> All();
        Genre GetById(int albumGenreId);
    }
}
