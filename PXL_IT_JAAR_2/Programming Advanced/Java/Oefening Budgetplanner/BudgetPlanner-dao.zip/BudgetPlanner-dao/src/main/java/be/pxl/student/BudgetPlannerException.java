package be.pxl.student;

public class BudgetPlannerException extends Exception {
	public BudgetPlannerException(Throwable cause) {
		super(cause);
	}
}
