package be.pxl.student.bean;

public class Payment {
}
