package be.pxl.student;

public class BudgetPlannerFeeder {


	public void feedRandomData() {

		// ...

	}
}
