package be.pxl.student.dao;

public class PaymentDao {
}
