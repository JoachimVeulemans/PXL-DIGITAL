package student;

import org.junit.*;

import java.sql.Connection;
import java.sql.SQLException;

public class BeerDaoTest {

    private BeerDao beerDao;

    @Before
    public void setUp() {
            beerDao = new BeerDao("jdbc:h2:mem:StudentDB;MODE=MySQL;INIT=RUNSCRIPT FROM 'classpath:StudentDB - MySQL.sql'", "", "");
    }

    @After
    public void tearDown() {

    }

    @Test
    public void testSelectById() {
        try {
            Beer beer = beerDao.selectById(729);
            Assert.assertEquals("Name compare", "Jupiler", beer.getName());
        } catch(BeerException beerException) {
            beerException.printStackTrace();
        }
    }

    @Test
    public void testUpdateBeer() {
        try {
            Beer beerUpdate = new Beer();
            beerUpdate.setName("Jupiler2");
            beerUpdate.setAlcohol(2.8);
            beerUpdate.setPrice(3.2);
            beerUpdate.setId(729); // choose your id ?

            //updateBeer returns edited Beer
            Beer beer = beerDao.updateBeer(beerUpdate);
            //verification
            Assert.assertEquals("name compare", "Jupiler2", beer.getName());

        } catch(BeerException beerException) {
            beerException.printStackTrace();
        }
    }

}