package student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BeerDao {
    private String url;
    private String user;
    private String password;

    public BeerDao() {
    }

    public BeerDao(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Connection getConnection() throws SQLException {
        return getConnection(url, user, password);
    }

    public Connection getConnection(String url, String user, String password) throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    private Beer updateBeer(Connection connection, Beer beer) throws SQLException {
        connection.setAutoCommit(false);
        PreparedStatement updateStatement = connection.prepareStatement("UPDATE beers SET Price = ?, Alcohol = ?, Name = ? WHERE Id = ?;");

        updateStatement.setDouble(1, beer.getPrice());
        updateStatement.setDouble(2, beer.getAlcohol());
        updateStatement.setString(3, beer.getName());
        updateStatement.setInt(4, beer.getId());
        updateStatement.executeUpdate();
        connection.commit();
        return selectById(connection, beer.getId());
    }

    public Beer updateBeer(Beer beer) throws BeerException {
        Beer output;
        try (Connection connection = getConnection()) {
            try {
                output = updateBeer(connection, beer);
            } catch (SQLException e) {
                connection.rollback();
                throw new BeerException(e);
            }
        } catch (SQLException exc) {
            throw new BeerException(exc);
        }
        return output;
    }

    private List<Beer> selectAllBeers(Connection connection) throws SQLException{
        connection.setAutoCommit(false);
        List<Beer> beerList = new ArrayList<>();
        String select = "SELECT * FROM Beers;";
        PreparedStatement selectStatement = connection.prepareStatement(select);
        ResultSet rs = selectStatement.executeQuery();
        connection.commit();

        while (rs.next()) {
            Beer addBeer = new Beer(rs.getString("Name"), rs.getDouble("Alcohol"), rs.getDouble("Price"), rs.getInt("categoryId"), rs.getInt("stock"), rs.getInt("brewerId"));
            beerList.add(addBeer);
        }
        return beerList;
    }

    public List<Beer> selectAllBeers() throws BeerException {
        try (Connection connection = getConnection()) {
            try {
                return selectAllBeers(connection);
            } catch (SQLException e) {
                connection.rollback();
                throw new BeerException(e);
            }
        } catch (SQLException exc) {
            throw new BeerException(exc);
        }
    }

    private Beer selectById(Connection connection, int beerId) throws SQLException {
        connection.setAutoCommit(false);
        Beer beer = null;
        String select = "SELECT * FROM Beers WHERE Id = ?;";
        PreparedStatement selectStatement = connection.prepareStatement(select);
        selectStatement.setInt(1, beerId);
        ResultSet rs = selectStatement.executeQuery();
        connection.commit();
        if(rs.next()) {
            beer = new Beer(rs.getString("Name"), rs.getDouble("Alcohol"), rs.getDouble("Price"), rs.getInt("categoryId"), rs.getInt("stock"), rs.getInt("brewerId"));
            beer.setId(beerId);
        }
        return beer;
    }

    public Beer selectById(int beerId) throws BeerException {
        try (Connection connection = getConnection()) {
            try {
                return selectById(connection, beerId);
            } catch (SQLException e) {
                connection.rollback();
                throw new BeerException(e);
            }
        } catch (SQLException exc) {
            throw new BeerException(exc);
        }
    }
}
