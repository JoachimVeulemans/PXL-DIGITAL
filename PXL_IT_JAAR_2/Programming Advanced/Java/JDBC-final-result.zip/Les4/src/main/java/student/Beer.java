package student;

public class Beer {
    private String name;
    private Double alcohol;
    private Double price;
    private Integer CategoryId;
    private Integer stock;
    private Integer brewerId;
    private Integer Id;

    public Beer() {
    }

    public Beer(String name, Double alcohol, Double price, Integer categoryId, Integer stock, Integer brewerId) {
        this.name = name;
        this.alcohol = alcohol;
        this.price = price;
        CategoryId = categoryId;
        this.stock = stock;
        this.brewerId = brewerId;
    }

    public Beer(String name, Double alcohol, Double price) {
        this.name = name;
        this.alcohol = alcohol;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getAlcohol() {
        return alcohol;
    }

    public void setAlcohol(Double alcohol) {
        this.alcohol = alcohol;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCategoryId() {
        return CategoryId;
    }

    public void setCategoryId(Integer categoryId) {
        CategoryId = categoryId;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Integer getBrewerId() {
        return brewerId;
    }

    public void setBrewerId(Integer brewerId) {
        this.brewerId = brewerId;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    @Override
    public String toString() {
        return "Beer{" +
                "name='" + name + '\'' +
                ", alcohol=" + alcohol +
                ", price=" + price +
                ", CatgoryId=" + CategoryId +
                ", stock=" + stock +
                ", brewerId=" + brewerId +
                '}';
    }
}
