/**
 * The package <b>be.pxl.h16.voorbeeld</b> contains classes and  
 * interfaces which represent graphical shapes
 */

package be.pxl.h16.voorbeeld;

