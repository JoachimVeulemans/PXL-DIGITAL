package be.pxl.vraag2;

//Angillis Ian

import java.awt.print.Paper;
import java.util.Random;

public class Vraag2 {

	public static void main(String[] args) {
		//Maakt een object aan van de klasse paper
		Paper bladPapier = new Paper();
		Random rand = new Random();
		int x;
		int y;
		
		//Zorgt ervoor dat het object een A3 formaat krijgt
		bladPapier.setSize(842,  1191);
		
		x = rand.nextInt(72 - 36 + 1) + 36;
		y = rand.nextInt(40 - 10) + 10;
		
		bladPapier.setImageableArea(x, y, x, y);
		
		System.out.println("Afmetingen van het imagineable deel");
		System.out.println(bladPapier.getImageableX());
		System.out.println(bladPapier.getImageableY());
		System.out.println(bladPapier.getImageableHeight());
		System.out.println(bladPapier.getImageableWidth());
		
	}

}
