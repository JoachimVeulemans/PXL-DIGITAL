package be.pxl.vraag3;

//Angillis Ian
import java.util.Scanner;

public class Vraag3 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		StringBuilder tempstring2 = new StringBuilder("");
		String finalString = new String("");
		String tempString = new String("");
		String prijsString = new String("");
		double prijsKamer;
		double totaalPrijs = 0;
		int totaalAantalPlanken = 0;
		int aantalPlanken;
		int aantalKamers;
		double lengte;
		double breedte;
		double plankBreedte;
		String plankType = new String("");
		int index;

		System.out.println("Geef het aantal kamers in");
		aantalKamers = keyboard.nextInt();

		for (int i = 0; i < aantalKamers; i++) {

			System.out.println("Geef de gegevens van kamer " + (i + 1));
			System.out.println("Geef de lengte in cm");
			lengte = keyboard.nextDouble();

			System.out.println("Geef de breedte in cm");
			breedte = keyboard.nextDouble();

			System.out.println("Geef type plank in");
			plankType = keyboard.next();

			plankBreedte = getPlankBreedte(plankType);

			aantalPlanken = berekenAantalPlanken(lengte, breedte, plankBreedte);
			
			totaalAantalPlanken += aantalPlanken;
			
			prijsKamer = berekenKamerPrijs(plankType, aantalPlanken, plankBreedte);	
			totaalPrijs += prijsKamer;
			prijsString = prijsKamer + "";
			prijsString = prijsString.substring(0, prijsString.indexOf(".") + 3);
			
			tempString = "Het aantal planken voor kamer " + (i+1) + " van het type " + plankType + " is " + aantalPlanken + " prijs �" + prijsString + "#";
			tempstring2.append(tempString);

		}
		
		finalString = tempstring2.toString();
		
		for(int i = 0; i < aantalKamers; i++){
			
			index = finalString.indexOf("#");
			tempString = finalString.substring(0, index);
			System.out.println(tempString);
			finalString = finalString.substring(index+1);
		}
		
		System.out.println("Het totaal aantal planken is " + totaalAantalPlanken);
		System.out.printf("Te betalen: � %.2f \n", totaalPrijs);

		keyboard.close();
	}
	
	public static double berekenKamerPrijs(String plankType, int aantalPlanken, double  plankBreedte) {
		double oppervlakte = ((125 * plankBreedte) * 43) / 10;
		double prijsPerVierkanteMeter;
		int containsX = 0;
		double kamerPrijs;
		
		for(int i = 0; i < plankType.length(); i++) {
			
			if(plankType.charAt(i) == 'x') {
				containsX++;
			}
		}
		
		if(containsX == 1) {
			prijsPerVierkanteMeter = 31.99;
		} else {
			prijsPerVierkanteMeter = 20.49;
		}
		
		kamerPrijs = oppervlakte / prijsPerVierkanteMeter;
		return kamerPrijs;
	}

	public static int berekenAantalPlanken(double lengte, double breedte, double plankBreedte) {

		int aantalPlanken = 0;
		double aantalRijen = breedte / plankBreedte;
	
		
		if(aantalRijen > (int)aantalRijen) {
			aantalRijen = (int) aantalRijen + 1;
		} else {
			aantalRijen = (int) aantalRijen;
		}
		
		double totaalLengte = aantalRijen * lengte;
		
		while(totaalLengte > 0) {
			totaalLengte -= 125;
			aantalPlanken++;
		}
		
		return aantalPlanken;
	}

	public static double getPlankBreedte(String plankType) {
		double breedte;

		if (plankType.toUpperCase().endsWith("S")) {

			breedte = 12.80;
		} else if (plankType.toUpperCase().endsWith("M")) {

			breedte = 20.50;
		} else if (plankType.toUpperCase().endsWith("L")) {

			breedte = 26.00;
		} else {

			breedte = 33.00;
		}

		return breedte;
	}

}
