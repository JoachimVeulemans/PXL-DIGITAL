package be.pxl.vraag1;

//Angillis Ian

import java.util.Scanner;

public class Vraag1 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		String[] deelnemersNummers = new String[100];
		String[] drankCategorieen = { "1. water", "2. frisdrank en fruitsap", "3. koffie/thee", "4. wijn/bier",
				"5. sterke drank" };
		String deelnemersnummer = new String("");
		int[] totaalAantalConsumpties = new int[5];

		int drankCategorie;
		int aantalConsumpties;
		int aantalDeelnemers = 0;
		int aantalDeelnemersSterkeDrank = 0;

		double percentageSterkeDrank;

		System.out.println("Geef je deelnemersnr (e, E, s of S om te eindigen)");
		deelnemersnummer = keyboard.next();

		while (deelnemerHeeftAlDeelgenomen(deelnemersnummer, deelnemersNummers, aantalDeelnemers)) {
			System.out.println("u heeft reeds deelgenomen.");
			System.out.println("Geef je deelnemersnr (e, E, s of S om te eindigen)");
			deelnemersnummer = keyboard.next();
		}

		while (!(deelnemersnummer.toUpperCase().equals("E") || deelnemersnummer.toUpperCase().equals("S")
				)) {

			deelnemersNummers[aantalDeelnemers] = deelnemersnummer;
			aantalDeelnemers++;

			System.out.println(
					"Kies een drankcategorie en geef vervolgens het aantal consumpties in drankcatagorienr (9 = eigen)");
			toonCategorieen(drankCategorieen);
			drankCategorie = keyboard.nextInt();
			
			while (drankCategorie != 9) {

				if (drankCategorie == 5) {
					aantalDeelnemersSterkeDrank++;
				}

				System.out.println("aantal consumpties");
				aantalConsumpties = keyboard.nextInt();

				totaalAantalConsumpties[drankCategorie - 1] += aantalConsumpties;

				System.out.println(
						"Kies een drankcategorie en geef vervolgens het aantal consumpties in drankcatagorienr (9 = eigen)");
				toonCategorieen(drankCategorieen);
				drankCategorie = keyboard.nextInt();
			}

			System.out.println("Geef je deelnemersnr (e, E, s of S om te eindigen)");
			deelnemersnummer = keyboard.next();

			while (deelnemerHeeftAlDeelgenomen(deelnemersnummer, deelnemersNummers, aantalDeelnemers)) {
				System.out.println("u heeft reeds deelgenomen.");
				System.out.println("Geef je deelnemersnr (e, E, s of S om te eindigen)");
				deelnemersnummer = keyboard.next();
			}

		}

		// Bereken het percentage dat sterke drank drinkt
		percentageSterkeDrank = ((double) aantalDeelnemersSterkeDrank / aantalDeelnemers) * 100;

		// Print per categorie het totaal aantal consumpties
		System.out.println("Totaal aantal consumpties op een werkdag: ");
		for (int i = 0; i < drankCategorieen.length; i++) {
			System.out.printf("%-26s : %-4d \n", drankCategorieen[i], totaalAantalConsumpties[i]);
		}

		System.out.printf("Percentage van de deelnemers dat sterke drank drinkt : %.2f \n", percentageSterkeDrank);

		keyboard.close();
	}

	public static void toonCategorieen(String[] drankCategorieen) {

		for (String drankCategorie : drankCategorieen) {
			System.out.println(drankCategorie);
		}
	}

	public static boolean deelnemerHeeftAlDeelgenomen(String deelnemersnummer, String[] deelnemersNummers,
			int aantalDeelnemers) {

		for (int i = 0; i < aantalDeelnemers; i++) {

			if (deelnemersnummer.equals(deelnemersNummers[i])) {
				return true;
			}

		}

		return false;

	}

}
