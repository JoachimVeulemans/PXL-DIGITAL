var stadions = [
	{lat: 55.7158863, long: 37.5070319, name: "Luzhniki", city: "Moskou", cap: 81006, img: "http://stadiumdb.com/pic-buildings/rus/luzhniki/luzhniki177.jpg"},
    {lat: 59.9727307, long: 30.2192158, name: "Zenit Arena", city: "Sint-Petersburg", cap: 68134, img: "http://stadiumdb.com/pic-buildings/rus/gazprom_arena/gazprom_arena651.jpg"},
    {lat: 43.4020701, long: 39.9537504, name: "Fisht Olympic Stadium", city: "Sochi", cap: 47659, img: "http://stadiumdb.com/pic-buildings/rus/sochi_olympic_stadium/sochi_olympic_stadium372.jpg"},
    {lat: 48.7345449, long: 44.5463401, name: "Volgograd Arena", city: "Volgograd", cap: 45568, img: "http://stadiumdb.com/pic-buildings/rus/volgograd_arena/volgograd_arena198.jpg"},
	{lat: 56.3372902, long: 43.961062, name: "Stadion Nizhny Novgorod", city: "Nizhny Novgorod", cap: 45331, img: "http://stadiumdb.com/pic-buildings/rus/stadion_nizhny_novgorod/stadion_nizhny_novgorod204.jpg"},
	{lat: 47.2095847, long: 39.7362356, name: "Rostov Arena", city: "Rostov-on-Don", cap: 45145, img: "http://stadiumdb.com/pic-buildings/rus/rostov_arena/rostov_arena191.jpg"},
	{lat: 55.820986, long: 49.1587774, name: "Kazan Arena", city: "Kazan", cap: 45105, img: "http://stadiumdb.com/pic-buildings/rus/stadion_rubina_kazan/stadion_rubina_kazan331.jpg"},
	{lat: 53.2781358, long: 50.235292, name: "Samara Arena", city: "Samara", cap: 44918, img: "http://stadiumdb.com/pic-buildings/rus/samara_arena/samara_arena241.jpg"},
	{lat: 54.1817979, long: 45.2016627, name: "Mordovia Arnoa", city: "Saransk", cap: 44442, img: "http://stadiumdb.com/pic-buildings/rus/stadion_yubileyniy_saransk/stadion_yubileyniy_saransk271.jpg"},
	{lat: 55.8177683, long: 37.438174, name: "Otkritie Arena", city: "Moskou", cap: 44000, img: "http://stadiumdb.com/pic-buildings/rus/stadion_spartak/stadion_spartak303.jpg"},
	{lat: 56.8324789, long: 60.5713934, name: "Tsentralnyj Stadion", city: "Yekaterinburg", cap: 35696, img: "http://stadiumdb.com/pic-buildings/rus/tsentralnyi_stadion_ekaterinburg/tsentralnyi_stadion_ekaterinburg245.jpg"},
	{lat: 54.6980452, long: 20.530098, name: "Stadion Kaliningrad", city: "Kaliningrad", cap: 35212, img: "http://stadiumdb.com/pic-buildings/rus/stadion_kaliningrad/stadion_kaliningrad145.jpg"}
]