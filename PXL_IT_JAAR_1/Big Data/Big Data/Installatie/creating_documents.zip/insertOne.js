db.moviesScratch.insertOne({ "title": "Rocky", "year": "1976", "imdb": "tt0075148"});
db.moviesScratch.insertOne({ "_id": "tt0075148", "title": "Rocky", "year": "1976" });
