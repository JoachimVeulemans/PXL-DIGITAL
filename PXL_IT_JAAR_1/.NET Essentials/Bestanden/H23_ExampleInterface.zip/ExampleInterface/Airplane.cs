﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace ExampleInterface
{
    class Airplane : IFlying
    {
        private int mps = 100;
        private int numberOfPassengers;
        private string code;
        private Image planeImage;

        public Airplane(int numberOfPassengers, string code)
        {
            this.numberOfPassengers = numberOfPassengers;
            this.code = code;
        }

        public int Mps
        {
            get
            {
                return mps;
            }
        }

        public void Fly()
        {
            planeImage.Margin = new Thickness(50, 15, 0, 0);
        }

        public void Land()
        {
            planeImage.Margin = new Thickness(50, 150, 0, 0);
        }

        public void DisplayOn(Canvas canvas)
        {
            planeImage = new Image();
            planeImage.Source = new BitmapImage(new Uri(@"airplane.png", UriKind.RelativeOrAbsolute));
            planeImage.Margin = new Thickness(50, 150, 0, 0);
            planeImage.Width = 150;
            planeImage.Height = 150;
            canvas.Children.Add(planeImage);
        }

    }
}
