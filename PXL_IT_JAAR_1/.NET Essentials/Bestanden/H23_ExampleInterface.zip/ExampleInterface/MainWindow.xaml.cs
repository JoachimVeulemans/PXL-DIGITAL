﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ExampleInterface
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Airplane airplane;
        private Bat bat;

        public MainWindow()
        {
            InitializeComponent();
            airplane = new Airplane(220, "BXL123");
            airplane.DisplayOn(canvas);
            bat = new Bat();
            bat.DisplayOn(canvas);
            
        }

        private void flyButton_Click(object sender, RoutedEventArgs e)
        {
            airplane.Fly();
            bat.Fly();
        }


        private void landButton_Click(object sender, RoutedEventArgs e)
        {
            airplane.Land();
            bat.Land();
        }

        private void soundButton_Click(object sender, RoutedEventArgs e)
        {
            bat.MakeSound();
        }
    }
}
