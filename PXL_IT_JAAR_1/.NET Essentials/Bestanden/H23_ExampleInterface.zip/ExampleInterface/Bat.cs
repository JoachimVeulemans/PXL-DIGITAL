﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ExampleInterface
{
    class Bat : IFlying, IAnimal
    {
        private Image batImage;
        private SoundPlayer batSound;

        public Bat()
        {
            batSound = new SoundPlayer(@"..\..\bats.wav");
        }

        public int Mps
        {
            get
            {
                return 15;
            }
        }

        public void DisplayOn(Canvas canvas)
        {
            batImage = new Image();
            batImage.Source = new BitmapImage(new Uri(@"bat.png", UriKind.RelativeOrAbsolute));
            batImage.Margin = new Thickness(200, 150, 0, 0);
            batImage.Width = 150;
            batImage.Height = 150;
            canvas.Children.Add(batImage);
        }

        public void Fly()
        {
            batImage.Margin = new Thickness(200, 15, 0, 0);
        }

        public void Land()
        {
            batImage.Margin = new Thickness(200, 150, 0, 0);
        }

        public void MakeSound()
        {
            
            batSound.Play();
        }
    }
}
