﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatternsLabOef2
{
    public class RighthandedBehavior : IJoyStickBehavior
    {
        public void JoystickUp()
        {
            Console.WriteLine("Go up!");
        }

        public void JoystickDown()
        {
            Console.WriteLine("Go down!");
        }

        public void JoystickLeft()
        {
            Console.WriteLine("Go left!");
        }

        public void JoystickRight()
        {
            Console.WriteLine("Go right!");
        }
    }
}
