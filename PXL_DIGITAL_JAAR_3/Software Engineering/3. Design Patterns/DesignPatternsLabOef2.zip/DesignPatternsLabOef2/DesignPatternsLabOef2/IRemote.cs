﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatternsLabOef2
{
    public interface IRemote
    {
        public IJoyStickBehavior JoyStickBehavior { get; set; }

        void JoystickUp(); 
        void JoystickDown(); 
        void JoystickLeft(); 
        void JoystickRight(); 
        virtual void  ButtonA_Click()
        {
            Console.WriteLine("Dancing!!");
        }
    }
}
