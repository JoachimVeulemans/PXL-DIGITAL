﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatternsLabOef2
{
    public class ConcreteRemote : IRemote
    {
        public IJoyStickBehavior JoyStickBehavior { get; set; }
        public void JoystickUp()
        {
            JoyStickBehavior.JoystickUp();
        }

        public void JoystickDown()
        {
            JoyStickBehavior.JoystickDown();
        }

        public void JoystickLeft()
        {
            JoyStickBehavior.JoystickLeft();
        }

        public void JoystickRight()
        {
            JoyStickBehavior.JoystickRight();
        }
    }
}
