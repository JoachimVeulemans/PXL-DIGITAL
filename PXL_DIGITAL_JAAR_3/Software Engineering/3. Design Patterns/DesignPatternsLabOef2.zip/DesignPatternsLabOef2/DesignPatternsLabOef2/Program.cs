﻿using System;

namespace DesignPatternsLabOef2
{
    class Program
    {
        static void Main(string[] args)
        {
            IRemote remote = new ConcreteRemote();
            remote.JoyStickBehavior = new RighthandedBehavior();

            Console.WriteLine("*** RIGHT HANDED ***");
            remote.ButtonA_Click();
            remote.JoystickUp();
            remote.JoystickDown();
            remote.JoystickLeft();
            remote.JoystickRight();

            remote.JoyStickBehavior = new LefthandedBehavior();
            Console.WriteLine("*** LEFT HANDED ***");
            remote.ButtonA_Click();
            remote.JoystickUp();
            remote.JoystickDown();
            remote.JoystickLeft();
            remote.JoystickRight();
        }

    }
}
