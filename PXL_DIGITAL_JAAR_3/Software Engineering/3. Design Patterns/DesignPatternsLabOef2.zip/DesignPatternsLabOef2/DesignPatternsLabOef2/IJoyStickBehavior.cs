﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatternsLabOef2
{
    public interface IJoyStickBehavior
    {
        void JoystickUp();
        void JoystickDown();
        void JoystickLeft();
        void JoystickRight();
    }
}
