﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatternsLabOef2
{
    public class LefthandedBehavior : IJoyStickBehavior
    {
        public void JoystickUp()
        {
            Console.WriteLine("Go down!");
        }

        public void JoystickDown()
        {
            Console.WriteLine("Go up!");
        }

        public void JoystickLeft()
        {
            Console.WriteLine("Go right!");
        }

        public void JoystickRight()
        {
            Console.WriteLine("Go left!");
        }
    }
}
