﻿using System;

namespace StateExercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            var controller = new Controller();

            controller.ButtonPressed();

            controller.SwitchOn();
            controller.ButtonPressed();
            controller.ButtonPressed();
            controller.SwitchOff();
            controller.SwitchOn();
            controller.ButtonPressed();
            controller.ButtonPressed();
            controller.ButtonPressed();
            controller.ButtonPressed();
            controller.SwitchOff();
            controller.ButtonPressed();
        }
    }
}
