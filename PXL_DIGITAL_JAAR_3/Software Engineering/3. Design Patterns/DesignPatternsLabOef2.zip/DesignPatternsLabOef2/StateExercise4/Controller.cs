﻿using System;
using System.Collections.Generic;
using System.Text;
using StateExercise4.States;

namespace StateExercise4
{
    public class Controller
    {
        private State _currentState;
        private State _lastKnownState;
        public State AllOnState { get; }
        public State BlinkingState { get; }
        public State StartLightState { get; }
        public State WaveState { get; }
        public State NoState { get; }
        public State DiscoState { get; }

        public Controller()
        {
            AllOnState = new AllOnState(this);
            BlinkingState = new BlinkingState(this);
            StartLightState = new StartLightState(this);
            WaveState = new WaveState(this);
            DiscoState = new DiscoState(this);
            NoState = new NoState();
            SwitchOff();
            _lastKnownState = AllOnState;
        }

        public void SetState(State state)
        {
            _currentState = state;
        }

        public void ButtonPressed()
        {
            _currentState.PressButton();
        }

        public void SwitchOn()
        {
            _currentState = _lastKnownState;
        }

        public void SwitchOff()
        {
            _lastKnownState = _currentState;
            _currentState = NoState;
        }
    }
}
