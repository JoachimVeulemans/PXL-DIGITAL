﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4.States
{
    public class BlinkingState : State
    {
        private readonly Controller _controller;

        public BlinkingState(Controller controller)
        {
            _controller = controller;
        }


        public void PressButton()
        {
            Console.WriteLine("BLINKING");
            _controller.SetState(_controller.StartLightState);
        }
    }
}
