﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4.States
{
    public class WaveState : State
    {
        private readonly Controller _controller;

        public WaveState(Controller controller)
        {
            _controller = controller;
        }
        public void PressButton()
        {
            Console.WriteLine("WAVESTATE");
            _controller.SetState(_controller.DiscoState);
        }
    }
}
