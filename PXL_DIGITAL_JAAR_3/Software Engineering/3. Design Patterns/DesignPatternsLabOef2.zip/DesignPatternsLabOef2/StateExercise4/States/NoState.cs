﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4.States
{
    public class NoState : State
    {
        public void PressButton()
        {
            
        }
    }
}
