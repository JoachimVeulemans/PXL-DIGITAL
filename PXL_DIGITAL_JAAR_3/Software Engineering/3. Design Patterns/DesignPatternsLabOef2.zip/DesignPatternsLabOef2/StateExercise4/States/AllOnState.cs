﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4.States
{
    public class AllOnState : State
    {
        private readonly Controller _controller;
        public AllOnState(Controller controller)
        {
            _controller = controller;
        }

        public void PressButton()
        {
            Console.WriteLine("ALL_ON");
            _controller.SetState(_controller.BlinkingState);
        }
    }
}
