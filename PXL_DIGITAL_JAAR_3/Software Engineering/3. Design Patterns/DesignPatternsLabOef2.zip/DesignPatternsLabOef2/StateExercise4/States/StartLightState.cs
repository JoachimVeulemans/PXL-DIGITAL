﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4.States
{
    public class StartLightState : State
    {
        private readonly Controller _controller;

        public StartLightState(Controller controller)
        {
            _controller = controller;
        }
        public void PressButton()
        {
            Console.WriteLine("STARTLIGHTSTATE");
            _controller.SetState(_controller.WaveState);
        }
    }
}
