﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4
{
    public interface State
    {
        void PressButton();
    }
}
