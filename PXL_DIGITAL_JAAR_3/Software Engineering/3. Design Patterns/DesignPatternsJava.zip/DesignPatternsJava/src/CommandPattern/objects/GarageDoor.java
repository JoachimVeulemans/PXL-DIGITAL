package CommandPattern.objects;

public class GarageDoor {
    private String name;

    public GarageDoor(String name){
        this.name = name;
    }

    public void up(){
        System.out.println(name + " Garage door is up");
    }

    public void down(){
        System.out.println(name + " Garage door is down");
    }

    public void lightOn(){
        System.out.println(name + " Garage door light is on");
    }

    public void lightOff(){
        System.out.println(name + " Garage door light is off");
    }
}
