package CommandPattern.objects;

public class Stereo {
    private String name;
    private int volume = 0;

    public Stereo(String name){
        this.name = name;
    }

    public void on(){
        System.out.println(name + " Stereo is on");
    }

    public void off(){
        System.out.println(name + " Stereo is off");
    }

    public void setCd(){
        System.out.println(name + " Stereo CD is set");
    }

    public void setDvd(){
        System.out.println(name + " Stereo DVD is set");
    }

    public void setRadio(){
        System.out.println(name + " Stereo radio is set");
    }

    public void setVolume(int volume){
        this.volume = volume;
        System.out.println(name + " Stereo volume is set to " + volume);
    }
}
