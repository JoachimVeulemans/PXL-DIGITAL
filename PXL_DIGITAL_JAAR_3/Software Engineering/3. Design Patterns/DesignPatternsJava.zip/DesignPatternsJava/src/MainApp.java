import CommandPattern.RemoteControl;
import CommandPattern.commands.*;
import CommandPattern.objects.CeilingFan;
import CommandPattern.objects.GarageDoor;
import CommandPattern.objects.Light;
import CommandPattern.objects.Stereo;
import CompositeIteratorPattern.*;
import CompositeIteratorPattern.iterators.Menu;
import DecoratorPattern.beverages.Beverage;
import DecoratorPattern.beverages.DarkRoast;
import DecoratorPattern.beverages.Espresso;
import DecoratorPattern.beverages.HouseBlend;
import DecoratorPattern.condiments.Mocha;
import DecoratorPattern.condiments.Soy;
import DecoratorPattern.condiments.Whip;
import FactoryPattern.ChicagoPizzaStore;
import FactoryPattern.NYPizzaStore;
import FactoryPattern.Pizza;
import FactoryPattern.PizzaStore;
import ObservablePattern.CurrentConditionDisplay;
import ObservablePattern.StatisticsDisplay;
import ObservablePattern.WeatherData;
import SingletonPattern.ChocolateBoiler;
import StatePattern.GumballMachine;
import StrategyPattern.behaviors.flybehavior.FlyRocketPowered;
import StrategyPattern.models.MallardDuck;
import StrategyPattern.models.ModelDuck;
import TemplateMethodPattern.Coffee;
import TemplateMethodPattern.CoffeeWithHook;
import TemplateMethodPattern.Duck;
import TemplateMethodPattern.Tea;

import java.util.ArrayList;
import java.util.Arrays;

public class MainApp {
    public static void main(String[] args) {

        demonstrateStrategyPattern();
        //demonstrateObservablePattern();
        //demonstrateDecoratorPattern();
        //demonstrateFactoryMethodPattern();
        //demonstrateSingletonPattern();
        //demonstrateCommandPattern();
        //demonstrateTemplateMethodPattern();
        //demonstrateIteratorPattern();
        demonstrateStatePattern();

    }

    public static void demonstrateStrategyPattern(){
        System.out.println("*** STRATEGY PATTERN ***");
        var mallard = new MallardDuck();
        mallard.performQuack();
        mallard.performFly();

        var modelDuck = new ModelDuck();
        modelDuck.performFly();
        modelDuck.setFlyBehavior(new FlyRocketPowered());
        modelDuck.performFly();

        System.out.println();
    }
    public static void demonstrateObservablePattern(){
        System.out.println("*** OBSERVER PATTERN ***");

        var weatherData = new WeatherData();

        var currentConditionsDisplay = new CurrentConditionDisplay(weatherData);
        var statisticsDisplay = new StatisticsDisplay(weatherData);

        weatherData.setMeasurements(80,65,30.4f);
        weatherData.setMeasurements(82,70,29.2f);
        weatherData.setMeasurements(78,90,29.2f);

        System.out.println();
    }
    public static void demonstrateDecoratorPattern(){
        System.out.println("*** DECORATOR PATTERN ***");

        Beverage beverage1 = new Espresso();
        System.out.println(beverage1.getDescription() + " $" + beverage1.cost());

        Beverage beverage2 = new DarkRoast();
        beverage2 = new Mocha(beverage2);
        beverage2 = new Mocha(beverage2);
        beverage2 = new Whip(beverage2);
        System.out.println(beverage2.getDescription() + " $" + beverage2.cost());

        Beverage beverage3 = new HouseBlend();
        beverage3 = new Soy(beverage3);
        beverage3 = new Mocha(beverage3);
        beverage3 = new Whip(beverage3);
        System.out.println(beverage3.getDescription() + " $" + beverage3.cost());

        System.out.println();
    }
    public static void demonstrateFactoryMethodPattern(){
        System.out.println("*** FACTORY METHOD PATTERN ***");

        PizzaStore nyStore = new NYPizzaStore();
        PizzaStore chicagoStore = new ChicagoPizzaStore();

        Pizza pizza = nyStore.orderPizza("cheese");
        System.out.println("Ethan ordered a " + pizza.getName() + "\n");

//        pizza = chicagoStore.orderPizza("cheese");
//        System.out.println("Joel ordered a " + pizza.getName() + "\n");

        System.out.println();
    }
    public static void demonstrateSingletonPattern(){
        System.out.println("*** SINGLETON PATTERN ***");

        var chocolateBoiler1 = ChocolateBoiler.getInstance();
        var chocolateBoiler2 = ChocolateBoiler.getInstance();

        if(chocolateBoiler1 == chocolateBoiler2){
            System.out.println("Same instance");
        }else{
            System.out.println("Definitely not a singleton pattern, two instances exist!!!");
        }

        System.out.println();
    }
    public static void demonstrateCommandPattern(){
        System.out.println("*** COMMAND PATTERN ***");

        var remoteControl = new RemoteControl();

        var livingRoomLight = new Light("Living Room");
        var kitchenLight = new Light("Kitchen");
        var ceilingFan = new CeilingFan("Living Room");
        var garageDoor = new GarageDoor("");
        var stereo = new Stereo("Living Room");

        var livingRoomLightOnCommand = new LightOnCommand(livingRoomLight);
        var livingRoomLightOffCommand = new LightOffCommand(livingRoomLight);
        var kitchenLightOnCommand = new LightOnCommand(kitchenLight);
        var kitchenLightOffCommand = new LightOffCommand(kitchenLight);

        var ceilingFanOnCommand = new CeilingFanHighCommand(ceilingFan);
        var ceilingFanOffCommand = new CeilingFanOffCommand(ceilingFan);

        var garageDoorOpenCommand = new GarageDoorOpenCommand(garageDoor);
        var garageDoorCloseCommand = new GarageDoorCloseCommand(garageDoor);

        var stereoWithCDOnCommand = new StereoOnWithCDCommand(stereo);
        var stereoOffCommand = new StereoOffCommand(stereo);

        remoteControl.setCommand(0, livingRoomLightOnCommand, livingRoomLightOffCommand);
        remoteControl.setCommand(1, kitchenLightOnCommand, kitchenLightOffCommand);
        remoteControl.setCommand(2, ceilingFanOnCommand, ceilingFanOffCommand);
        remoteControl.setCommand(3, stereoWithCDOnCommand, stereoOffCommand);

        System.out.println(remoteControl);

        remoteControl.onButtonWasPressed(0);
        remoteControl.offButtonWasPressed(0);
        remoteControl.onButtonWasPressed(1);
        remoteControl.offButtonWasPressed(1);
        remoteControl.onButtonWasPressed(2);
        remoteControl.offButtonWasPressed(2);
        remoteControl.onButtonWasPressed(3);
        remoteControl.offButtonWasPressed(3);

        System.out.println("*** INCLUDING UNDO ***");
        remoteControl.onButtonWasPressed(0);
        remoteControl.offButtonWasPressed(0);
        System.out.println(remoteControl);
        remoteControl.undoButtonWasPressed();
        remoteControl.offButtonWasPressed(0);
        remoteControl.onButtonWasPressed(0);
        System.out.println(remoteControl);
        remoteControl.undoButtonWasPressed();

        System.out.println();

    }
    public static void demonstrateTemplateMethodPattern(){
        System.out.println("*** TEMPLATE METHOD PATTERN ***");

        var coffee = new Coffee();
        var tea = new Tea();

        System.out.println("Preparing Coffee");
        coffee.prepareRecipe();
        System.out.println();
        System.out.println("Preparing Tea");
        tea.prepareRecipe();

        System.out.println();
        System.out.println("With hooks");

        var coffeeWithHook = new CoffeeWithHook();

        System.out.println("\nMaking coffee...");
        coffeeWithHook.prepareRecipe();

        System.out.println("Real-life example: sorting with Comparable implementation");
        Duck[] ducks = {
                new Duck("Daffy", 8),
                new Duck("Dewey", 2),
                new Duck("Howard", 7),
                new Duck("Louie", 2),
                new Duck("Donald", 10),
                new Duck("Huey", 2)
        };

        System.out.println("Before sorting:");
        for(var duck : ducks){
            System.out.println(duck);
        }

        Arrays.sort(ducks);

        System.out.println("\nAfter sorting:");
        for(var duck : ducks){
            System.out.println(duck);
        }

        System.out.println();
    }
    public static void demonstrateIteratorPattern(){
        MenuComponent pancakeHouseMenu = new Menu("PANCAKE HOUSE MENY", "Breakfast");
        MenuComponent dinerMenu = new Menu("DINER MENU", "Lunch");
        MenuComponent cafeMenu = new Menu("CAFE MENU", "Dinner");
        MenuComponent dessertMenu = new Menu("DESSERT MENU", "Dessert");

        MenuComponent allMenus = new Menu("ALL MENUS", "All menus combined");

        allMenus.add(pancakeHouseMenu);
        allMenus.add(dinerMenu);
        allMenus.add(cafeMenu);

        //Populating menu's from old classes, too lazy to type
        var pancakeMenuItems = new PancakeHouseMenu().createIterator();
        var dinerMenuItems = new DinerMenu().createIterator();
        var cafeMenuItems = new CafeMenu().createIterator();

        while(pancakeMenuItems.hasNext()){
            pancakeHouseMenu.add(pancakeMenuItems.next());
        }

        while(dinerMenuItems.hasNext()){
            dinerMenu.add(dinerMenuItems.next());
        }

        while(cafeMenuItems.hasNext()){
            cafeMenu.add(cafeMenuItems.next());
        }

        //Composite pattern
        dessertMenu.add(new MenuItem("Apple Pie", "Apple pie with flakey crust, topped with vanilla ice cream", true, 1.59));

        dinerMenu.add(dessertMenu);

        var waitress = new Waitress(allMenus);
        waitress.printMenu(); //Watch the magic happen
        waitress.printVegetarianMenu();

        /*Code before Composite Pattern
        var menuList = new ArrayList<Menu>();
        menuList.add(new PancakeHouseMenu());
        menuList.add(new DinerMenu());
        menuList.add(new CafeMenu());

        var waitress = new Waitress(menuList);

        waitress.printMenu();*/
    }
    public static void demonstrateStatePattern(){
        System.out.println("*** STATE PATTERN ***");

        var gumballMachine = new GumballMachine(5);

        System.out.println(gumballMachine);

        gumballMachine.insertQuarter();
        gumballMachine.turnCrank();

        System.out.println(gumballMachine);

        gumballMachine.insertQuarter();
        gumballMachine.turnCrank();
        gumballMachine.insertQuarter();
        gumballMachine.turnCrank();

        System.out.println(gumballMachine);
        gumballMachine.refill();

        System.out.println();
    }
}