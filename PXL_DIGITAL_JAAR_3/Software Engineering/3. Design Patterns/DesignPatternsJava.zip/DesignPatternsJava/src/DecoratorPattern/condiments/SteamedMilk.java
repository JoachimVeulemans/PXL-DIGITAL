package DecoratorPattern.condiments;

import DecoratorPattern.beverages.Beverage;

public class SteamedMilk extends CondimentDecorator {
    private Beverage beverage;

    public SteamedMilk(Beverage beverage){
        this.beverage = beverage;
    }

    @Override
    public String getDescription() {
        return beverage.getDescription() + ", Steamed milk";
    }

    @Override
    public double cost() {
        return beverage.cost() + 0.10;
    }
}
