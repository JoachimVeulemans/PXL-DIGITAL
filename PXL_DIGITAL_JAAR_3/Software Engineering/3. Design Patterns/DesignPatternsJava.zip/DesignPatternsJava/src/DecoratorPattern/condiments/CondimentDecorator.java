package DecoratorPattern.condiments;

import DecoratorPattern.beverages.Beverage;

public abstract class CondimentDecorator extends Beverage {
    public abstract String getDescription();
}
