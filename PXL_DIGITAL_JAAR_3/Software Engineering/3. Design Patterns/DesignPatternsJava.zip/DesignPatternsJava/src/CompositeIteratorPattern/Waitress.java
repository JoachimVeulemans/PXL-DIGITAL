package CompositeIteratorPattern;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Waitress {
   MenuComponent allMenus;

   public Waitress(MenuComponent allMenus){
       this.allMenus = allMenus;
   }

   public void printMenu(){
       allMenus.print();
   }

   public void printVegetarianMenu(){
       var iterator = allMenus.createIterator();

       System.out.println("\nVEGATARIAN MENU\n----");
       while(iterator.hasNext()){
           var menuComponent = iterator.next();
           try{
               if(menuComponent.isVegetarian()){
                   menuComponent.print();
               }
           }catch (UnsupportedOperationException e){}
       }
   }

    /* This was the code before the Composite Pattern
    private List<Menu> menus;

    public Waitress(List<Menu> menus){
        this.menus = menus;
    }

    public void printMenu(){
        for(var menu : menus){
            printMenu(menu.createIterator());
        }
    }

    private void printMenu(Iterator<MenuItem> iterator){
        while(iterator.hasNext()){
            var menuItem = (MenuItem) iterator.next();
            printMenu(menuItem);
        }
    }

    private void printMenu(MenuItem menuItem){
        System.out.print(menuItem.getName() + ", ");
        System.out.print(menuItem.getPrice() + " -- ");
        System.out.println(menuItem.getDescription());
    }*/
}
