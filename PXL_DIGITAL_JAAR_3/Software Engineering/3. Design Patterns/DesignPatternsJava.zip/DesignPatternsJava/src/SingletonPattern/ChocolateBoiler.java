package SingletonPattern;

public class ChocolateBoiler {
    private boolean empty;
    private boolean boiled;
    private static ChocolateBoiler uniqueInstance;

    public static ChocolateBoiler getInstance(){
        if(uniqueInstance == null){
            synchronized (ChocolateBoiler.class){
                if(uniqueInstance == null){
                    uniqueInstance = new ChocolateBoiler();
                }
            }
        }
        return uniqueInstance;
    }

    private ChocolateBoiler(){
        this.empty = true;
        this.boiled = false;
    }

    public void fill(){
        if(empty){
            empty = false;
            boiled = false;
            //fill the boiler with a milk/chocolate mixture
        }
    }

    public void drain(){
        if(!empty && !boiled){
            //drain the boiled milk and chocolate
            empty = true;
        }
    }
}
