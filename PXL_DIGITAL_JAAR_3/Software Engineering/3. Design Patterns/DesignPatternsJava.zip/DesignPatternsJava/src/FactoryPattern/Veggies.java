package FactoryPattern;

public class Veggies {
}
