package FactoryPattern;

public class Clam {
}
