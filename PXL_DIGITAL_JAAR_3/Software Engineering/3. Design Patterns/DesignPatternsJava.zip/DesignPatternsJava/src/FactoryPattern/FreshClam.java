package FactoryPattern;

public class FreshClam extends Clam{
}
