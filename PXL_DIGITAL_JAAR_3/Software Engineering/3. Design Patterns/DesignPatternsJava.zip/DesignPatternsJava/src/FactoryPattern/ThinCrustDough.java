package FactoryPattern;

public class ThinCrustDough extends Dough {
}
