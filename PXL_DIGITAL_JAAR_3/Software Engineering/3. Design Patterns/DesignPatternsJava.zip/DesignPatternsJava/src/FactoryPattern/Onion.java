package FactoryPattern;

public class Onion extends Veggies {
}
