package FactoryPattern;

public class Sauce {
}
