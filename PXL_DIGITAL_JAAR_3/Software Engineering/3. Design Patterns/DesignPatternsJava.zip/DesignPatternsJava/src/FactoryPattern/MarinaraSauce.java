package FactoryPattern;

public class MarinaraSauce extends Sauce {
}
