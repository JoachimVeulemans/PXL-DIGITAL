package FactoryPattern;

public class RedPepper extends Veggies {
}
