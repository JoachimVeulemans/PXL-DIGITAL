package FactoryPattern;

public class Dough {
}
