package FactoryPattern;

public class Pepperoni {
}
