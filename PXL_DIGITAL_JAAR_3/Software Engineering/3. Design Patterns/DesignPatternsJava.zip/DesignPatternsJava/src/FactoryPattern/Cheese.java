package FactoryPattern;

public class Cheese {
}
