package FactoryPattern;

public class ReggianoCheese extends Cheese {
}
