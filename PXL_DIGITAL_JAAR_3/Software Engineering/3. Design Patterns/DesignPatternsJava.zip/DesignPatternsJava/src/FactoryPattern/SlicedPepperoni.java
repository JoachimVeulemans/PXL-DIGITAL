package FactoryPattern;

public class SlicedPepperoni extends Pepperoni {
}
