package FactoryPattern;

public class Mushroom extends Veggies {
}
