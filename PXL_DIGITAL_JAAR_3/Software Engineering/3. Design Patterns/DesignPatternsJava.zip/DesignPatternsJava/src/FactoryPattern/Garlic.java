package FactoryPattern;

public class Garlic extends Veggies {
}
