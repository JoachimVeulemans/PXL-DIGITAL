package TemplateMethodPattern;

public abstract class CaffeineBeverage {
    public final void prepareRecipe(){
        boilWater();
        brew();
        pourInCup();
        if(customerWantsCondiments()) { //Hook
            addCondiments();
        }
    }

    abstract void brew();
    abstract void addCondiments();

    final public void boilWater(){
        System.out.println("Boiling water");
    }

    final public void pourInCup(){
        System.out.println("Pouring into cup");
    }

    public boolean customerWantsCondiments(){
        return true;
    }
}
