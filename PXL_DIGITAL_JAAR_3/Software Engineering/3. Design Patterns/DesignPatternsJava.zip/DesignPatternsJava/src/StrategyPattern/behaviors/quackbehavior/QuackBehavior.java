package StrategyPattern.behaviors.quackbehavior;

public interface QuackBehavior {
    void quack();
}