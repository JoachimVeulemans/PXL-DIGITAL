package StrategyPattern.behaviors.flybehavior;

public interface FlyBehavior {
    void fly();
}
