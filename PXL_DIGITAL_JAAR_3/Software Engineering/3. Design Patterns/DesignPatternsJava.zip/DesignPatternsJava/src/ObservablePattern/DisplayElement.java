package ObservablePattern;

public interface DisplayElement {
    void display();
}
