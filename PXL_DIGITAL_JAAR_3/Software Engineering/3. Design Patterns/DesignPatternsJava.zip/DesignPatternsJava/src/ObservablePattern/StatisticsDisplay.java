package ObservablePattern;

import java.util.ArrayList;
import java.util.List;

public class StatisticsDisplay implements Observer, DisplayElement {
    private Subject weatherData;
    private List<Float> temperatures;
    private float averageTemperature;
    private float minimumTemperature;
    private float maximumTemperature;

    public StatisticsDisplay(Subject weatherData){
        this.weatherData = weatherData;
        this.weatherData.registerObserver(this);
        temperatures = new ArrayList<>();
    }

    @Override
    public void display() {
        System.out.println("Minimum temperature: " + minimumTemperature + " maximum temperature: " + maximumTemperature + " average temperature: " + averageTemperature);
    }

    @Override
    public void update(float temperature, float humidity, float pressure) {
        temperatures.add(temperature);

        this.averageTemperature =(float) temperatures.stream().mapToDouble(f -> f).average().getAsDouble();
        this.maximumTemperature = temperatures.stream().max(Float::compare).get();
        this.minimumTemperature = temperatures.stream().min(Float::compare).get();
        display();
    }
}
