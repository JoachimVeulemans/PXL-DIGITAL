﻿using NUnit.Framework;
using StateExercise4;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimUDuck
{
    [TestFixture]
    public class UnitTests
    {
    
        [Test]
        public void TestPoweroffNoChangingState()
        {
            LightController lightController = new LightController();

            IState state = lightController.GetCurrentState();

            lightController.PushButton();

            Assert.Equals(state, lightController.GetCurrentState());
        }

        [Test]
        public void TestSuperDuckQuack()
        {
        }
    }
}
