﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4
{
    public interface IState
    {
        void ButtonPressed();
    }
}
