﻿using System;

namespace StateExercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            LightController lightController = new LightController();
            Console.WriteLine("Starting in: " + lightController.GetCurrentState().ToString());

            lightController.TogglePowerButton();

            lightController.PushButton();

            lightController.TogglePowerButton();

            lightController.PushButton();

            lightController.TogglePowerButton();

            Console.ReadLine();
        }
    }
}
