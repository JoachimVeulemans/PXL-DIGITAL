﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4
{
    public class LightController
    {
        IState allOnState;
        IState blinkingState;
        IState startlightState;
        IState waveState;
        IState discoState;

        IState currentState;
        bool currentlyOn = false;

        public LightController()
        {
            allOnState = new AllOnState(this);
            blinkingState = new BlinkingState(this);
            startlightState = new StartlightState(this);
            waveState = new WaveState(this);
            discoState = new DiscoState(this);

            // Booting sets the all on state
            currentState = allOnState;
        }

        public bool GetCurrentlyOn()
        {
            return currentlyOn;
        }

        public void PushButton()
        {
            this.currentState.ButtonPressed();
        }

        public void SetState(IState state)
        {
            this.currentState = state;
        }

        public IState GetAllOnState()
        {
            return allOnState;
        }

        public IState GetBlinkingState()
        {
            return blinkingState;
        }

        public IState GetWaveState()
        {
            return waveState;
        }

        public IState GetStartlightState()
        {
            return startlightState;
        }

        public IState GetDiscoState()
        {
            return discoState;
        }

        public IState GetCurrentState()
        {
            return currentState;
        }

        public void TogglePowerButton()
        {
            currentlyOn = !currentlyOn;
            Console.WriteLine("Switched controller on to: " + currentlyOn + ", currently in state: " + currentState);
        }
    }
}
