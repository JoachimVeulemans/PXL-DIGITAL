﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StateExercise4
{
    public class BlinkingState : IState
    {
        LightController lightController;
        public BlinkingState(LightController lightController)
        {
            this.lightController = lightController;
        }

        public void ButtonPressed()
        {
            if (lightController.GetCurrentlyOn())
            {
                lightController.SetState(lightController.GetStartlightState());
                Console.WriteLine("Changed to: " + lightController.GetCurrentState());
            }
            else
            {
                Console.WriteLine("Not changing state because controller is turned off!");
            }
        }
    }

    public class StartlightState : IState
    {
        LightController lightController;
        public StartlightState(LightController lightController)
        {
            this.lightController = lightController;
        }

        public void ButtonPressed()
        {
            if (lightController.GetCurrentlyOn())
            {
                lightController.SetState(lightController.GetWaveState());
                Console.WriteLine("Changed to: " + lightController.GetCurrentState());
            }
            else
            {
                Console.WriteLine("Not changing state because controller is turned off!");
            }
        }
    }

    public class WaveState : IState
    {
        LightController lightController;
        public WaveState(LightController lightController)
        {
            this.lightController = lightController;
        }

        public void ButtonPressed()
        {
            if (lightController.GetCurrentlyOn())
            {
                lightController.SetState(lightController.GetAllOnState());
                Console.WriteLine("Changed to: " + lightController.GetCurrentState());
            }
            else
            {
                Console.WriteLine("Not changing state because controller is turned off!");
            }
        }
    }

    public class AllOnState : IState
    {
        LightController lightController;
        public AllOnState(LightController lightController)
        {
            this.lightController = lightController;
        }

        public void ButtonPressed()
        {
            if (lightController.GetCurrentlyOn())
            {
                lightController.SetState(lightController.GetDiscoState());
                Console.WriteLine("Changed to: " + lightController.GetCurrentState());
            }
            else
            {
                Console.WriteLine("Not changing state because controller is turned off!");
            }
        }
    }

    public class DiscoState : IState
    {
        LightController lightController;
        public DiscoState(LightController lightController)
        {
            this.lightController = lightController;
        }

        public void ButtonPressed()
        {
            if (lightController.GetCurrentlyOn())
            {
                lightController.SetState(lightController.GetBlinkingState());
                Console.WriteLine("Changed to: " + lightController.GetCurrentState());
            }
            else
            {
                Console.WriteLine("Not changing state because controller is turned off!");
            }
        }
    }
}
