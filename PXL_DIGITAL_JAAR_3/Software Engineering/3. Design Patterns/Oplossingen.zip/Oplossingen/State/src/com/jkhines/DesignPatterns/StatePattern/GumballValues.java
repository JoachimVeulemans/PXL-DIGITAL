package com.jkhines.DesignPatterns.StatePattern;

public class GumballValues {
	public static int refillSize = 5;
}
