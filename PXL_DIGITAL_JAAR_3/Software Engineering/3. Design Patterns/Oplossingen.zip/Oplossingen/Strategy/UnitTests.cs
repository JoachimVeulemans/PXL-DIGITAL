﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimUDuck
{
    [TestFixture]
    public class UnitTests
    {
    
        [Test]
        public void TestSuperDuckFly()
        {
            var duck = new SuperDuperDuck();

            Assert.IsInstanceOf<FlyWithRockets>(duck.getFly());
        }

        [Test]
        public void TestSuperDuckQuack()
        {
            var duck = new SuperDuperDuck();

            Assert.IsInstanceOf<QuackLikeMallard>(duck.getQuack());
        }
    }
}
