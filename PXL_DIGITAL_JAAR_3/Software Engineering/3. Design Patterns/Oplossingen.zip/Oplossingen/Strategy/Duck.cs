﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimUDuck
{
    public abstract class Duck
    {
        IFlyBehavior flyer;
        IQuackBehavior quacker;

        public IFlyBehavior getFly()
        {
            return flyer;
        }

        public IQuackBehavior getQuack()
        {
            return quacker;
        }

        public virtual void DoFly()
        {
            this.flyer.Fly();
        }

        public virtual void SetFly(IFlyBehavior newFlyer)
        {
            this.flyer = newFlyer;
        }

        public virtual void DoQuack()
        {
            this.quacker.Quack();
        }

        public virtual void SetQuack(IQuackBehavior newQuacker)
        {
            this.quacker = newQuacker;
        }

        public virtual void Swim()
        {
            Console.WriteLine("Swish, swish");
        }
    }

    public class Mallard : Duck
    {
        public Mallard()
        {
            SetFly(new FlyWithWings());
            SetQuack(new QuackLikeMallard());
        }
    }

    public class Spaniel : Duck
    {
        public Spaniel()
        {
            SetFly(new FlyWithJetPropulsion());
            SetQuack(new QuackLikeSpaniel());
        }
    }

    public class SuperDuperDuck : Duck
    {
        public SuperDuperDuck()
        {
            SetFly(new FlyWithRockets());
            SetQuack(new QuackLikeMallard());
        }
    }
}
