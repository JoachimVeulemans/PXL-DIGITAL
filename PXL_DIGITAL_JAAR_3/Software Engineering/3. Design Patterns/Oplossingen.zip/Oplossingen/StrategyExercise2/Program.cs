﻿using System;

namespace StrategyExercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Left remote");
            var remote1 = new Remote("left");
            remote1.LeftPressed();

            Console.WriteLine("Right remote");
            var remote2 = new Remote("right");
            remote2.RightPressed();

            // Should output: left -> left & right -> left

            Console.ReadLine();
        }
    }
}
