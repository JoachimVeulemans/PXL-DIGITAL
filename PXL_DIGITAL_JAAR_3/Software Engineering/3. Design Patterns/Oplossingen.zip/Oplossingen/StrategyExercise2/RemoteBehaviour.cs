﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StrategyExercise2
{
    public class LeftRemote : IRemote
    {
        public void ButtonA_Click()
        {
            Console.WriteLine("Button clicked");
        }

        public void JoystickDown()
        {
            Console.WriteLine("Down pressed");
        }

        public void JoystickLeft()
        {
            Console.WriteLine("Left pressed");
        }

        public void JoystickRight()
        {
            Console.WriteLine("Right pressed");
        }

        public void JoystickUp()
        {
            Console.WriteLine("Up pressed");
        }
    }

    public class RightRemote : IRemote
    {
        public void ButtonA_Click()
        {
            Console.WriteLine("Button clicked");
        }

        public void JoystickDown()
        {
            Console.WriteLine("Up pressed");
        }

        public void JoystickLeft()
        {
            Console.WriteLine("Right pressed");
        }

        public void JoystickRight()
        {
            Console.WriteLine("Left pressed");
        }

        public void JoystickUp()
        {
            Console.WriteLine("Down pressed");
        }
    }
}
