﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StrategyExercise2
{
    public interface IRemote
    {
        void JoystickUp();
        void JoystickDown();
        void JoystickLeft();
        void JoystickRight();
        void ButtonA_Click();
    }
}
