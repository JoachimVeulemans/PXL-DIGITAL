﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StrategyExercise2
{
    public class Remote
    {
        IRemote remote;

        public Remote(string side)
        {
            if (side.ToLower() == "left")
            {
                remote = new LeftRemote();
            } else
            {
                remote = new RightRemote();
            }
        }

        public void ButtonAClick()
        {
            this.remote.ButtonA_Click();
        }

        public void LeftPressed()
        {
            this.remote.JoystickLeft();
        }

        public void RightPressed()
        {
            this.remote.JoystickRight();
        }

        public void UpPressed()
        {
            this.remote.JoystickUp();
        }

        public void DownPressed()
        {
            this.remote.JoystickDown();
        }
    }
}
