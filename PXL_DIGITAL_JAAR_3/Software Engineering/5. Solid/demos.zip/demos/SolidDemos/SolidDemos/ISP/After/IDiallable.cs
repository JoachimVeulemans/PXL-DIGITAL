﻿namespace SolidDemos.ISP.After
{
    public interface IDiallable
    {
        string Telephone { get; set; }
    }
}
