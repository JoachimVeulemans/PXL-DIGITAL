﻿namespace SolidDemos.OC.After
{
    public class FileLogger : IMessageLogger
    {
        public void Log(string message)
        {
            // Add code to log to a file
        }
    }
}
