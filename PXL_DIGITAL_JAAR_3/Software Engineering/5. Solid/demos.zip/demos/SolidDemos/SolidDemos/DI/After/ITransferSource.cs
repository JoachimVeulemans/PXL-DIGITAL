﻿namespace SolidDemos.DI.After
{
    public interface ITransferSource
    {
        void RemoveFunds(decimal value);
    }
}
