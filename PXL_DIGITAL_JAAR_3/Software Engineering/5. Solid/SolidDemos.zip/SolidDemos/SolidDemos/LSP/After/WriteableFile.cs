﻿namespace SolidDemos.LSP.After
{
    public class WriteableFile : ProjectFile
    {
        public void SaveFileData()
        {
            // Write FileData to disk
        }
    }
}