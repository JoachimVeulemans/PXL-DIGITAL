﻿namespace SolidDemos.DI.After
{
    public interface ITransferDestination
    {
        void AddFunds(decimal value);
    }
}
