﻿namespace SolidDemos.ISP.Before
{
    public class Dialler
    {
        public void MakeCall(Contact contact)
        {
            // Code to dial telephone number of contact
        }
    }
}
