﻿namespace SolidDemos.ISP.Before
{
    public class Emailer
    {
        public void SendMessage(Contact contact, string subject, string body)
        {
            // Code to send email, using contact's email address and name
        }
    }
}
