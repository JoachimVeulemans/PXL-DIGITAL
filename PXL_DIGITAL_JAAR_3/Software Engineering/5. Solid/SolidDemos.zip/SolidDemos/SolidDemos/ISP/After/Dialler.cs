﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidDemos.ISP.After
{
    public class Dialler
    {
        public void MakeCall(IDiallable target)
        {
            // Code to dial telephone number of target
        }
    }
}
