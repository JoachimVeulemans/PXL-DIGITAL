﻿namespace SolidDemos.OC.After
{
    public interface IMessageLogger
    {
        void Log(string message);
    }
}