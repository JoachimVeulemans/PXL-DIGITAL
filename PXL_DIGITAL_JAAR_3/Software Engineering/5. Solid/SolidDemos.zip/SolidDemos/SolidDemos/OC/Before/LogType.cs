﻿public enum LogType
{
    Console,
    File
}
