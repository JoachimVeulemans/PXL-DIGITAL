package be.pxl.h9.oef1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class PersoonTest {
	private Persoon persoon;

	@Before
	public void init() {
		persoon = new Persoon("Aerts", "Jef", 29, 11, 1990, "Lindestraat", "23d", 3500, "Hasselt");

	}

	@Test
	public void testConstructorZonderObjecten() {
		assertEquals("Aerts", persoon.getNaam());
		assertEquals("Jef", persoon.getVoornaam());
		assertNotNull(persoon.getGeboortedatum());
		assertEquals(29, persoon.getGeboortedatum().getDag(), 0);
		assertEquals(11, persoon.getGeboortedatum().getMaandNr(), 0);
		assertEquals(1990, persoon.getGeboortedatum().getJaar(), 0);
		assertNotNull(persoon.getAdres());
		assertEquals("Lindestraat", persoon.getAdres().getStraat());
		assertEquals("23d", persoon.getAdres().getHuisnr());
		assertNotNull(persoon.getAdres().getGemeente());
		assertEquals(3500, persoon.getAdres().getGemeente().getPostcode());
		assertEquals("Hasselt", persoon.getAdres().getGemeente().getGemNaam());
	}

	@Test
	public void testConstructorMetObjecten() {
		Adres adres = new Adres("Lindestraat", "23d", 3500, "Hasselt");
		Datum geboorteDatum = new Datum(29, 11, 1990);
		Persoon persoonObject = new Persoon("Aerts", "Jef", geboorteDatum, adres);
		assertEquals("Aerts", persoonObject.getNaam());
		assertEquals("Jef", persoonObject.getVoornaam());
		assertNotNull(persoonObject.getGeboortedatum());
		assertEquals(geboorteDatum, persoonObject.getGeboortedatum());
		assertNotNull(persoonObject.getAdres());
		assertEquals(adres, persoonObject.getAdres());
	}

	@Test
	public void testVoegVoornamenToe() {
		persoon.voegVoornamenToe("Sofie", "Robbe", "Hans");
		assertEquals("Jef Sofie Robbe Hans", persoon.getVoornaam());
	}

	@Test
	public void testToString() {
		String tekst = "Jef Aerts\nLindestraat 23d\n3500 Hasselt";
		assertEquals(tekst, persoon.toString());
	}
}
