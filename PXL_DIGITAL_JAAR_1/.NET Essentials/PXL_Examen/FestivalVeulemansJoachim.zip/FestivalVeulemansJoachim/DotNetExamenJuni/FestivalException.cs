﻿using System;

namespace DotNetExamenJuni
{
    [Serializable]
    internal class FestivalException : ApplicationException
    {
        public FestivalException(string message) : base(message)
        {
        }
    }
}