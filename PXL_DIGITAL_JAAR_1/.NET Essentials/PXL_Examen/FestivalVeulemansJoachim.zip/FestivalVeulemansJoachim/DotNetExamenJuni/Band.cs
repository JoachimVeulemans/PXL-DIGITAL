﻿using System.Collections.Generic;

namespace DotNetExamenJuni
{
    public class Band : Performer
    {
        public int MemberCount { get; set; }

        public Band(int memberCount, string name, int reservationNumber, string startTime, string endTime,
            int[] technicalSupplies, List<string> rider) : base(name, reservationNumber, startTime, endTime, technicalSupplies, rider)
        {
            MemberCount = memberCount;
        }

    }
}
