﻿using System.ComponentModel;
using System.Windows;

namespace DotNetExamenJuni
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ProgramButton_Click(object sender, RoutedEventArgs e)
        {
            StageLineUpWindow stageLineUpWindow = new StageLineUpWindow();
            stageLineUpWindow.Show();
            stageLineUpWindow.Closing += StageLineUpWindowOnClosing;
            WindowState = WindowState.Minimized;
            
        }

        private void StageLineUpWindowOnClosing(object sender, CancelEventArgs e)
        {
            WindowState = WindowState.Normal;
        }
    }
}
