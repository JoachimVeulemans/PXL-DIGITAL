﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace DotNetExamenJuni
{
    /// <summary>
    /// Interaction logic for NewActWindow.xaml
    /// </summary>
    public partial class NewActWindow : Window
    {
        private List<Performer> _artiesten;

        public NewActWindow()
        {
            InitializeComponent();
        }

        private void BandRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (typeCountLabel != null)
            {
                typeCountLabel.Content = "Members";
            }

        }

        private void SoloRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (typeCountLabel != null)
            {
                typeCountLabel.Content = "Type of artist";
            }
                
        }

        private void AddActButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (typeCountTextBox.Text != "" && nameTextBox.Text != "" && numberTextBox.Text != "" && startHourTextBox.Text != "" && endHourTextBox.Text != "" && technicalTextBox.Text != "" && riderTextBox.Text != "")
                {
                    Performer artiest;
                    if (bandRadioButton.IsChecked == true)
                    {
                        //BAND
                        string[] technicalSupplies = technicalTextBox.Text.Split(' ');
                        int[] technicalSuppliesInt = new int[2];
                        technicalSuppliesInt[0] = Convert.ToInt32(technicalSupplies[0]);
                        technicalSuppliesInt[1] = Convert.ToInt32(technicalSupplies[1]);
                        List<string> riderlist = riderTextBox.Text.Split(',').ToList();


                        artiest = new Band(Convert.ToInt32(typeCountTextBox.Text), nameTextBox.Text, Convert.ToInt32(numberTextBox.Text), startHourTextBox.Text, endHourTextBox.Text, technicalSuppliesInt, riderlist);

                    }
                    else
                    {
                        //SOLO
                        string[] technicalSupplies = technicalTextBox.Text.Split(' ');
                        int[] technicalSuppliesInt = new int[2];
                        technicalSuppliesInt[0] = Convert.ToInt32(technicalSupplies[0]);
                        technicalSuppliesInt[1] = Convert.ToInt32(technicalSupplies[1]);
                        List<string> riderlist = riderTextBox.Text.Split(',').ToList();


                        artiest = new Solo(typeCountTextBox.Text, nameTextBox.Text, Convert.ToInt32(numberTextBox.Text), startHourTextBox.Text, endHourTextBox.Text, technicalSuppliesInt, riderlist);

                    }

                    //CHECK STARTTIJD
                    for (int i = 0; i < _artiesten.Count; i++)
                    {
                        if (_artiesten[i].StartTime > artiest.StartTime)
                        {
                            //Hiervoor moet deze invoegen
                            if (i == 0)
                            {
                                //Eerste artiest check eindtijd
                                if (artiest.EndTime > _artiesten[i].StartTime)
                                {
                                    throw new FestivalException("Vorig optreden nog niet beëindigd");
                                }
                            }
                            else
                            {
                                //Niet de eerste maar tussenin
                                //Starttijd naar vorige eindtijd
                                if (artiest.StartTime < _artiesten[i - 1].EndTime)
                                {
                                    throw new FestivalException("Vorig optreden nog niet beëindigd");
                                }
                                //eindtijd voor vorige starttijd
                                if (artiest.EndTime > _artiesten[i].StartTime)
                                {
                                    throw new FestivalException("Optreden duurt te lang, het volgende optreden start voor het einde van dit optreden");
                                }
                            }

                            i = _artiesten.Count;
                        }
                    }

                    //Alles goed, dus toevoegen
                    _artiesten.Add(artiest);
                    //Sorteren
                    _artiesten = _artiesten.OrderBy(o => o.StartTime).ToList();
                }
                else
                {
                    throw new FestivalException("Gelieve alle velden in te vullen!");
                }
                Close();
            }
            catch (FestivalException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void SetArtiesten(List<Performer> performers)
        {
            _artiesten = performers;
        }
    }
}
