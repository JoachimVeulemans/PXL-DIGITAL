﻿using System;
using System.Collections.Generic;

namespace DotNetExamenJuni
{
    public abstract class Performer
    {
        public string Name { get; set; }
        public int ReservationNumber { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public int[] TechnicalSupplies { get; set; }
        public List<string> Rider { get; set; }

        protected Performer(string name, int reservationNumber, string startTime, string endTime,int[] technicalSupplies, List<string> rider)
        {
            Name = name;
            ReservationNumber = reservationNumber;
            string[] startTimeArray = startTime.Split(':');
            string[] endTimeArray = endTime.Split(':');
            if (startTimeArray[0].Substring(0, 1) == " ")
            {
                startTimeArray[0] = startTimeArray[0].Substring(1, startTimeArray[0].Length - 1);
            }
            if (endTimeArray[0].Substring(0, 1) == " ")
            {
                endTimeArray[0] = endTimeArray[0].Substring(1, endTimeArray[0].Length - 1);
            }
            StartTime = new TimeSpan(Convert.ToInt32(startTimeArray[0]), Convert.ToInt32(startTimeArray[1]), 0);
            EndTime = new TimeSpan(Convert.ToInt32(endTimeArray[0]), Convert.ToInt32(endTimeArray[1]), 0);
            TechnicalSupplies = technicalSupplies;
            Rider = rider;
        }

        public override string ToString()
        {
            string tekst = "";
            tekst += StartTime.Hours + ":" + StartTime.Minutes;
            tekst += "-";
            tekst += EndTime.Hours + ":" + EndTime.Minutes;
            tekst += "\t" + Name;
            return tekst;
        }
    }
}
