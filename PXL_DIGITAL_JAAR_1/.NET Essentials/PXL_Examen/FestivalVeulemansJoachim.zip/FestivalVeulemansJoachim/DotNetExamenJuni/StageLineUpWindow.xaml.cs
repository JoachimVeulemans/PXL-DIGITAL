﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.IO;
using Microsoft.Win32;

namespace DotNetExamenJuni
{
    /// <summary>
    /// Interaction logic for StageLineUpWindow.xaml
    /// </summary>
    public partial class StageLineUpWindow : Window
    {
        public List<Performer> Artiesten = new List<Performer>();
        private string _path = "";
        
        public StageLineUpWindow()
        {
            InitializeComponent();
        }

        public void DisableEvents()
        {
            openMenuItem.Click -= OpenMenuItem_OnClick;
            exitMenuItem.Click -= ExitMenuItem_OnClick;
            addButton.Click -= addButton_Click;
            removeButton.Click -= RemoveButton_Click;
        }

        public void EnableEvents()
        {
            openMenuItem.Click += OpenMenuItem_OnClick;
            exitMenuItem.Click += ExitMenuItem_OnClick;
            addButton.Click += addButton_Click;
            removeButton.Click += RemoveButton_Click;
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            int index = performListBox.SelectedIndex;
            if (index != -1)
            {
                Artiesten.RemoveAt(index);
            }
            
            //tip om de getoonde lijst te updaten.
            performListBox.Items.Refresh();
        }

        private void ShowContentsInListBox()
        {
            performListBox.ItemsSource = null;
            performListBox.ItemsSource = Artiesten;
        }

        //Tip bij bewaren:
        //obj is Band geeft true terug als obj van het type Band is.

        private void OpenMenuItem_OnClick(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            string startdir = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            openFileDialog.InitialDirectory = startdir;
            openFileDialog.Filter = "Text Files|*.txt";

            if (openFileDialog.ShowDialog() == true)
            {
                _path = openFileDialog.FileName;
                StreamReader inputStream = null;

                try
                {
                    inputStream = File.OpenText(_path);
                    string line = inputStream.ReadLine();
                    while (line != null)
                    {
                        string[] onderdelen = line.Split(',');

                        if (onderdelen[0].ToLower() == "s")
                        {
                            //SOLO
                            int[] technicalSupplies = new int[2];
                            technicalSupplies[0] = Convert.ToInt32(onderdelen[6]);
                            technicalSupplies[1] = Convert.ToInt32(onderdelen[7]);

                            List<string> riderlist = new List<string>();
                            for (int i = 8; i < onderdelen.Length; i++)
                            {
                                riderlist.Add(onderdelen[i]);
                            }

                            Solo artiest = new Solo(onderdelen[1], onderdelen[2], Convert.ToInt32(onderdelen[3]), onderdelen[4], onderdelen[5], technicalSupplies, riderlist);
                            Artiesten.Add(artiest);
                        }
                        else
                        {
                            //BAND
                            int[] technicalSupplies = new int[2];
                            technicalSupplies[0] = Convert.ToInt32(onderdelen[6]);
                            technicalSupplies[1] = Convert.ToInt32(onderdelen[7]);

                            List<string> riderlist = new List<string>();
                            for (int i = 8; i < onderdelen.Length; i++)
                            {
                                riderlist.Add(onderdelen[i]);
                            }

                            Band artiest = new Band(Convert.ToInt32(onderdelen[1]), onderdelen[2], Convert.ToInt32(onderdelen[3]), onderdelen[4], onderdelen[5],technicalSupplies, riderlist);
                            Artiesten.Add(artiest);
                        }

                        line = inputStream.ReadLine();
                    }

                    saveMenuItem.IsEnabled = true;
                    addButton.IsEnabled = true;
                    removeButton.IsEnabled = true;

                    //Tonen op scherm
                    ShowContentsInListBox();

                }
                catch (FileNotFoundException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (UnauthorizedAccessException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (FormatException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    inputStream?.Close();
                }
            }
        }

        private void SaveMenuItem_OnClick(object sender, RoutedEventArgs e)
        {
            StreamWriter s = File.CreateText(_path);
            for (int i = 0; i < Artiesten.Count; i++)
            {
                StringBuilder line = new StringBuilder("");

                if (Artiesten[i].GetType() == typeof(Band))
                {
                    line.Append("B, ");
                    line.Append(Convert.ToString(((Band)Artiesten[i]).MemberCount) + ", ");
                }
                else
                {
                    line.Append("S,");
                    line.Append(((Solo)Artiesten[i]).Type + ", ");
                }

                line.Append(Artiesten[i].Name + ", ");
                line.Append(Artiesten[i].ReservationNumber + ", ");
                line.Append(Artiesten[i].StartTime.Hours + ":" + Artiesten[i].StartTime.Minutes + ", ");
                line.Append(Artiesten[i].StartTime.Hours + ":" + Artiesten[i].StartTime.Minutes + ", ");
                line.Append(Artiesten[i].TechnicalSupplies[0] + ", ");
                line.Append(Artiesten[i].TechnicalSupplies[1] + ",");

                string riderlist = "";
                for (int j = 0; j < Artiesten[i].Rider.Count; j++)
                {
                    if (j == Artiesten[i].Rider.Count - 1)
                    {
                        riderlist += Artiesten[i].Rider[j];
                    }
                    else
                    {
                        riderlist += Artiesten[i].Rider[j] + ",";
                    }
                    
                }

                line.Append(riderlist);

                s.WriteLine(line.ToString());
            }
            s.Close();
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            NewActWindow newActWindow = new NewActWindow();
            newActWindow.Closing += NewActWindowOnClosing;
            newActWindow.SetArtiesten(Artiesten);
            newActWindow.Show();
            DisableEvents();
        }

        private void NewActWindowOnClosing(object sender, CancelEventArgs e)
        {
            EnableEvents();
            ShowContentsInListBox();
        }

        private void ExitMenuItem_OnClick(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
