﻿using System.Collections.Generic;

namespace DotNetExamenJuni
{
    public class Solo : Performer
    {
        public string Type { get; set; }

        public Solo(string type, string name, int reservationNumber, string startTime, string endTime, int[] technicalSupplies, List<string> rider) : base(name, reservationNumber, startTime, endTime, technicalSupplies, rider)
        {
            Type = type;
        }

    }
}
