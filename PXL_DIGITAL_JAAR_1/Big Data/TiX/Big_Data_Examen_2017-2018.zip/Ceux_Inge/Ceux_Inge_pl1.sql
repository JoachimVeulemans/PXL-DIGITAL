CREATE OR REPLACE PROCEDURE plan_1tin_zit2
(p_jaar	  IN	NUMBER)
AS
	v_exDatum	DATE;
	v_startDatum	DATE	:= TO_DATE('17-08-' || p_jaar ,'DD-MM-YYYY');
	v_olodCount	NUMBER	:= 0;
	v_loopCount	NUMBER	:= 0;	
BEGIN
	v_exDatum := v_startDatum;

	FOR rec IN (SELECT olodcode
		FROM olods
		WHERE olodcode LIKE '_1TIN%')
		LOOP
			WHILE TO_CHAR(v_exDatum,'DY') = 'SAT' OR TO_CHAR(v_exDatum,'DY') = 'SUN' LOOP
				v_exDatum := v_exDatum + 1;
			END LOOP;
		
			INSERT INTO examendatum_olod (olodcode, exdatum, acjaar,examenmaand)
			VALUES	(rec.olodcode, v_exDatum, TO_CHAR(p_jaar -1 || ' - ' ||  p_jaar),'aug-sep');
			v_exDatum := v_exDatum + 1;
		END LOOP;
END;
/

