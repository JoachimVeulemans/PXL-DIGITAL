CREATE OR REPLACE TRIGGER bir_kpspo
BEFORE INSERT
ON klas_perstudent_perolod
FOR EACH ROW
WHEN (TO_NUMBER(SUBSTR(NEW.acjaar,8,11)) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')))
BEGIN
	IF TO_NUMBER(SUBSTR(:NEW.acjaar,8,11)) < TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) THEN
		RAISE_APPLICATION_ERROR(-20000,'U bent te laat om zich in te schrijven');
	ELSIF SYSDATE > TO_DATE('01-09-' || TO_CHAR(SYSDATE,'YYYY')) THEN
		RAISE_APPLICATION_ERROR(-20000,'U bent te laat om zich in te schrijven');
	ELSE
		DBMS_OUTPUT.PUT_LINE('U werd succesvol ingeschreven');
	END IF;
END;
/

