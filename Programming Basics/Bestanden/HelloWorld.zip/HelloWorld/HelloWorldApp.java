/* This Java application shows the text 'Hello World!' on the screen. */
package hello;

public class HelloWorldApp {
   public static void main(String[] args) {
      System.out.println("Hello World!"); //Show the text
   }
}
  