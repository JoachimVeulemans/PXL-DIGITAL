﻿using Microsoft.AspNetCore.Identity;

namespace OdeToFood.Data.DomainClasses
{
    public class Role: IdentityRole<int>
    {
    }
}
