﻿using Microsoft.AspNetCore.Identity;

namespace OdeToFood.Data.DomainClasses
{
    public class User:IdentityUser<int>
    {
    }
}
