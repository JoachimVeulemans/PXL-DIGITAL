﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OdeToFood.Areas.Identity.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}

