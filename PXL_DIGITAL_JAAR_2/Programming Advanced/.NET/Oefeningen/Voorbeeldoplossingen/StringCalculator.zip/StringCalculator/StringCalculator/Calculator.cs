﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StringCalculator
{
    public class Calculator
    {
        public int Add(string inputText)
        {
            if (string.IsNullOrEmpty(inputText)) return 0;

            var parser = NumberStringParser.From(inputText);
            string[] candidateNumbers = parser.GetNumberCandidates();

            var sum = 0;
            var negatives = new List<int>();
            foreach (var candidateNumber in candidateNumbers)
            {
                sum += ParsePossibleNumber(candidateNumber, negatives);
            }

            if(negatives.Count > 0)
            {
                ThrowNegativeNumbersException(negatives);
            }

            return sum;
        }

        private int ParsePossibleNumber(string possibleNumber, List<int> negatives)
        {
            if (int.TryParse(possibleNumber, out var number))
            {
                if (number < 0)
                {
                    negatives.Add(number);
                }
                return number;
            }
            throw new ArgumentException($"Invalid number {possibleNumber}");
        }

        private static void ThrowNegativeNumbersException(List<int> negatives)
        {
            var numbersMessage = string.Join(",", negatives.Select(n => n.ToString()));

            throw new ArgumentException($"Negatives not allowed {numbersMessage}");
        }

        //I could refactor this further by creating an INumberStringParser interface and injecting it into the Calculator
        //At this point in time (the first week of this course) you don't know yet how to work with Mocks, so I'll stop refactoring at this point.
        //At the end of the course, however, you should be able to refactor this further (tests will also be split into tests 
        //for the Calculator (with Mocks) and tests for the NumberStringParser)
        private class NumberStringParser
        {
            private readonly List<char> _validDelimiters;
            private readonly string _delimitedNumbers;

            private NumberStringParser(string input)
            {
                _validDelimiters = new List<char> { '\n' };
                if (HasCustomDelimiter(input))
                {
                    _validDelimiters.Add(GetCustomDelimiter(input));
                    _delimitedNumbers = RemoveDelimiterPart(input);
                }
                else
                {
                    _validDelimiters.Add(',');
                    _delimitedNumbers = input;
                }
            }

            public static NumberStringParser From(string input)
            {
                return new NumberStringParser(input);
            }

            public string[] GetNumberCandidates()
            {
                return _delimitedNumbers.Split(_validDelimiters.ToArray());
            }

            private bool HasCustomDelimiter(string input)
            {
                return input.StartsWith("//");
            }

            private char GetCustomDelimiter(string input)
            {
                return input.ToCharArray()[2];
            }

            private string RemoveDelimiterPart(string input)
            {
                var firstNewlineIndex = input.IndexOf('\n');
                return input.Substring(firstNewlineIndex + 1);
            }
        }
    }
}
