﻿using System;
using System.Windows;

namespace StringCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, RoutedEventArgs e)
        {
            var calculator = new Calculator();
            string result;
            try
            {
                result = calculator.Add(inputTextBox.Text).ToString();
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }
            resultTextBlock.Text = result;
        }
    }
}
