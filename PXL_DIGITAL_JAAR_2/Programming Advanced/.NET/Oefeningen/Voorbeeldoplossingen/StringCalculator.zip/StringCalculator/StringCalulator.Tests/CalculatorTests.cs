﻿using NUnit.Framework;

namespace StringCalculator.Tests
{
    [TestFixture]
    public class CalculatorTests
    {
        private Calculator _calculator;

        [SetUp]
        public void Setup()
        {
            _calculator = new Calculator();
        }

        [Test]
        [TestCase("")]
        [TestCase(null)]
        public void Add_EmptyString_ReturnsZero(string input)
        {
            //Act
            int result = _calculator.Add(input);

            //Assert
            Assert.That(result, Is.Zero);
        }

        [Test]
        [TestCase("1", 1)]
        [TestCase("10", 10)]
        [TestCase("100", 100)]
        public void Add_ContainsSingleNumber_ReturnsNumber(string input, int expected)
        {
            TestAdd(input, expected);
        }

        [Test]
        [TestCase("1,2", 3)]
        [TestCase("0,1,2,3,4,5", 15)]
        public void Add_ContainsMultipleNumbers_ReturnsSumOfNumbers(string input, int expected)
        {
            TestAdd(input, expected);
        }

        [Test]
        [TestCase("1\n2", 3)]
        [TestCase("5\n10,20", 35)]
        public void Add_ContainsNewlineDelimiter_ReturnsSumOfNumbers(string input, int expected)
        {
            TestAdd(input, expected);
        }

        [Test]
        [TestCase("//;\n1;2", 3)]
        [TestCase("//_\n10_20", 30)]
        public void Add_UsesCustomDelimiter_ReturnsSumOfNumbers(string input, int expected)
        {
            TestAdd(input, expected);
        }

        [Test]
        [TestCase("1,aaa", "aaa")]
        [TestCase("aaa", "aaa")]
        [TestCase("1\n,2", "")]
        public void Add_ContainsInvalidNumber_ThrowsArgumentException(string input, string invalidPart)
        {
            //Act + Assert
            Assert.That(
                () => _calculator.Add(input),
                Throws.ArgumentException.With.Message.EqualTo($"Invalid number {invalidPart}"));
        }

        [Test]
        [TestCase("-1", "-1")]
        [TestCase("1,-2", "-2")]
        [TestCase("-1,2,-3", "-1,-3")]
        public void Add_ContainsNegativeNumbers_ThrowsArgumentExceptionWithAllNegativeNumbersInMessage(string input, string negativeNumbers)
        {
            //Act + Assert
            Assert.That(
                () => _calculator.Add(input),
                Throws.ArgumentException.With.Message.EqualTo($"Negatives not allowed {negativeNumbers}"));
        }

        private void TestAdd(string input, int expected)
        {
            //Act
            int result = _calculator.Add(input);

            //Assert
            Assert.That(result, Is.EqualTo(expected));
        }
    }
}
