﻿using System;
using MoqKoansCore.KoansHelpers;
using NUnit.Framework;

namespace MoqKoansCore
{
	/// <summary>
	/// The tests in this class will make you familiar with creating Mock objects with Moq.
	/// </summary>
	[TestFixture]
	public class Moq1_Interfaces : Koan
	{
		// This is an interface that we will be mocking.
		public interface IVolume
		{
			void Louder();
			void Quieter();
			string Current();
		}

		// This is a simple implementation of IVolume.
		private class Volume : IVolume
		{
			private int volume = 50;

			public void Louder() { volume++; }
			public void Quieter() { volume--; }
			public string Current() { return volume.ToString(); }
		}

		[Test]
		public void VariablesStartAsNull()
		{
			IVolume volume = null;
			Assert.AreEqual(___, volume == null);
		}

		[Test]
		public void AnInstanceOfVolumeIsAlsoAnIVolume()
		{
			var volume = new Volume();
			Assert.AreEqual(___, volume is IVolume);
		}

		[Test]
		public void AMockOfIVolumeIsNotAnIVolume()
		{
			var volume = new Moq.Mock<IVolume>();
			Assert.AreEqual(___, volume is IVolume);
			Assert.IsTrue(volume is ___);
		}

		[Test]
		public void TheObjectPropertyOfAMockReturnsAnInstanceThatImplementsTheMockedInterface()
		{
			var volume = new Moq.Mock<IVolume>();
			Assert.AreEqual(___, volume.Object is IVolume);
		}

		// IVolume was a public interface.
		// This one is private instead.
		private interface IPrivateInterface
		{
			string SomeMethod();
		}

		[Test]
		public void CanNotMockAPrivateInterface()
		{
			var throwsException = false;
			try
			{
				var mock = new Moq.Mock<IPrivateInterface>().Object;
			}
			catch (Exception)
			{
				throwsException = true;
			}

			Assert.AreEqual(___, throwsException);
		}

		[Test]
		public void CreateANewMockOfIVolumeToMakeThisTestPass()
		{
			var mock = new ___();
            Assert.That(mock, Is.InstanceOf<Moq.Mock<IVolume>>());
        }
	}
}
