﻿using System;
using System.Dynamic;

namespace MoqKoansCore.KoansHelpers
{
	public class ___ : Exception
	{
		public void ____()
		{
		}

		public dynamic Object => new ExpandoObject();
	}
}
