package be.pxl.lambdaexpressions.opdracht2;

@FunctionalInterface
public interface Encryptie {
	public String apply(String s);
}
