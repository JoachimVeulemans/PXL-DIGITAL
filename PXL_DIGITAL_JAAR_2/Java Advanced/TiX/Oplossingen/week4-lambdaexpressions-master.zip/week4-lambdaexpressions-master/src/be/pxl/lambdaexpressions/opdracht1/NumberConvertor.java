package be.pxl.lambdaexpressions.opdracht1;

@FunctionalInterface
public interface NumberConvertor {
	public String convert(int number);
}
