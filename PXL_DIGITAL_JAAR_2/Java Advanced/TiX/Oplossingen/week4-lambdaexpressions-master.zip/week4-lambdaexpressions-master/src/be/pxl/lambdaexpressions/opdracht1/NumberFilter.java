package be.pxl.lambdaexpressions.opdracht1;

@FunctionalInterface
public interface NumberFilter {
	public boolean check(int number);
}
