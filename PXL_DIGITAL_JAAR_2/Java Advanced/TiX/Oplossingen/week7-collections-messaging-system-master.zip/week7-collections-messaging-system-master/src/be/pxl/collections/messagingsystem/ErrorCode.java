package be.pxl.collections.messagingsystem;

public interface ErrorCode {
	public String getMessage();
}
