package be.pxl.generics.demo2;

public class Animal extends LivingCreature {
    private boolean sick;

    public boolean isSick() {
        return sick;
    }

    public void setSick(boolean sick) {
        this.sick = sick;
    }
}
