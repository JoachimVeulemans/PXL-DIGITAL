package be.pxl.generics.demo2;

public class LivingCreature {
}
