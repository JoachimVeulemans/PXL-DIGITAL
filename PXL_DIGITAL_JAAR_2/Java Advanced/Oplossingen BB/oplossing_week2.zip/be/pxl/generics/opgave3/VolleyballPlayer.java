package be.pxl.generics.opgave3;

public class VolleyballPlayer extends Player {

	public VolleyballPlayer(String name) {
		super(name);
	}

}
