package be.pxl.generics.opgave1;

public class CircularSaw implements Motorized {

}
