package be.pxl.generics.opgave1;

public class Bike extends Vehicle {

}
