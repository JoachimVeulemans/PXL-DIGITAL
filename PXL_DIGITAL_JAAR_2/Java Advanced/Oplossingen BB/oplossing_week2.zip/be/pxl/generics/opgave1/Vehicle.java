package be.pxl.generics.opgave1;

public abstract class Vehicle {

}
