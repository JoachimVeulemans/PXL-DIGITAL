package be.pxl.generics.opgave1;

public class Car extends Vehicle implements Motorized {

}
