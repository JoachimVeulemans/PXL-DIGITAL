package be.pxl.generics.opgave2;

public class Elephant implements Moveable<Location> {
    private Location currentLocation;

    @Override
    public void move(Location locationCode) {
        currentLocation = locationCode;
    }

    @Override
    public Location getCurrentLocation() {
        return currentLocation;
    }
}
