package be.pxl.generics.opgave2;

public class ChessPiece implements Moveable<ChessBoardLocation> {
    private ChessBoardLocation chessBoardLocation;
    @Override
    public void move(ChessBoardLocation locationCode) {
        chessBoardLocation = locationCode;
    }

    @Override
    public ChessBoardLocation getCurrentLocation() {
        return chessBoardLocation;
    }
}
