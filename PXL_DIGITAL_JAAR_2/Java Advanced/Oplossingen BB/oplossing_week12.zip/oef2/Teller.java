package be.pxl.multithreading.oef2;

public class Teller extends Thread {
	private String name;
	private BankLine line;
	
	public Teller(BankLine line, String name) {
		this.name = name;
		this.line = line;
	}
	
	@Override
	public void run() {
		while(true) {
			Customer customer = line.provideCustomer();
			if (customer != null) {
				System.out.println("Teller " + name + " helping customer " + customer.getName());
				try {
					Thread.sleep(customer.getServiceTime());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Teller " + name + " finished helping customer " + customer.getName());
			} else {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
