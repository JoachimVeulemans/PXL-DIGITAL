package be.pxl.multithreading.oef2;

public class Customer {
	private String name;
	private int serviceTime;
	private long lineInTime;
	private static final int MIN_TIME = 1000;
	private static final int MAX_TIME = 10000;
	

	public Customer(String name) {
		this.name = name;
		serviceTime = MIN_TIME + (int) Math.round(Math.random() * (MAX_TIME - MIN_TIME));
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void inLine() {
		lineInTime = System.currentTimeMillis();
	}
	
	public long outOfLine() {
		return System.currentTimeMillis() - lineInTime;
	}
	
	public int getServiceTime() {
		return serviceTime;
	}
	

}
