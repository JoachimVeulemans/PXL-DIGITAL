package be.pxl.multithreading.oef1;

import javax.naming.RefAddr;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class Customer extends Thread {
    private static final Random RANDOM = new Random();
    public static  AtomicInteger totalDeposit = new AtomicInteger();
    public static AtomicInteger totalWithdrawal = new AtomicInteger();
    private BankAccount bankAccount;
    private int numberOfTransactions;
    private String name;
    private int transactionLimit;

    public Customer(String name, BankAccount bankAccount, int numberOfTransactions, int transactionLimit) {
        this.name = name;
        this.bankAccount = bankAccount;
        this.numberOfTransactions = numberOfTransactions;
        this.transactionLimit = transactionLimit;
    }
    @Override
    public void run() {
        for (int j = 0; j < numberOfTransactions; j++) {
            try {
                if (RANDOM.nextDouble() < 0.5) {
                    int amount = RANDOM.nextInt(transactionLimit);
                    bankAccount.deposit(amount, name);
                    totalDeposit.getAndAdd(amount);
                } else {
                    int amount = RANDOM.nextInt(transactionLimit);
                    bankAccount.withdraw(amount, name);
                    totalWithdrawal.getAndAdd(amount);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
