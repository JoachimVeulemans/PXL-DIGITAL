package be.pxl.multithreading.oef1;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

public class BankAccountApp {
    public static void main(String[] args) throws IOException {
        try (FileInputStream propertyInputStream = new FileInputStream("resources/oefening1.properties");
             BufferedWriter logger = Files.newBufferedWriter(Paths.get("resources/log/logger.txt"))) {
            Random random = new Random();
            Properties properties = new Properties();
            properties.load(propertyInputStream);
            int startBalance = Integer.valueOf((String) properties.get("account.balance"));
            int users = Integer.valueOf((String) properties.get("account.users"));
            int transactions = Integer.valueOf((String) properties.get("user.transactions"));
            int limit = Integer.valueOf((String) properties.get("transaction.limit"));

            BankAccount account = new BankAccount("12345-678", startBalance, logger);
            List<Thread> userThreads = new ArrayList<>();
            for (int i = 0; i < users; i++) {
                final String name = "" + i;
                Thread thread = new Customer(name, account, transactions, limit);
                thread.start();
                userThreads.add(thread);
            }


            try {
                for (Thread thread : userThreads) {
                    thread.join();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(account.getBalance());
            int totalDeposit = Customer.totalDeposit.get();
            System.out.println(totalDeposit);
            int totalWithdrawal = Customer.totalWithdrawal.get();
            System.out.println(totalWithdrawal);
            System.out.println("Expected: " + (startBalance + totalDeposit - totalWithdrawal));

        }
    }
}