package be.pxl.multithreading.oef1;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;

public class BankAccount {
	private int balance;
	private String accountNumber;
	private BufferedWriter logger;
	
	public BankAccount(String accountNumber, int initialBalance, BufferedWriter logger) {
		this.accountNumber = accountNumber;
		this.balance = initialBalance;
		this.logger = logger;
	}
	
	//public void deposit(int amount, String user) throws IOException {
	public synchronized void deposit(int amount, String user) throws IOException {
		int oldBalance = balance;
		balance += amount;
		logger.write("user +[" + amount + ", " + oldBalance+"] = " + balance);
		logger.newLine();
	}
	
	//public void withdraw(int amount, String user) throws IOException {
	public synchronized void withdraw(int amount, String user) throws IOException {
		int oldBalance = balance;
		balance -= amount;
		logger.write("user +[" + amount + ", " + oldBalance+"] = " + balance);
		logger.newLine();
	}
	
	public double getBalance() {
		return balance;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
}
