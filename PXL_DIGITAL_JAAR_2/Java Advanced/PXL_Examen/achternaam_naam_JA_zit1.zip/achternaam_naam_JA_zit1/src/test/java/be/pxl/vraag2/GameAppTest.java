package be.pxl.vraag2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GameAppTest {

	private GameApp gameApp;

	@BeforeEach
	void setUp() {
		gameApp = new GameApp();
	}

	@Test
	void gameApp1() {
		assertEquals(16167, gameApp.gameApp1());
	}

	@Test
	void gameApp2() {
		assertEquals(1970, gameApp.gameApp2());
	}

	@Test
	void gameApp3() {
		assertEquals(2020, gameApp.gameApp3());
	}

	@Test
	void gameApp4() {
		assertEquals(36, gameApp.gameApp4());
	}

	@Test
	void gameApp5() {
		assertEquals("Asteroids", gameApp.gameApp5());
	}

	@Test
	void gameApp6() {
		assertEquals("2600,3DO,3DS,DC,DS,GB,GBA,GC,GEN,GG,N64,NES,NG,PC,PCFX,PS,PS2,PS3,PS4,PSP,PSV,SAT,SCD,SNES,TG16,WS,Wii,WiiU,X360,XB,XOne", gameApp.gameApp6());
	}

	@Test
	void gameApp7() {
		assertEquals(336, gameApp.gameApp7());
	}

	@Test
	void gameApp8() {
		List<Game> resultApp8 = Arrays.asList(
				new Game("0,Wii Sports,Wii,2006,Sports,Nintendo,41.49,29.02,3.77,8.46,82.74".split(",")),
				new Game("0,Super Mario Bros.,NES,1985,Platform,Nintendo,29.08,3.58,6.81,0.77,40.24".split(",")),
				new Game("0,Mario Kart Wii,Wii,2008,Racing,Nintendo,15.85,12.88,3.79,3.31,35.82".split(",")),
				new Game("0,Wii Sports Resort,Wii,2009,Sports,Nintendo,15.75,11.01,3.28,2.96,33".split(",")),
				new Game("0,Pokemon Red/Pokemon Blue,GB,1996,Role-Playing,Nintendo,11.27,8.89,10.22,1,31.37".split(","))
		);
		assertEquals(resultApp8, gameApp.gameApp8());
	}

	@Test
	void gameApp9() {
		List<Game> resultApp9 = Arrays.asList(
				new Game("10347,Aqua Aqua,PS2,2000,Puzzle,3DO,0.05,0.04,0,0.01,0.11".split(",")),
				new Game("16521,Crossroad Crisis,PS,2000,Puzzle,Success,0.01,0,0,0,0.01".split(",")),
				new Game("4148,Fantavision,PS2,2000,Puzzle,Sony Computer Entertainment,0.14,0.11,0.19,0.04,0.47".split(",")),
				new Game("13509,I.Q. Remix+: Intelligent Qube,PS2,2000,Puzzle,Sony Computer Entertainment,0,0,0.04,0,0.04".split(",")),
				new Game("1622,Kirby Tilt 'n' Tumble,GB,2000,Puzzle,Nintendo,0.29,0.17,0.75,0.02,1.23".split(",")),
				new Game("4450,Ms. Pac-Man Maze Madness,PS,2000,Puzzle,Namco Bandai Games,0.25,0.17,0,0.03,0.44".split(",")),
				new Game("7229,Ms. Pac-Man: Maze Madness,N64,2000,Puzzle,Namco Bandai Games,0.18,0.04,0,0,0.22".split(",")),
				new Game("4367,Pokemon Puzzle League,N64,2000,Puzzle,Nintendo,0.36,0.08,0,0.01,0.45".split(",")),
				new Game("15376,Rat Attack!,N64,2000,Puzzle,Mindscape,0.02,0,0,0,0.02".split(",")),
				new Game("5814,Spin Jam,PS,2000,Puzzle,Empire Interactive,0.17,0.12,0,0.02,0.31".split(",")),
				new Game("5380,Super Bust-A-Move,PS2,2000,Puzzle,Acclaim Entertainment,0.17,0.13,0,0.04,0.34".split(",")),
				new Game("8114,The Adventures of Cookie & Cream,PS2,2000,Puzzle,Empire Interactive,0.09,0.07,0,0.02,0.18".split(","))
		);
		assertEquals(resultApp9, gameApp.gameApp9());
	}

	@Test
	void gameApp10() {
		assertEquals("Electronic Arts", gameApp.gameApp10());
	}
}
