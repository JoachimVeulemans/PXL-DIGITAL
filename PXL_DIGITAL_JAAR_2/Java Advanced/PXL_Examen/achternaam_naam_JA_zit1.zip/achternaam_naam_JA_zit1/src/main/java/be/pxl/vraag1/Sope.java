package be.pxl.vraag1;

public class Sope extends Snack {

}
