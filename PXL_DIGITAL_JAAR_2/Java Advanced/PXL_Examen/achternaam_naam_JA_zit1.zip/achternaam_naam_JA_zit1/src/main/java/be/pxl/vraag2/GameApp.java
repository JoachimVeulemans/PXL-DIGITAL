package be.pxl.vraag2;

import java.util.List;

public class GameApp {

	private List<Game> games;

	public static void main(String[] args) {
		GameApp gameApp = new GameApp();
	}

	public GameApp() {
		// TODO: read data from file  vgsales.csv and assign to games
	}

	// 1. Geef het aantal games in totaal
	public long gameApp1() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 2. Geef het aantal games van vóór het jaar 2000
	public long gameApp2() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 3. Geef het recentste jaar van alle games
	public long gameApp3() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 4. Geef het aantal games met de tekst "Pac-Man" in hun naam
	public long gameApp4() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 5. Geef de naam van het oudste game.
	public String gameApp5() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 6. Geef een tekst lijstje (alfabetisch gesorteerd en gescheiden met een komma) met de verschillende platformen die in het bestand vermeld worden (geen dubbels).
	public String gameApp6() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 7. Geef het aantal games voor het platform PS4.
	public long gameApp7() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 8. Geef een lijst van de 5 games met de hoogste global sales waarde.
	public List<Game> gameApp8() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 9. Geef een lijst van alle games met genre PUZZLE van het jaar 2000. Sorteer de games op alfabetisch (A -> Z) op naam.
	public List<Game> gameApp9() {
		// TODO
		throw new UnsupportedOperationException();
	}

	// 10. Geef de naam van de publisher die het meeste games heeft uitgegeven
	public String gameApp10() {
		// TODO
		throw new UnsupportedOperationException();
	}
}
