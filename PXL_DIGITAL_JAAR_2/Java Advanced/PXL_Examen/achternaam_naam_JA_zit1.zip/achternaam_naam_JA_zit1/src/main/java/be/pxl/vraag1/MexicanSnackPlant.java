package be.pxl.vraag1;

public class MexicanSnackPlant {

	public static void main(String[] args) {

		Conveyor<Snack> snackConveyor = new Conveyor<>();
		// 1. read properties file snacks.properties in directory resources. Use a relative path.


		// 2. create 2 producers: one for creating Mollete and one for creating Sope
		// Use a method reference for implementing the interface SnackFactory
		// Use the correct production.delay from properties file
		Producer<Mollete> molletProducer = null;
		Producer<Sope> sopeProducer = null;

		// 3. create 2 consumers (= wrappers)
		Consumer fernanda = new Consumer(/* TODO: add parameters */);
		Consumer carlos = new Consumer(/* TODO: add parameters */);

		// 4. start all threads correctly


		// 5. wait for threads fernanda and carlos to finish


		// 6. output (no changes needed)
		fernanda.summary();
		carlos.summary();
		System.out.println("Molletes produced: " + molletProducer.getProduced());
		System.out.println("Sopes produced: " + sopeProducer.getProduced());

	}

}
