package be.pxl.vraag1;

public class Producer<T extends Snack> extends Thread {

	private Conveyor<? super T> conveyor;
	private SnackFactory<T> snackFactory;
	private int delay;
	private int produced;

	public Producer(Conveyor<? super T> conveyor, SnackFactory<T> snackFactory, int delay) {
		this.conveyor = conveyor;
		this.delay = delay;
		this.snackFactory = snackFactory;
	}

	@Override
	public void run() {
		while (!conveyor.isFinished()) {
			T snack = snackFactory.createSnack();
			System.out.println("Producing " + snack.getClass().getSimpleName());
			produced++;
			conveyor.addItem(snack);
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public int getProduced() {
		return produced;
	}
}
