package be.pxl.vraag2;

public class Game {
	private String name;
	private String platform;
	private int year;
	private double globalSales;
	private Genre genre;
	private String publisher;

	public Game(String[] parts) {
		name = parts[1];
		platform = parts[2];
		year = Integer.parseInt(parts[3]);
		genre = Genre.valueOf(parts[4].toUpperCase().replace("-", "_"));
		publisher = parts[5];
		globalSales = Double.parseDouble(parts[10]);
	}

	public Game(String name, String platform) {
		this.name = name;
		this.platform = platform;
	}

	public String getName() {
		return name;
	}

	public String getPlatform() {
		return platform;
	}

	public int getYear() {
		return year;
	}

	public double getGlobalSales() {
		return globalSales;
	}

	public Genre getGenre() {
		return genre;
	}

	public String getPublisher() {
		return publisher;
	}

	@Override
	public String toString() {
		return "Game{" +
				"name='" + name + '\'' +
				", platform='" + platform + '\'' +
				", year=" + year +
				", globalSales=" + globalSales +
				", genre='" + genre + '\'' +
				", publisher='" + publisher + '\'' +
				'}';
	}
}
