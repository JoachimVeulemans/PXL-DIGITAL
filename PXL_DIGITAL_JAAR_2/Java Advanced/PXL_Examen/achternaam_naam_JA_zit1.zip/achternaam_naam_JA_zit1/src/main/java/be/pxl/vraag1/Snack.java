package be.pxl.vraag1;

public class Snack {

}
