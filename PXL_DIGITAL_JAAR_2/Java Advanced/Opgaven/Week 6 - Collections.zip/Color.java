package be.pxl.collections.opdracht1;

public enum Color {
	HEART,
	DIAMOND,
	CLUB,
	SPADE;
}
