package be.pxl.ja.week4.opgaves.dia6;

@FunctionalInterface
public interface DisplayOnly {
    void print(User user);
}
