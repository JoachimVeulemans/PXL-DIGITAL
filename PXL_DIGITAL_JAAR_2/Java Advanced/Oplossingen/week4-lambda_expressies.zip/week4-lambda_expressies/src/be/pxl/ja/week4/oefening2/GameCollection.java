package be.pxl.ja.week4.oefening2;

import java.util.ArrayList;
import java.util.function.Predicate;

public class GameCollection {
    private ArrayList<VideoGame> videoGames = new ArrayList<>();

    public void addGame(VideoGame videoGame) {
        this.videoGames.add(videoGame);
    }

    public ArrayList<VideoGame> selectGames(Predicate<VideoGame> filter) {
        ArrayList<VideoGame> newList = new ArrayList<>();
        for (int i = 0; i < videoGames.size(); i++) {
            if (filter.test(this.videoGames.get(i))) {
                newList.add(this.videoGames.get(i));
            }
        }
        return newList;
    }
}
