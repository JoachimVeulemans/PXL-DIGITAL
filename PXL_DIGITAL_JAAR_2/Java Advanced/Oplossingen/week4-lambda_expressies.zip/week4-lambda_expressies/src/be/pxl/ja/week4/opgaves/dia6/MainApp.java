package be.pxl.ja.week4.opgaves.dia6;

public class MainApp {
    public static void main(String[] args) {
        User joachim = new User("Joachim", "Admin");
        DisplayOnly displayOnly = System.out::println;
        displayOnly.print(joachim);
    }
}
