package be.pxl.ja.week4.oefening1;

public interface NumberFilter {
    boolean check(int number);
}
