package be.pxl.ja.week4.oefening2;

import java.util.ArrayList;
import java.util.function.Predicate;

public class GameBrowser {
    private  GameCollection gameCollection;

    public GameBrowser(GameCollection gameCollection) {
        this.gameCollection = gameCollection;
    }

    public ArrayList<VideoGame> showGamesForSearch(String search) {
        class Filter implements Predicate<VideoGame> {
            @Override
            public boolean test(VideoGame videoGame) {
                return videoGame.getName().toLowerCase().contains(search.toLowerCase());
            }
        }
        Predicate<VideoGame> filter = new Filter();
        return gameCollection.selectGames(filter);
    }

    public ArrayList<VideoGame> showFreeGames() {
        return gameCollection.selectGames(videoGame -> videoGame.getPrice()==0);
    }

    public ArrayList<VideoGame> showGamesInGenre(String genre) {
        return gameCollection.selectGames(videoGame -> videoGame.getGenres().contains(genre));
    }
}
