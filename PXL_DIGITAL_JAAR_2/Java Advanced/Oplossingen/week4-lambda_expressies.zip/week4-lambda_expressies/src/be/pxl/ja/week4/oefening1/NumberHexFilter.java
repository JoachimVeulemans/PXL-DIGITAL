package be.pxl.ja.week4.oefening1;

import java.util.ArrayList;

@FunctionalInterface
public interface NumberHexFilter {
    String toHex(int number);
}
