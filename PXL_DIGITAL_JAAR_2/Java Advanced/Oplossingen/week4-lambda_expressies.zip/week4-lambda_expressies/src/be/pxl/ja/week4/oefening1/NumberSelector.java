package be.pxl.ja.week4.oefening1;

public class NumberSelector {
    private NumberMachine numberMachine;

    public NumberSelector(NumberMachine numberMachine) {
        this.numberMachine = numberMachine;
    }

    public String showEvenNumbers() {
        class Filter implements NumberFilter {
            @Override
            public boolean check(int number) {
                return number%2 == 0;
            }
        }
        NumberFilter filter = new Filter();
        return numberMachine.processNumbers(filter);
    }

    public String showNumbersAbove(int numberReceived) {
        return numberMachine.processNumbers(number -> number>numberReceived);
    }

    public String printHexNumbers() {
        return numberMachine.convertNumbers(number -> Integer.toHexString(number));
    }
}
