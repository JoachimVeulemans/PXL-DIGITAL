package be.pxl.generics.opgave3;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TeamTest {

    @Test
    public void addPlayerIncreasesNumberOfPlayers() {
        Team<SoccerPlayer> soccerTeam = new Team<>("KRC Genk");
        assertEquals(0, soccerTeam.numberOfPlayers());
        soccerTeam.addPlayer(new SoccerPlayer("Buffel"));
        assertEquals(1, soccerTeam.numberOfPlayers());
    }

    @Test
    public void addPlayerTwiceDoesNotIncreaseNumberOfPlayers() {
        Team<SoccerPlayer> soccerTeam = new Team<>("KRC Genk");
        assertEquals(0, soccerTeam.numberOfPlayers());
        SoccerPlayer player = new SoccerPlayer("Buffel");
        soccerTeam.addPlayer(player);
        soccerTeam.addPlayer(player);
        assertEquals(1, soccerTeam.numberOfPlayers());
    }
}
