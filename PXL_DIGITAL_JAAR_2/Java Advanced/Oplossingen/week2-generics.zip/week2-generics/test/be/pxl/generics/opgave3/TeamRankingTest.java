package be.pxl.generics.opgave3;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TeamRankingTest {

	private static final Team<SoccerPlayer> OPPONENT = new Team<>("Oponent");

	@Test
	public void testThreePointsForGameWon() {
		Team<SoccerPlayer> ourTeam = new Team<>("OurTeam");
		ourTeam.matchResult(OPPONENT, 9, 5);
		assertEquals(3, ourTeam.ranking());
	}
	
	@Test
	public void testOnePointForGameTied() {
		Team<SoccerPlayer> ourTeam = new Team<>("OurTeam");
		ourTeam.matchResult(OPPONENT, 5, 5);
		assertEquals(1, ourTeam.ranking());
	}
	
	@Test
	public void testZeroPointsForGameLost() {
		Team<SoccerPlayer> ourTeam = new Team<>("OurTeam");
		ourTeam.matchResult(OPPONENT, 5, 9);
		assertEquals(0, ourTeam.ranking());
	}
	
	
	@Test
	public void testPointsAreCorrectlyAdded() {
		Team<SoccerPlayer> ourTeam = new Team<>("OurTeam");
		ourTeam.matchResult(OPPONENT, 9, 5);
		ourTeam.matchResult(OPPONENT, 9, 5);
		ourTeam.matchResult(OPPONENT, 5, 5);
		ourTeam.matchResult(OPPONENT, 5, 5);
		assertEquals(8, ourTeam.ranking());
	}
}
