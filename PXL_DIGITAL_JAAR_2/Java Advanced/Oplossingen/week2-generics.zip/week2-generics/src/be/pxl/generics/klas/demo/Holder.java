package be.pxl.generics.klas.demo;

public class Holder {

    private Object canBeAnything;

    public Holder() {

    }

    public Object getCanBeAnything() {
        return canBeAnything;
    }

    public void setCanBeAnything(Object canBeAnything) {
        this.canBeAnything = canBeAnything;
    }
}
