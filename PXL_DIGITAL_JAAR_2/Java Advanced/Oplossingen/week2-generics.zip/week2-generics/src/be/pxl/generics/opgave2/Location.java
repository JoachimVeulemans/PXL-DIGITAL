package be.pxl.generics.opgave2;

public enum Location {
    NEAR_THE_RIVER,
    IN_THE_VILLAGE,
    IN_THE_FORREST;
}
