package be.pxl.generics.klas.demo;

public class Demo2 {
    public static void main(String[] args) {

        HolderV2<GSM> holderV2 = new HolderV2<>();
        GSM gsm = new GSM();
        gsm.setSerialNo("12135133513056406545");
        holderV2.setCanBeAnything(gsm);

        GSM getGSM = holderV2.getCanBeAnything();
        System.out.println(getGSM);

        HolderV2<Pint> holderPint = new HolderV2<>();
        holderPint.setCanBeAnything(new Pint(4.5));
        System.out.println(holderPint.getCanBeAnything().getAlcoholPercentage());
    }
}
