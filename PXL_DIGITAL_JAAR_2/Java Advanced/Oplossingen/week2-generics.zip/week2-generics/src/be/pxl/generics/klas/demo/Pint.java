package be.pxl.generics.klas.demo;

public class Pint {

    private double alcoholPercentage;

    public Pint(double alcoholPercentage) {
        this.alcoholPercentage = alcoholPercentage;
    }

    public double getAlcoholPercentage() {
        return alcoholPercentage;
    }

    public void setAlcoholPercentage(double alcoholPercentage) {
        this.alcoholPercentage = alcoholPercentage;
    }

    @Override
    public String toString() {
        return String.valueOf(alcoholPercentage);
    }

}
