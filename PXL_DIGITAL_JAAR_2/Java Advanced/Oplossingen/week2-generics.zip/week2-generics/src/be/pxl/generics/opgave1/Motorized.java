package be.pxl.generics.opgave1;

public interface Motorized {

}
