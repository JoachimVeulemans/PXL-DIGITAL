package be.pxl.generics.klas.demo;

public class HolderV2<T> {
    private T canBeAnything;

    public HolderV2() {

    }

    public T getCanBeAnything() {
        return canBeAnything;
    }

    public void setCanBeAnything(T canBeAnything) {
        this.canBeAnything = canBeAnything;
    }
}
