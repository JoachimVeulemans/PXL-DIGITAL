package be.pxl.generics.klas.demo;

/**
 * Demo1 is een voorbeeld van de middeleeuwen.
 */
public class Demo1 {
    public static void main(String[] args) {

        Holder holder = new Holder();
        holder.setCanBeAnything(new GSM("05315314864351834864"));
        System.out.println(holder.getCanBeAnything());

        // Set something else
        holder.setCanBeAnything(new Pint(6.3));
        System.out.println(holder.getCanBeAnything());

        // Get Pint instance
        if (holder.getCanBeAnything() instanceof  Pint) {
            Pint pint = (Pint) holder.getCanBeAnything();
            System.out.println(pint.getAlcoholPercentage());
        } else if (holder.getCanBeAnything() instanceof GSM) {
            GSM gsm = (GSM) holder.getCanBeAnything();
            System.out.println(gsm.getSerialNo());
        }
    }
}
