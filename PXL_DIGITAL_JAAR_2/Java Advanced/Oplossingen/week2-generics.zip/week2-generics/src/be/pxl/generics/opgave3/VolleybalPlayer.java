package be.pxl.generics.opgave3;

public class VolleybalPlayer extends Player {
    public VolleybalPlayer(String name) {
        super(name);
    }
}
