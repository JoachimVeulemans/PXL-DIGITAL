package be.pxl.generics.demo2;

public class HabitatOvercrowdedException extends Exception {
    public HabitatOvercrowdedException(String message) {
        super(message);
    }
}
