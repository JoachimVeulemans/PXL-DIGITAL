package be.pxl.generics.opgave3;

import java.util.ArrayList;

public class Team<T> {
    private String name;
    private int played = 0;
    private int won = 0;
    private int lost = 0;
    private int tied = 0;
    private ArrayList<T> members = new ArrayList<>();

    public Team(String name) {
        this.name = name;
    }

    public void addPlayer(T player) {
        if (!members.contains(player)) {
            members.add(player);
        }
    }

    public int numberOfPlayers() {
        return members.size();
    }

    public void matchResult(Team<T> opponent, int ourScore, int theirScore) {
        if (ourScore == theirScore) {
            this.tied++;
            opponent.tied++;
        } else if (ourScore > theirScore) {
            this.won++;
            opponent.lost++;
        } else {
            this.lost++;
            opponent.won++;
        }

        this.played++;
        opponent.played++;
    }

    public int ranking() {
        return (this.won * 3) + (this.tied);
    }

    public String getName() {
        return name;
    }

    public int getPlayed() {
        return played;
    }

    public int getWon() {
        return won;
    }

    public int getLost() {
        return lost;
    }

    public int getTied() {
        return tied;
    }

    public ArrayList<T> getMembers() {
        return members;
    }
}
