package be.pxl.generics.demo2;

import be.pxl.generics.demo2.Animal;

public class Fish extends Animal {
}
