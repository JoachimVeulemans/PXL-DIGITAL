package opdracht1;

public class IBANChecker extends Thread {
    private String code;

    public IBANChecker(String code) {
        this.code = code;
    }

    public void validate() {
        boolean valid = false;
        // 1
        String checkCode = code.replaceAll(" ", "");

        // 2
        int check = Integer.parseInt(checkCode.substring(2, 4));
        if (check > 2 && check < 98) {
            // 3
            checkCode = checkCode.substring(5) + checkCode.substring(0, 4);

            // 4
            StringBuilder newCode = new StringBuilder("");
            for (int i = 0; i < checkCode.length(); i++) {
                newCode.append(Character.getNumericValue(checkCode.charAt(i)));
            }
            long checkCodeInt = Long.parseLong(newCode.toString());

            // 5
            if (checkCodeInt % 97 == 1) {
                valid = true;
            }
        }

        print(code, valid);
    }

    public void print(String code, boolean valid) {
        if (valid) {
            System.out.println(code + ": valid");
        } else {
            System.out.println(code + ": not valid");
        }
    }

    @Override
    public void run() {
        validate();
    }
}
