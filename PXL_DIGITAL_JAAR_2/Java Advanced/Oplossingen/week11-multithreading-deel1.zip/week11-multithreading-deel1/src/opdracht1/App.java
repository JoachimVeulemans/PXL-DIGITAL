package opdracht1;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class App {
    public static void main(String[] args) {
        Path path = Paths.get(System.getProperty("user.dir"));
        Path filepath = path.resolve("codes.txt");
        try (BufferedReader br = Files.newBufferedReader(filepath)) {
            String line = br.readLine();

            while (line != null) {
                Thread ibanChecker= new IBANChecker(line);
                ibanChecker.run();
                line = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
