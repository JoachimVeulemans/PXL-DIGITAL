package opdracht2;

public class App {
    public static void main(String[] args) {
        long before = System.currentTimeMillis();

        DivisorCounter f = new DivisorCounter(1, 10000);
        try {
            f.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Getal: " + f.getMaxNumber());
        System.out.println("Aantal delers: " + f.getMaxDivisors());

        long after = System.currentTimeMillis();

        double seconds = (after - before) / 1000.0;
        System.out.printf("Berekening duurde %.3f seconden", seconds);
    }
}
