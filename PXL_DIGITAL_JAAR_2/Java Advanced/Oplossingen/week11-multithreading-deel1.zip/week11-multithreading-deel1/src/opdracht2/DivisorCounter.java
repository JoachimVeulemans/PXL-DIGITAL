package opdracht2;

public class DivisorCounter extends Thread {
    private int maxNumber;
    private int[] maxDivisors;
    private int min;
    private int max;

    public DivisorCounter(int min, int max) {
        // findNumberWithHighestNumberOfDivisors(min, max);
        this.min = min;
        this.max = max;
    }

    private void findNumberWithHighestNumberOfDivisors(int min, int max) {

    }

    public int getMaxNumber() {
        return maxNumber;
    }

    public int[] getMaxDivisors() {
        return maxDivisors;
    }

    @Override
    public void run() {
        findNumberWithHighestNumberOfDivisors(min, max);
    }
}
