package be.pxl.multithreading.oef1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;

public class User extends Thread {
    private int transactionsToDo;
    private int count = 0;
    private Bankrekening bankrekening;
    private int amount;

    public User(int transactionsToDo, Bankrekening bankrekening, int amount) {
        this.transactionsToDo = transactionsToDo;
        this.bankrekening = bankrekening;
        this.amount = amount;
    }

    @Override
    public void run() {
        while (count < transactionsToDo) {
            try {
                Random rand = new Random();

                if (rand.nextInt(2) == 0) {
                    bankrekening.deposit(amount);
                    System.out.println("Deposit gedaan!");
                    writeTransaction("Deposit", amount, bankrekening);
                } else {
                    bankrekening.withdraw(amount);
                    System.out.println("Withdraw gedaan!");
                    writeTransaction("Withdraw", amount, bankrekening);
                }



                count++;

                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void writeTransaction(String type, int amount, Bankrekening bankrekening) {
        String line = type + " van " + amount + " euro op " + bankrekening.getName() + " gedaan.";
        Path path = Paths.get(System.getProperty("user.home"));
        Path file = path.resolve(bankrekening.getName() + "-" + new Random().nextInt() + ".txt");

        try (BufferedWriter bw = Files.newBufferedWriter(file)) {
            bw.write(line);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
