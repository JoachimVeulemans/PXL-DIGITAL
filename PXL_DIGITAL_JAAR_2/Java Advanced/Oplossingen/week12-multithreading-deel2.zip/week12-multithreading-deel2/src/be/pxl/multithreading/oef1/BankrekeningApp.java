package be.pxl.multithreading.oef1;

public class BankrekeningApp {
    public static void main(String[] args) {
        // Ik had geen zin in programma-attributen dus het is gewoon een array met waardes, lekker makkelijk ;)
        int[] arguments = {200, 2, 2, 50};

        Bankrekening bankrekening = new Bankrekening(arguments[0], "DitIsDeNaam");

        for (int i = 0; i < arguments[1]; i++) {
            // ELKE GEBRUIKER
            Thread user = new User(arguments[2], bankrekening, arguments[3]);
            user.start();
        }
    }
}
