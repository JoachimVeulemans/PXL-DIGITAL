package be.pxl.multithreading.oef2;

public class Teller extends Thread {
    private String name;
    private BankLine line;

    public Teller(BankLine line, String name) {
        this.name = name;
        this.line = line;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Customer customer = line.provideCustomer();
                if (customer != null) {
                    System.out.println("Huidige klant: " + customer.getName());
                    Thread.sleep(customer.getServiceTime());
                    System.out.println("Klaar met het helpen van klant: " + customer.getName());
                } else {
                    Thread.sleep(1000);
                }
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }
}
