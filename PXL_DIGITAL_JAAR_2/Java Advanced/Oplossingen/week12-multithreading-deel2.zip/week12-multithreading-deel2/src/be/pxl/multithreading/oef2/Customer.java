package be.pxl.multithreading.oef2;

import java.time.Duration;
import java.time.LocalTime;

public class Customer {
    private String name;
    private int serviceTime;
    private long lineInTime;
    private static final int MIN_SERVICE_TIME = 1000;
    private static final int MAX_SERVICE_TIME = 10000;
    private LocalTime timeInLine;
    private LocalTime timeOutLine;

    public Customer(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(int serviceTime) {
        this.serviceTime = serviceTime;
    }

    public long getLineInTime() {
        return lineInTime;
    }

    public void inLine() {
        this.timeInLine = LocalTime.now();
    }

    public long outOfLine() {
        this.timeOutLine = LocalTime.now();
        this.lineInTime = Duration.between(timeInLine, timeOutLine).toMinutes();
        return lineInTime;
    }
}
