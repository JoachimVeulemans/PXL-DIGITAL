package be.pxl.streams;

import java.util.OptionalInt;
import java.util.Random;
import java.util.stream.IntStream;

public class Challenge2 {
	public static void main(String[] args) {
		// maak een stream met 10 random gehele getallen tussen 0 en 30
		// bekijk hiervoor de methode ints(...) in de klasse Random
		IntStream stream = new Random().ints(10, 0, 30);
		// Onderstaande is ook mogelijk

		// IntStream.generate(() -> ThreadLocalRandom.current().nextInt(30)).limit(10)
		// IntStream.generate(() -> new Random().nextInt(30)).limit(10)

		// filter de getallen die deelbaar zijn door 3
		stream = stream.filter(i -> i % 3 == 0);

		// en geef het maximum
		OptionalInt max = stream.max();

		// gebruik eventueel peek() om een tussenresultaat van de stream te tonen
		stream = stream.peek(System.out::println);
	}
}
