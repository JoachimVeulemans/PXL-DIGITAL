package be.pxl.computerstore.hardware;

import be.pxl.computerstore.exceptions.TooManyPeripheralsException;
import be.pxl.computerstore.util.Computable;

public class ComputerSystem implements Computable {
    public static final int MAX_PERIPHERAL = 3;
    private Processor processor;
    private HardDisk hardDisk;
    private ComputerCase computerCase;

    private Peripheral[] peripherals = new Peripheral[MAX_PERIPHERAL];

    public ComputerSystem() {
    }

    public void addPeripheral(Peripheral peripheral) throws TooManyPeripheralsException {
        boolean openSpot = false;

        for (int i = 0; i < peripherals.length; i++) {
            if (peripherals[i] == null) {
                peripherals[i] = peripheral;
                i = peripherals.length;
                openSpot = true;
            }
        }

        if (!openSpot) {
            throw new TooManyPeripheralsException();
        }
    }

    public Peripheral[] getPeripherals() {
        return peripherals;
    }

    public int getNumberOfPeripherals() {
        int number = 0;
        for (int i = 0; i < peripherals.length; i++) {
            if (peripherals[i] != null) {
                number++;
            }
        }
        return number;
    }

    @Override
    public double totalPriceExcl() {
        double price = 0;

        if (this.processor != null) {
            price += this.processor.getPrice();
        }

        if (this.hardDisk != null) {
            price += this.hardDisk.getPrice();
        }

        if (this.computerCase != null) {
            price += this.computerCase.getPrice();
        }

        for (int i = 0; i < peripherals.length; i++) {
            if (peripherals[i] != null) {
                price += peripherals[i].getPrice();
            }
        }

        return price;
    }

    @Override
    public double totalPriceIncl() {
        return this.totalPriceExcl() * 1.21;
    }

    public Processor getProcessor() {
        return processor;
    }

    public void setProcessor(Processor processor) {
        this.processor = processor;
    }

    public HardDisk getHardDisk() {
        return hardDisk;
    }

    public void setHardDisk(HardDisk hardDisk) {
        this.hardDisk = hardDisk;
    }

    public ComputerCase getComputerCase() {
        return computerCase;
    }

    public void setComputerCase(ComputerCase computerCase) {
        this.computerCase = computerCase;
    }

    public void removePeripheral(String articleNumber) {
        for (int i = 0; i < peripherals.length; i++) {
            if (peripherals[i] != null && peripherals[i].getArticleNumber().equals(articleNumber)) {
                peripherals[i] = null;
            }
        }
    }
}
