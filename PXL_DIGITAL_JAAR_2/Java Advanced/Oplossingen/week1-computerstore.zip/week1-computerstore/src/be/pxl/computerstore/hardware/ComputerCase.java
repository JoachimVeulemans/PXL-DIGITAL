package be.pxl.computerstore.hardware;

import be.pxl.computerstore.util.Dimension;

public class ComputerCase extends ComputerComponent {
    private Dimension dimension;
    private double weight;

    public ComputerCase(String vendor, String name, double price) {
        super(vendor, name, price);
    }

    public Dimension getDimension() {
        return dimension;
    }

    public void setDimension(Dimension dimension) {
        this.dimension = dimension;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getFullDescription() {
        StringBuilder text = new StringBuilder("");
        text.append(super.getFullDescription());
        text.append("Width = ").append(this.dimension.getWidth()).append("mm");
        text.append("\r\n");
        text.append("Height = ").append(this.dimension.getHeight()).append("mm");
        text.append("\r\n");
        text.append("Depth = ").append(this.dimension.getDepth()).append("mm");
        text.append("\r\n");
        text.append("Weight = ").append(this.weight).append("kg");
        text.append("\r\n");
        return text.toString();
    }
}
