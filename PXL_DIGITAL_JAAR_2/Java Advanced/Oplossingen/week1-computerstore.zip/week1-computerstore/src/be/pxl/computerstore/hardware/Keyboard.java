package be.pxl.computerstore.hardware;

import be.pxl.computerstore.data.KeyboardLayout;

public class Keyboard extends Peripheral {
    private KeyboardLayout KeyboardLayout;

    public Keyboard(String vendor, String name, double price, KeyboardLayout keyboardLayout) {
        super(vendor, name, price);
        this.KeyboardLayout = keyboardLayout;
    }
}
