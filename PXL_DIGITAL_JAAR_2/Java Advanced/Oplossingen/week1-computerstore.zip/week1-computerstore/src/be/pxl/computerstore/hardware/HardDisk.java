package be.pxl.computerstore.hardware;

public class HardDisk extends  Peripheral {
    private double storage;
    public HardDisk(String vendor, String name, double price, double storage) {
        super(vendor, name, price);
        this.storage = storage;
    }
}
