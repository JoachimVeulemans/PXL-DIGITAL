package be.pxl.computerstore.data;

public enum KeyboardLayout {
    AZERTY(),
    QWERTY()
}
