package be.pxl.computerstore.hardware;

public class Processor extends ComputerComponent {
    private double clockspeed;

    public Processor(String vendor, String name, double price, double clockspeed) {
        super(vendor, name, price);
        this.setClockspeed(clockspeed);
    }

    public double getClockspeed() {
        return clockspeed;
    }

    public void setClockspeed(double clockspeed) {
        if (clockspeed < 0.7) {
            this.clockspeed = 0.7;
        } else {
            this.clockspeed = clockspeed;
        }
    }

    public String getFullDescription() {
        StringBuilder text = new StringBuilder("");
        text.append(super.getFullDescription());
        text.append("Clock speed = ").append(this.clockspeed).append("GHz");
        text.append("\r\n");
        return text.toString();
    }

}
