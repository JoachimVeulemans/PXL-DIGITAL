package be.pxl.computerstore.exceptions;


public class TooManyPeripheralsException extends Exception {
    public TooManyPeripheralsException() {
        super();
    }
}
