package be.pxl.computerstore.hardware;

public class Monitor extends Peripheral {
    public Monitor(String vendor, String name, double price) {
        super(vendor, name, price);
    }
}
