package be.pxl.computerstore.hardware;

public abstract class Peripheral extends ComputerComponent {
    public Peripheral(String vendor, String name, double price) {
        super(vendor, name, price);
    }

    public String toString() {
        String currentClass = this.getClass().toString().substring(this.getClass().toString().lastIndexOf(".") + 1);
        return currentClass + " " + super.toString();
    }
}
