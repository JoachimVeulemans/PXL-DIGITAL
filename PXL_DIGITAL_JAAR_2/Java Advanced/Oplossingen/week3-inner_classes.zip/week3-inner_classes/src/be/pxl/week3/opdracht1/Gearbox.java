package be.pxl.week3.opdracht1;

import java.util.ArrayList;

public class Gearbox {
    private int maxGears;
    private boolean clutchIsIn = true;
    private ArrayList<Gear> gears = new ArrayList<>();
    private int currentGear;

    public Gearbox(int maxGears) {
        this.maxGears = maxGears;
        for (int i = 0; i <= this.maxGears; i++) {
            Gear newgear = new Gear(i);
            newgear.setRatio(i * 5.3);
            this.addGear(newgear);
        }
    }

    public void operateClutch(boolean in) {
        this.clutchIsIn = in;
    }

    private void addGear(Gear gear) {
        gears.add(gear);
    }

    public void changeGear(int newGear) {
        if (newGear >= 0 && newGear <= this.maxGears && clutchIsIn) {
            this.currentGear = newGear;
            System.out.println("Gear " + newGear + " selected");
        } else {
            this.currentGear = 0;
            System.out.println("hoi ik ben een vreemd geluid");
        }
    }

    public double wheelSpeed(int revs) {
        if (this.clutchIsIn) {
            System.out.println("Geluid!");
            return 0;
        } else {
            return gears.get(currentGear).driveSpeed(revs);
        }
    }

    private class Gear {
        private int gearNumber;
        private double ratio;

        public Gear(int gearNumber) {
            this.gearNumber = gearNumber;
        }

        public void setRatio(double ratio) {
            this.ratio = ratio;
        }

        public double driveSpeed(int revs) {
            return revs * ratio;
        }
    }
}
