package be.pxl.week3.opdracht2;

public interface Monster {
    void menace();
}
