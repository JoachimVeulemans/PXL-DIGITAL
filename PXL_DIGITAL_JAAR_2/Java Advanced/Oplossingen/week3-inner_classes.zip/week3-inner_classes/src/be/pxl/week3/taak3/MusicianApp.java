package be.pxl.week3.taak3;

public class MusicianApp {
    public static void main(String[] args) {
        System.out.println(new Musician().play());
    }
}
