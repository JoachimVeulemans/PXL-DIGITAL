package be.pxl.week3.taak2;

public class Musician {

    public void play() {
        class Instrument {
            public void makeNoise() {
                System.out.println("Geluid!");
            }
        }

        new Instrument().makeNoise();
    }
}
