package be.pxl.week3.taak2;

public class MusicianApp {
    public static void main(String[] args) {
        Musician musician = new Musician();
        musician.play();
    }
}
