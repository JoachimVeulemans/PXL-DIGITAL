package be.pxl.week3.taak3;

public interface Instrument {
    String makeNoise();
}
