package be.pxl.week3.taak3;

public class Musician {

    public String  play() {
        Instrument instrument = new Instrument() {
            @Override
            public String makeNoise() {
                return "blaf";
            }
        };

        return instrument.makeNoise();
    }
}
