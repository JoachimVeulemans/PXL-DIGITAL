<?php
namespace App\Models;

use CodeIgniter\Model;

class TodoModel extends Model
{
        protected $table = 'todolist';
        protected $returnType = '\App\Entities\Todo';
        protected $allowedFields = [
                'priority', 'text'
        ];


		public function countTodo(){
			$query = $this->db->query('SELECT COUNT(*) AS count FROM '. $this->table);
  			$result = $query->getResult();
			return $result[0]->count;
		}



}


