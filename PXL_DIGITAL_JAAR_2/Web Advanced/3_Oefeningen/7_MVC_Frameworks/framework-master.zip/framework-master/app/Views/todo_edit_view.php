<!doctype html>
<html>
<head>
    <title>Todo</title>
</head>
<body>
Totaal: <?php print($count); ?>
<?php print($pager->links()); ?>
<table>
    <?php
    foreach ($todoList as $todoItem) {
        print(form_open('/todo/edit?page=' . $page));
        print('<tr><td>');
        print(form_input([
            'name' => 'id',
            'value' => $todoItem->id,
            'type' => 'hidden'
        ]));
        print($todoItem->id);
        print('</td><td>');
        print(form_input([
            'name' => 'priority',
            'value' => $todoItem->priority
        ]));
        print('</td><td>');
        print(form_input([
            'name' => 'text',
            'value' => $todoItem->text
        ]));
        print(form_submit([
            'name' => 'submit',
            'value' => 'EDIT'
        ]));
        print('</td></tr>');
        print(form_close());
    }
    ?>
</table>
<?php print ($validator == null ? "" : $validator->listErrors()); ?>
<?php print(anchor('/todo?page=' . $page, 'BACK')); ?>
</body>
</html>
