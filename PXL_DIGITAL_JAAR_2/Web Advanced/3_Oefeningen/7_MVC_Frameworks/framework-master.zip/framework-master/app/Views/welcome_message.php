<!doctype html>
<html>
<head>
    <title>Welcome to CodeIgniter</title>
    <?php print (link_tag('assets/css/mystyle.css')); ?>
</head>
<body>
<?php
$imageProperties = [
    'src' => 'assets/images/pxl_it.png',
    'alt' => 'PXL IT logo',
    'width' => '200',
];

print(img($imageProperties));
print("\n");
print(anchor('news/1', 'My News'));
?>
<pre> base_url = <?php print(base_url()); ?></pre>
<pre> site_url = <?php print(site_url()); ?></pre>
<?php print(script_tag('assets/js/myjavascript.js')); ?>
</body>
</html>
