<!doctype html>
<html>
<head>
    <title>Welcome</title>

</head>
<body>
Hallo
<?php print(implode(", ", $who)); ?>

</body>
</html>
