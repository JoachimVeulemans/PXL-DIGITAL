<!doctype html>
<html>
<head>
    <title>Sum</title>

</head>
<body>

<?php print(implode("+ ", $numbers)); ?>
=
<?php print($sum); ?>

</body>
</html>
