<!doctype html>
<html>
<head>
    <title>Todo</title>

</head>
<body>

Totaal: <?php print($count); ?>
<?php print($pager->links()); ?>
<table>
    <?php
    foreach ($todoList as $todoItem) {
        print("<tr><td>" . $todoItem->id . "</td><td>" .
            $todoItem->priority . "</td><td>" .
            $todoItem->text . "</td></tr>");
    }
    ?>
</table>
<?php print(anchor('/todo/edit?page=' . $page, 'EDIT')); ?>
</body>
</html>
