<?php namespace App\Controllers;

use CodeIgniter\Controller;

class Greeter extends Controller
{
    public function greet()
    {
        $who = \func_get_args();
        $data = ['who' => $who];

        return view('greet_view', $data);
    }

}
