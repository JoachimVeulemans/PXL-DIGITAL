<?php namespace App\Controllers;

use \CodeIgniter\Controller;
use \CodeIgniter\Exceptions\PageNotFoundException;
use \App\Models\TodoModel;


class Todo extends Controller
{

    public function index()
    {
        helper(['url', 'html']);
        $todoModel = new TodoModel();
        $count = $todoModel->countTodo();
        $todoList = $todoModel->paginate(5);
        $page = $this->request->getGet('page');
        $data = ['todoList' => $todoList,
            'count' => $count,
            'pager' => $todoModel->pager,
            'page' => $page];
        return view('todo_view', $data);
    }

    public function edit()
    {
        helper(['url', 'html', 'form']);
        $todoModel = new TodoModel();
        $submit = $this->request->getPost('submit');
        if ($submit != null) {
            $rules = [
                'text' => ['label' => 'text', 'rules' => 'required|min_length[10]'],
                'priority' => ['label' => 'priority', 'rules' => 'required|integer|in_list[1,2,3]']
            ];
            $this->validate($rules);
            $id = $this->request->getPost('id');
            $text = $this->request->getPost('text');
            $priority = $this->request->getPost('priority');
            $todoModel->update($id, ['text' => $text, 'priority' => $priority]);
        }

        $count = $todoModel->countTodo();
        $todoList = $todoModel->paginate(5);
        $page = $this->request->getGet('page');
        $data = ['todoList' => $todoList,
            'count' => $count,
            'pager' => $todoModel->pager,
            'page' => $page,
            'validator' => $this->validator
        ];
        return view('todo_edit_view', $data);
    }
}
