<?php namespace App\Controllers;

use CodeIgniter\Controller;
use \CodeIgniter\Exceptions\PageNotFoundException;

class Math extends Controller
{
    public function sum()
    {
        $numbers = \func_get_args();
        $sum = 0;
        foreach ($numbers as $number) {
            if (!preg_match('/^\s*\d+\s*$/', $number)) {
                throw new PageNotFoundException();
            }
            $sum += $number;
        }
        $data = ['numbers' => $numbers, 'sum' => $sum];
        return view('sum_view', $data);
    }
}
