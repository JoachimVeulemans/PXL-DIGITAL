<?php

use PHPUnit\Framework\TestCase;

class ProductTest extends TestCase
{

    public function inValidIdProvider()
    {
        return [[-1, -1.0], [-2, 12.0]];
    }

    public function invalidPriceProvider()
    {
        return [[1, -1.0], [1, -12.0]];
    }

    public function validIdValidPriceProvider()
    {
        return [[1, 1.0], [2, 12.0]];
    }



    /**
     * @dataProvider invalidIdProvider
     * @expectedException InvalidArgumentException
     */
	public function testConstructor_invalidId_InvalidArgumentException($id, $price)
    {
        $product=new \accounting\Product($id, $price);
    }


    /**
     * @dataProvider invalidPriceProvider
     * @expectedException InvalidArgumentException
     */
    public function testConstructor_invalidPrice_InvalidArgumentException($id, $price)
    {
        $product=new \accounting\Product($id, $price);
    }


    /**
     * @dataProvider validIdValidPriceProvider
     */
    public function testConstructor_validIdValidPrice_product($id, $price)
    {
        $product=new \accounting\Product($id, $price);
		$isAProduct=$product instanceof \accounting\Product;
		$this->assertTrue($isAProduct);
        $actualId=$product->getId();
        $actualPrice=$product->getPrice();
        $this->assertEquals($id, $actualId,"$actualId should equal $id" );
        $this->assertEquals($price, $actualPrice,"$actualPrice should equal $price", 0.01);
    }

}
