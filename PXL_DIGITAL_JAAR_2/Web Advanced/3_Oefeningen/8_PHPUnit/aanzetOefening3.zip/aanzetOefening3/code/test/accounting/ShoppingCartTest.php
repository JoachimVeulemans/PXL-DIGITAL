<?php

use \accounting\Product;
use \accounting\ShoppingCart;

class ShoppingCartTest extends \PHPUnit\Framework\TestCase
{

}
