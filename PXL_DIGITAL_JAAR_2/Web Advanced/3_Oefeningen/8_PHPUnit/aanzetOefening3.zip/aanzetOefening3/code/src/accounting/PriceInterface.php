<?php
namespace accounting;
interface PriceInterface
{
    public function calculatePrice(): float;

}
