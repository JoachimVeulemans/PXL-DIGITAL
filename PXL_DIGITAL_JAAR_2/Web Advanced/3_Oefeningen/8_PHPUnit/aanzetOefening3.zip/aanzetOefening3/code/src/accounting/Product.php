<?php
namespace accounting;
class Product
{
    private $id;
    private $price;

    public function __construct(int $id, float $price)
    {
        if ($id < 0) {
            throw new \InvalidArgumentException("id $id negative");
        }
        if ($price < 0) {
            throw new \InvalidArgumentException("price $price negative");
        }
        $this->id = $id;
        $this->price = $price;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getPrice(): float
    {
        return $this->price;
    }

}
