<?php

namespace accounting;


class ShoppingCart implements PriceInterface
{
    private $products;


}
