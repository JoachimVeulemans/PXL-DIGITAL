<?php
require_once "vendor/autoload.php";

$product=new \accounting\Product(1,12.2);
$cart=new \accounting\ShoppingCart();
$cart->addProduct($product);
print($cart->calculatePrice());
