<?php

use \drawing\Point;
use \drawing\Line;

class LineTest extends \PHPUnit\Framework\TestCase
{

    public function listValidPointsProvider()
    {
        return [
			[new Point(1,3), new Point(4,5) ],
			[new Point(5,2), new Point(1,6) ],
			[new Point(1,-76), new Point(-1,6) ]
        ];
    }


    public function listInValidPointsProvider()
    {
        return [
			[new Point(1,3), null ],
			[null, new Point(1,6) ],
			[null, null ],
			[new Point(1,3), 1 ],
			[1, new Point(1,6) ],
			[1, 1 ]
        ];
    }
    /**
     * @dataProvider listInValidPointsProvider
     * @expectedException \Exception
     */
    public function testConstruct_inValidPoints_Exception($startPoint, $endPoint)
    {
		$line=new Line($startPoint, $endPoint);
    }

    /**
     * @dataProvider listValidPointsProvider
     */
    public function testConstruct_validPoints_LineObject($startPoint, $endPoint)
    {
		$line=new Line($startPoint, $endPoint);
		$this->assertTrue($line instanceof Line);
    }

}
