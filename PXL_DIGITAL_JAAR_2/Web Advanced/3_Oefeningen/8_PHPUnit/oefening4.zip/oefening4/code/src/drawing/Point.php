<?php
namespace drawing;
class Point
{
    private $x;
    private $y;

    public function __construct($x, $y)
    {
        $this->setX($x);
		$this->setY($y);
    }

	public function setX($x)
	{
		if(gettype($x)!='integer'){
			throw new \Exception("setX: \$x is geen integer");
		}
		$this->x=$x;
	}

	public function setY($y)
	{
		if(gettype($y)!='integer'){
			throw new \Exception("setX: \$y is geen integer");
		}
		$this->y=$y;
	}

    public function getX()
    {
        return $this->x;
    }

    public function getY()
    {
        return $this->y;
    }


}
