<?php
namespace drawing;
class Line
{
    private $startPoint;
    private $endPoint;

    public function __construct($startPoint, $endPoint)
    {
        $this->setStartPoint($startPoint);
        $this->setEndPoint($endPoint);
    }

	public function setStartPoint($startPoint)
	{
		if(!$startPoint instanceof Point){
			throw new \Exception("setStartPoint: \$startPoint is geen Point");
		}
		$this->startPoint=$startPoint;
	}

	public function setEndPoint($endPoint)
	{
		if(!$endPoint instanceof Point){
			throw new \Exception("setEndPoint: \$endPoint is geen Point");
		}
		$this->endPoint=$endPoint;
	}

    public function getEndPoint()
    {
        return $this->endPoint;
    }

    public function getStartPoint()
    {
        return $this->startPoint;
    }
}
