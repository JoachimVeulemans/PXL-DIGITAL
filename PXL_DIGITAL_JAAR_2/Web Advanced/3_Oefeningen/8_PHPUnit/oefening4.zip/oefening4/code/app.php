<?php
require_once "vendor/autoload.php";
use drawing\Point;
use drawing\Line;
$startPoint=new Point(1,2);
$endPoint=new Point(3,4);
$line=new Line($startPoint, $endPoint);
var_dump($line);

