<?php

// naam: Joachim Veulemans

namespace oef1;

require_once("src/model/entities/Message.php");
require_once("src/model/entities/Sender.php");
require_once("src/model/repositories/SenderRepository.php");

use PDOException;
use PDO;
use entities\Sender;
use entities\Message;
use repositories\SenderRepository;

$user = 'root';
$password = 'root';
$database = 'examenwa2019';
$server = 'localhost';
$id = $_GET["senderid"];
$pdo = null;
try {
    $pdo = new PDO("mysql:host=$server;dbname=$database", $user, $password);
    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );
    $senderRepository = new SenderRepository($pdo);
    $sender = $senderRepository->getSenderById($id);

    if ($sender == null) {
        print($id . " niet gevonden");
    } else {
        print("Sender met name " . $sender->getName() . " heeft " . $sender->countNumberOfMessages() . " berichten:");
        for ($i = 0; $i < $sender->countNumberOfMessages(); $i++) {
            print("<br>" . $sender->getMessageByIndex($i)->getContents());
        }
    }


} catch (PDOException $e) {
    print("error" . str($e));
}

