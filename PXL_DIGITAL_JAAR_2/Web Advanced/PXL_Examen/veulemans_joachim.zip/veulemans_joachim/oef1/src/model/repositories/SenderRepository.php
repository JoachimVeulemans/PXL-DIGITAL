<?php

// naam: Joachim Veulemans

namespace repositories;

use model\ModelException;
use PDO;
use PDOException;
use entities\Sender;
use entities\Message;

class SenderRepository{
	private $pdo;

    /**
     * SenderRepository constructor.
     * @param $pdo
     */
    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function getSenderById($id) {
        try {
            $query = 'SELECT sender.name, message.id, message.contents
                      FROM sender, message
                      WHERE sender.id = message.sender_id and sender.id = (:id)';
            $statement = $this->pdo->prepare($query);
            $statement->bindParam(':id', $id, PDO::PARAM_INT);
            $statement->setFetchMode(PDO::FETCH_ASSOC);
            $statement->execute();
            $sender = null;
            while (($row = $statement->fetch()) !== false) {
                if ($sender == null) {
                    $sender = Sender::make($id, $row["name"]);
                }
                $sender->addMessage(Message::make($row["id"], $row["contents"]));
            }
            return $sender;
        } catch (PDOException $e) {
            throw new ModelException();
        }
    }

}
