<?php

// naam: Joachim Veulemans

namespace entities;

use model\ModelException;

class Sender{
	private $id;
	private $name;
	private $messages;

    private function __construct($id, $name)
    {
        if ($id <= 0) {
            throw new ModelException();
        }
        $this->id = $id;
        $this->name = $name;
        $this->messages = [];
    }

    public static function make(int $id, string $name) {
        return new Sender($id, $name);
    }

    public function addMessage(Message $message) {
        array_push($this->messages, $message);
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    public function countNumberOfMessages() {
        return sizeof($this->messages);
    }

    public function getMessageByIndex($id) {
        return $this->messages[$id];
    }

}
