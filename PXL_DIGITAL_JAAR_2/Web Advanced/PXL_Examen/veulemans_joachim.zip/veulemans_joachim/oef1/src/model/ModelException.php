<?php namespace model;

class ModelException extends \Exception{
}
