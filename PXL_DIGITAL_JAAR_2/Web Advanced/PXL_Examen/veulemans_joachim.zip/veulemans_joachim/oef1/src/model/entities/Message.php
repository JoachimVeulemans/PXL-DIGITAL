<?php

// naam: Joachim Veulemans

namespace entities;

use model\ModelException;

class Message{
	private $id;
	private $contents;

    private function __construct($id, $contents)
    {
        if ($id <= 0) {
            throw new ModelException();
        }
        $this->id = $id;
        $this->contents = $contents;
    }

    public static function make(int $id, string $contents) {
        return new Message($id, $contents);
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getContents(): string
    {
        return $this->contents;
    }

    /**
     * @param string $contents
     */
    public function setContents(string $contents): void
    {
        $this->contents = $contents;
    }

}
