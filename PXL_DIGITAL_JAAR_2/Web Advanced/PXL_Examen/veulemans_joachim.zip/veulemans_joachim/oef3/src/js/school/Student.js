"use strict";
import Course from './Course';
// naam: Joachim Veulemans
export default class Student{
    constructor(id){
        this._id = id;
        this._courses = [];
    }

    addCourse(course) {
        if (!(course instanceof Course)) {
            throw new Error("parameter course is not of type Course");
        }

        this._courses.push(course);
    }

    calculateGrade() {
        let grade = 0;
        let numberOfCoursesComplete = 0;
        for(let i = 0; i < this._courses.length; i++) {
            if (this._courses[i].completed) {
                grade += this._courses[i].grade;
                numberOfCoursesComplete += 1;
            }
        }
        if (numberOfCoursesComplete === 0) {
            throw new Error("aantal voltooide vakken is gelijk aan 0");
        }
        return grade * 1.0 / numberOfCoursesComplete;
    }
}
