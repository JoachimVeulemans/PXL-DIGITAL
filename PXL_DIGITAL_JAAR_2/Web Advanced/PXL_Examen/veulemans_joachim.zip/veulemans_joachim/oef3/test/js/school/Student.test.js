import Course from '../../../src/js/school/Course';
import Student from '../../../src/js/school/Student';
// naam: Joachim Veulemans

describe('calculateGrade',
    () => {
        it('should throw error when student does not have a completed course',
            () => {
                let student = new Student(1);
                let course = new Course(1);
                student.addCourse(course);
                expect(() => {
                    student.calculateGrade();
                }).toThrow(Error)
            });

        it('should give back the correct value when a student has 1 completed course',
            () => {
                let student = new Student(1);
                let course = new Course(1);
                course.grade = 12;
                course.completed = true;
                student.addCourse(course);
                expect(student.calculateGrade()).toBe(12);
            });

    }
);