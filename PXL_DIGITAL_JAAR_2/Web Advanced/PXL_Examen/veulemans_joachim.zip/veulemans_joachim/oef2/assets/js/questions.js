window.addEventListener("load", loaded);

// naam: Joachim Veulemans

function loaded() {
    let buttonGetQuestions = document.getElementById('button_get_questions');
    buttonGetQuestions.addEventListener("click", handleGetQuestions);
}


function handleGetQuestions() {
    let url = 'questionnaire.json';
    let output = document.getElementById("div_output");
    makeElementEmpty(output);

    fetch(url)
        .then((response) => {
            if (response.status === 200) {
                return response.json();
            } else {
                throw `error with status ${response.status}`;
            }
        })
        .then((questionnaire) => {
            let questionnaireDiv = makequestionnaireDiv(questionnaire);
            output.appendChild(questionnaireDiv);
        })
        .catch((error) => {
            output.appendChild(document.createTextNode(error));
        });
}

function makeElementEmpty(element) {
    while (element.hasChildNodes()) {
        element.removeChild(element.firstChild);
    }
}

function makequestionnaireDiv(questionnaire) {
    let questionnaireDiv = document.createElement("div");
    let h1 = document.createElement("h1");
    h1.appendChild(document.createTextNode(questionnaire.title));
    questionnaireDiv.appendChild(h1);
    for(let i = 0; i < questionnaire.questions.length; i++) {
        question = questionnaire.questions[i];
        questionnaireDiv.appendChild(document.createElement("br"));

        questionnaireDiv.appendChild(document.createTextNode((i + 1) + " " + question));
        questionnaireDiv.appendChild(document.createElement("br"));

        let input = document.createElement("input");
        input.setAttribute("type", "text");
        input.setAttribute("id", "q" + (i + 1));
        questionnaireDiv.appendChild(input);

        questionnaireDiv.appendChild(document.createElement("hr"));
    }

    let button = document.createElement("button");
    button.appendChild(document.createTextNode("send"));
    button.setAttribute("id", "button_send");
    button.addEventListener("click", makeoutputDiv);
    questionnaireDiv.appendChild(button);

    return questionnaireDiv;
}

function makeoutputDiv() {
    let output = document.getElementById("div_output");
    let volgnummer = 1;
    let input = document.getElementById("q" + volgnummer);
    while (input !== null) {
        output.appendChild(document.createTextNode((volgnummer + 1) + " " + input.value));
        output.appendChild(document.createElement("hr"));

        volgnummer += 1;
        input = document.getElementById("q" + volgnummer);
    }

}
