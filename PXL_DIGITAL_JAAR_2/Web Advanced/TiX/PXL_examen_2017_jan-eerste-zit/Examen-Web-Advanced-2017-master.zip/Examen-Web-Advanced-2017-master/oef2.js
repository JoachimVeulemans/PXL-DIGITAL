function getById() {
    var id = document.getElementById("textAuthorID").value;

    fetch('list.php?id=' + id, {
        method: 'get'
    }).then(function (response) {
        return response.json();
    }).then(function (json) {
        var name = json['name'];
        var books = json.books;

        var output = name + " ";
        // For loop...
        for (i = 0; i < books.length; i++) {
            var book = books[i];
            output += book["title"] + " ";
        }

        // Set the output.
        var outputDiv = document.getElementById("divOutput");
        outputDiv.innerHTML = output;
    });
}