<?php

namespace Util;

class Book implements JsonWritable
{
    public $id;
    public $title;

    public function __construct($id, $title)
    {
        $this->id = $id;
        $this->title = $title;
    }

    public function getJSONString()
    {
        return json_encode([
            'id' => $this->id,
            'title' => $this->title,
        ]);
    }

}
