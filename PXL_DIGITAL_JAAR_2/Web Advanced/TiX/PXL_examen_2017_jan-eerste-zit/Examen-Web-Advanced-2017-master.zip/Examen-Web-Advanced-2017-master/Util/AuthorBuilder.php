<?php

/**
 * Created by PhpStorm.
 * User: Daan Vankerkom
 * Date: 15/06/2017
 * Time: 9:08
 */
namespace Util;

use Util\Author;

class AuthorBuilder
{
    public static function build($author, $books)  {
        return new Author(
            $author['id'],
            $author['name'],
            $books
        );
    }
}