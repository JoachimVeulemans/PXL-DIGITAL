<?php

namespace Util;

class Author implements JsonWritable
{
    private $id;
    private $name;
    private $books;

    public function __construct($id, $name, array $books)
    {
        $this->id = $id;
        $this->name = $name;
        $this->books = $books;
    }

    public function getJSONString()
    {
        return json_encode([
            'id' => $this->id,
            'name' => $this->name,
            'books' => $this->books,
        ]);
    }
}
