<?php

/**
 * Created by PhpStorm.
 * User: Daan Vankerkom
 * Date: 15/06/2017
 * Time: 9:13
 */
namespace Util;

use Util\Book;

class BookBuilder
{
    public static function build($results) {
        $books = [];

        foreach ($results as $result) {
            $newBook = new Book(
                $result['id'],
                $result['title']
            );

            array_push($books, $newBook);
        }

        return $books;
    }
}