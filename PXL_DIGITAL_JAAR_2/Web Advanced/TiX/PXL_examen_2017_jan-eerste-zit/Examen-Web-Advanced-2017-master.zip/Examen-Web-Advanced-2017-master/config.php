<?php
/**
 * Created by PhpStorm.
 * User: Daan Vankerkom
 * Date: 15/06/2017
 * Time: 9:39
 */
return [
    'host' => '127.0.0.1',
    'username' => 'root',
    'password' => '',
    'database' => 'examen'
];
