<?php

// Connect
include_once 'connector.php';

// Delete if is set.
$bookId = isset($_POST['bookId']) ? intval($_POST['bookId']) : 0;

if ($bookId > 0) {
    // Attempt to delete
    $statement = $pdo->prepare('DELETE FROM book WHERE id=:id');
    $statement->bindParam('id', $bookId, PDO::PARAM_INT);
    $result = $statement->execute();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3verwerk</title>
</head>
<body>
    <p>Affected Rows: <?php echo $statement->rowCount(); ?></p>
</body>
</html>
