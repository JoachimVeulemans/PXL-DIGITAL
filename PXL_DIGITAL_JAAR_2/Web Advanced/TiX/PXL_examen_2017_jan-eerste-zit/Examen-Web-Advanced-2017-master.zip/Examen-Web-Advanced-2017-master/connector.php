<?php
/**
 * Created by PhpStorm.
 * User: Daan Vankerkom
 * Date: 15/06/2017
 * Time: 9:41
 */

// Database config to make your life a lot easier.
$config = include 'config.php';


// Connecting to the database...
try {
    $pdo = new PDO(
        'mysql:host=' . $config['host'] . ';dbname=' . $config['database'],
        $config['username'],
        $config['password']
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch (Exception $e) {
    die(json_encode([]));
}
