<?php
// Om aan de oefening over fetch te kunnen beginnen wordt in de huidige versie van list.php altijd een JSON-string afgedrukt.
// Je mag list.php natuurlijk aanpassen aan het gevraagde in de oefening over PDO.

// Lazy including
require_once 'vendor/autoload.php';

// Using namespace
use Util\AuthorBuilder;
use Util\BookBuilder;

// Connect to the database, let's use a clever bypass so we do not need to write much code...
// We are programmers and we are lazy, it's ok it works.
include_once 'connector.php';

// Set empty output by default.
$output = [];

// Fetch user id.
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Validate if the id can be found.
if ($id > 0) {

    // Select if the author exists inside the database.
    $statement = $pdo->prepare('SELECT * FROM author WHERE id=:id');
    $statement->bindParam(':id', $id, PDO::PARAM_INT);
    $statement->execute();

    // Check results count.
    if ($statement->rowCount() > 0) {
        // Generate output.. (for now)
        $authorResult = $statement->fetch();

        // Fetch the books of the author
        $bookStatement = $pdo->prepare('SELECT * FROM book WHERE author_id=:author_id');
        $bookStatement->bindParam(':author_id', $authorResult['id'], PDO::PARAM_INT);
        $bookStatement->execute();

        $booksResult = $bookStatement->fetchAll(PDO::FETCH_ASSOC);

        $books = BookBuilder::build($booksResult);
        $author = AuthorBuilder::build($authorResult, $books);

        echo $author->getJSONString();
    }else{
        echo json_decode([]);
    }
}else{
    echo json_encode([]);
}
