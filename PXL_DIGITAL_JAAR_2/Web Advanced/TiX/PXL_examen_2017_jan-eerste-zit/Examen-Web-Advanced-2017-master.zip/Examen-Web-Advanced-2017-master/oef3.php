<?php

// Connect
include_once 'connector.php';

// Fetch
$statement = $pdo->prepare('SELECT * FROM book');
$statement->execute();
$books = $statement->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Oef3</title>
</head>
<body>


<form action="oef3verwerk.php" method="post" accept-charset="utf-8">

    <label for="bookId">
        bookId:
    </label>
    <select id="bookId" name="bookId">
        <?php
        foreach($books as $book) {
            echo '<option value="' . $book['id'] . '">' . $book['id'] . '</option>';
        }
        ?>
    </select>

    <input type="submit" value="Delete"/>
</form>
</body>
</html>
