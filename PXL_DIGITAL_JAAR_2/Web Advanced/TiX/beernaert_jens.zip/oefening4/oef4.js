// Naam: Jens Beernaert
window.addEventListener("load", handleWindowLoad);

function handleWindowLoad() {
    var buttonclick = document.getElementById("buttonclick");
    buttonclick.addEventListener("click", handleClick);
}


function handleClick() {
    const URL = 'telefoons.json';

    fetch(URL)
        .then((response) => {
            return response.json()
        })
        .then((data) => {
            findName(data)
        })
        .catch((exception) => {
            console.log(exception.message);
            clearInput();
        });
}

function findName(data) {
    var table = document.getElementById("results");
    var txtnaam = document.getElementById("txtnaam");
    var naam = txtnaam.value;

    table.innerHTML = "";

    if (!naam.match(/^[A-Za-z]+$/)) {
        clearInput();
    }

    for (var i = 0; i < data.length; i++) {
        if (data[i].name.startsWith(naam)) {
            var newRow = document.createElement("tr");

            var newNameCol = document.createElement("td");
            newNameCol.innerHTML = data[i].name;

            var newTelCol = document.createElement("td");
            newTelCol.innerHTML = data[i].tel;

            newRow.appendChild(newNameCol);
            newRow.appendChild(newTelCol);
            table.appendChild(newRow);
        }
    }
}

function clearInput() {
    var txtnaam = document.getElementById("txtnaam");
    txtnaam.value = "";
}



