<?php
// Naam: Jens Beernaert
namespace Util;

use Psr\Log\InvalidArgumentException;

class Product implements Comparable
{
    private $price;
    private $name;

    private function __construct($price, $name)
    {
        $this->price = $price;
        $this->name = $name;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function getName()
    {
        return $this->name;
    }

    public static function create($price, $name)
    {
        if (!is_numeric($price) || $price < 0)
            throw new InvalidArgumentException('Price needs to be a positive number');

        if (!is_string($name) || strlen($name) <= 2)
            throw new InvalidArgumentException('Name needs to be a string longer than 2 chars');

        return new self($price, $name);
    }

    public function equals(Comparable $other)
    {
        if (!$other instanceof Product)
            return false;

        if ($other->name != $this->name)
            return false;

        return true;
    }
}
