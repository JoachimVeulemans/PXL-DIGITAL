<?php
// Naam: Jens Beernaert
namespace Util;
interface Comparable
{
    public function equals(Comparable $other);
}
