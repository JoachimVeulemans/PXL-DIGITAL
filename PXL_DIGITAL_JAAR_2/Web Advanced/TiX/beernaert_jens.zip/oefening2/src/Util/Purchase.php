<?php
// Naam: Jens Beernaert
namespace Util;
class Purchase
{
    private $products;

    private function __construct()
    {
        $this->products = array();
    }

    public function create()
    {
        return new self();
    }

    public function addProduct(Product $product)
    {
        $this->products[] = $product;
    }

    public function getNumberOfProducts()
    {
        return count($this->products);
    }

    public function getProductAt($i)
    {
        if (!is_int($i) || $i < 0 || $i >= $this->getNumberOfProducts())
            throw new \InvalidArgumentException("Invalid index");

        return $this->products[$i];
    }

    public function getTotalPrice()
    {
        $total = 0;
        foreach ($this->products as $product) {
            $total += $product->getPrice();
        }
        return $total;
    }
}


