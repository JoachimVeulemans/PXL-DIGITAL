<?php
// Naam: Jens Beernaert
require 'src/Util/Comparable.php';
require 'src/Util/Product.php';
require 'src/Util/Purchase.php';

use Util\Comparable;
use Util\Product;
use Util\Purchase;


$product1 = Product::create(2, "Krant");
$product2 = Product::create(1.2, "Snoep");
$product3 = Product::create(2.3, "Magazine");

$purchase = Purchase::create();
$purchase->addProduct($product1);
$purchase->addProduct($product2);
$purchase->addProduct($product3);
$count = $purchase->getNumberOfProducts();
for ($i = 0; $i < $count; $i++) {
    print($purchase->getProductAt($i)->getName() . "\n");
}

print($purchase->getTotalPrice() . "\n");


try {
    $product = Product::create(-1, "Krant");
} catch (InvalidArgumentException $e) {
    print($e->getMessage() . "\n");
}

try {
    $product = Product::create("mis", "Krant");
} catch (InvalidArgumentException $e) {
    print($e->getMessage() . "\n");
}

try {
    $product = Product::create(1, "a");
} catch (InvalidArgumentException $e) {
    print($e->getMessage() . "\n");
}
try {
    $product = Product::create(1, 1);
} catch (InvalidArgumentException $e) {
    print($e->getMessage() . "\n");
}


$purchase->addProduct(array(1, 2));

