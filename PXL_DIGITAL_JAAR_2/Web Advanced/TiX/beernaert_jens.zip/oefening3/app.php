<?php
// Naam: Jens Beernaert
$user = 'root';
$password = 'root';

if (isset($_GET['submit_1'])) {
    ?>
    <form action='app.php' method='get'>
        <?php
        $database = $_GET['database'];
        $table = $_GET['table'];

        try {
            $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);

            $statement = $pdo->query("SELECT * FROM " . $table);
            $statement->setFetchMode(PDO::FETCH_ASSOC);

            if ($statement->rowCount() > 0) {
                for ($i = 0; $i < $statement->columnCount(); $i++) {
                    $columnData = $statement->getColumnMeta($i);

                    print '<input type="checkbox" name="column[]" value="' . $columnData['name'] . '"/>' . $columnData['name'];
                }
            }
        } catch (PDOException $exception) {
            print '<p>Something went wrong!</p>';
        }
        ?>
        <input type='hidden' name='database' value="<?php echo $_GET['database']; ?>"/>
        <input type='hidden' name='table' value="<?php echo $_GET['table']; ?>"/>
        <input type='submit' name='submit_2'/>
    </form>

    <?php
} elseif (isset($_GET['submit_2'])) {
    $database = $_GET['database'];
    $table = $_GET['table'];
    $columns = $_GET['column'];

    try {
        $pdo = new PDO("mysql:host=localhost;dbname=$database", $user, $password);
        $sql = "SELECT " . implode(', ', $columns) . " FROM " . $table;

        $statement = $pdo->query($sql);
        $statement->setFetchMode(PDO::FETCH_ASSOC);

        if ($statement->rowCount() > 0) {
            print("<table>");
            while ($row = $statement->fetch()) {
                print('<tr><td>' . implode('</td><td>', $row) .
                    '</td></tr>');
            }
            print("</table>");
        }
    } catch (PDOException $exception) {
        print '<p>Something went wrong!</p>';
    }
} else {
    ?>
    <form action='app.php' method='get'>
        database:<input type='text' name='database'/><br/>
        table:<input type='text' name='table'/><br/>
        <input type='submit' name='submit_1'/>
    </form>
    <?php
}
?>
