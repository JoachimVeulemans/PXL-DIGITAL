#!/bin/bash

docker image rm spring_break:latest
