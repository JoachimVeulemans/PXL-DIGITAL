#!/bin/bash

docker build -t spring_break:latest .
