#!/usr/bin/env python2.7

import sys
import rospy

from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import QTimer
from PyQt5.uic import loadUi

from sensor_msgs.msg import Image
from threading import Lock

GUI_UPDATE_PERIOD = 20 #ms

class DashBoard(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)

        loadUi("mainwindow.ui", self)
        self.setWindowTitle("Dashboard")
        self.setFixedSize(819, 510)

        # Connect callbacks and set initial states
        # . . .
        # Tim doesn't share __ALL__ his code!
        # . . .

        self.player_combo.activated.connect(self.player_combo_activated)
        self.current_player = self.player_combo.currentText()

        self.image = None
        self.image_lock = Lock()
        self.video_sub   = rospy.Subscriber("/player_one/camera/rgb/image_raw", Image, self.callback_image_raw)

        self.timer_redraw = QTimer(self)
        self.timer_redraw.timeout.connect(self.redraw_callback)
        self.timer_redraw.start(GUI_UPDATE_PERIOD)

    def player_combo_activated(self):
        selected_player = self.player_combo.currentText()
        if self.current_player != selected_player:
            self.current_player = selected_player
            print "Changed"

    def callback_image_raw(self, data):
        self.image_lock.acquire()
        try:
            self.image = data
        finally:
            self.image_lock.release()

    def redraw_callback(self):
        if self.image is not None:
            self.image_lock.acquire()

            try:
                format = QImage.Format_RGB888
                image_converted = QImage(self.image.data, self.image.width, self.image.height, format)
                pixmap = QPixmap.fromImage(image_converted)
                self.image_label.resize(pixmap.width(), pixmap.height())
                self.image_label.setPixmap(pixmap)
            finally:
                self.image_lock.release()


if __name__ == "__main__":
    rospy.init_node("dashboard", anonymous=False)
    app = QtWidgets.QApplication(sys.argv)
    mainWin = DashBoard()
    mainWin.show()
    sys.exit(app.exec_())