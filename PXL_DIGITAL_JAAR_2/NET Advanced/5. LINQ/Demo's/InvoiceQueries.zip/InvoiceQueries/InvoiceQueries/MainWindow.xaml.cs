﻿using InvoiceQueries.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace InvoiceQueries
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IList<Invoice> _allInvoices;
        private IList<Invoice> AllInvoices
        {
            get
            {
                if (_allInvoices == null)
                {
                    _allInvoices = InvoiceRepository.GetAll();
                }
                return _allInvoices;
            }
        }

        private IList<Vendor> _allVendors;
        private IList<Vendor> AllVendors
        {
            get
            {
                if (_allVendors == null)
                {
                    _allVendors = VendorRepository.GetAll();
                }
                return _allVendors;
            }
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ShowInvoicesSumButton_OnClick(object sender, RoutedEventArgs e)
        {
            //Define the query expression
            var invoiceQuery = from invoice in AllInvoices
                select invoice;

            //Execute the query
            decimal sum = 0;
            foreach (var invoice in invoiceQuery) //triggers query execution
            {
                sum += invoice.InvoiceTotal;
            }
            MessageBox.Show(sum.ToString("C"), "Sum of invoices");
        }

        private void ShowBigInvoicesButton_OnClick(object sender, RoutedEventArgs e)
        {
            //Define the query expression
            var bigInvoiceQuery = from invoice in AllInvoices
                                  join vendor in AllVendors on invoice.VendorId equals vendor.VendorId
                                  where invoice.InvoiceTotal > 20000
                                  orderby invoice.InvoiceTotal descending
                                  select new
                                  {
                                      VendorName = vendor.Name,
                                      invoice.InvoiceNumber,
                                      invoice.InvoiceTotal
                                  };

            ////FYI: Method syntax equivalent:
            //var bigInvoiceQuery = allInvoices.Where(invoice => invoice.InvoiceTotal > 20000)
            //    .Join(allVendors, invoice => invoice.VendorId, vendor => vendor.VendorId, (invoice, vendor) => new
            //    {
            //        VendorName = vendor.Name,
            //        invoice.InvoiceNumber,
            //        invoice.InvoiceTotal
            //    });

            //Execute the query
            var resultBuilder = new StringBuilder("Vendor\t\t\tInvoice No.\tInvoice Total");
            resultBuilder.AppendLine();
            foreach (var item in bigInvoiceQuery) //triggers query execution
            {
                resultBuilder.AppendLine($"{item.VendorName}\t{item.InvoiceNumber}\t\t{item.InvoiceTotal:C}");
            }
            MessageBox.Show(resultBuilder.ToString());
        }

        private void ShowInvoicesDueButton_OnClick(object sender, RoutedEventArgs e)
        {
            //Define the query expression
            var invoicesDueQuery = from invoice in AllInvoices
                                   let balanceDone = invoice.CreditTotal + invoice.PaymentTotal
                                   where invoice.BalanceDue > 0 &&
                                          invoice.DueDate < DateTime.Today.AddDays(15)
                                   orderby balanceDone, invoice.InvoiceNumber
                                   select new
                                   {
                                       Number = invoice.InvoiceNumber,
                                       invoice.BalanceDue,
                                       BalanceDone = balanceDone
                                   };

            //Execute the query
            var resultBuilder = new StringBuilder("Invoice No.\tBalance due\tBalance done");
            resultBuilder.AppendLine();
            foreach (var item in invoicesDueQuery) //triggers query execution
            {
                resultBuilder.AppendLine($"{item.Number.PadRight(15)}\t{item.BalanceDue:C}\t\t{item.BalanceDone:C}");
            }
            MessageBox.Show(resultBuilder.ToString());
        }

        private void ShowGroupedInvoicesButton_OnClick(object sender, RoutedEventArgs e)
        {
            //Define the query expression
            var groupedInvoicesQuery = from invoice in AllInvoices
                                       where invoice.InvoiceTotal > 20000
                                       group invoice by invoice.VendorId into vendorGroup
                                       select new
                                       {
                                           VendorId = vendorGroup.Key,
                                           InvoiceCount = vendorGroup.Count(),
                                           Invoices = vendorGroup,
                                       };

            ////FYI: Method syntax equivalent:
            //var groupedInvoicesQuery = allInvoices.Where(invoice => invoice.InvoiceTotal > 20000)
            //    .GroupBy(invoice => invoice.VendorId)
            //    .Select(vendorGroup => new
            //    {
            //        VendorId = vendorGroup.Key,
            //        InvoiceCount = vendorGroup.Count(),
            //        Invoices = vendorGroup,
            //    });

            //Execute the query
            var resultBuilder = new StringBuilder("Vendor Id (#invoices)\t\tInvoice No.\tInvoice Total");
            resultBuilder.AppendLine();
            foreach (var vendorInfo in groupedInvoicesQuery) //triggers query execution
            {
                resultBuilder.AppendLine($"{vendorInfo.VendorId} ({vendorInfo.InvoiceCount})");
                foreach (var invoice in vendorInfo.Invoices)
                {
                    resultBuilder.AppendLine($"\t\t\t{invoice.InvoiceNumber.PadRight(15)}\t{invoice.InvoiceTotal:C}");
                }
            }
            MessageBox.Show(resultBuilder.ToString());
        }
    }
}
