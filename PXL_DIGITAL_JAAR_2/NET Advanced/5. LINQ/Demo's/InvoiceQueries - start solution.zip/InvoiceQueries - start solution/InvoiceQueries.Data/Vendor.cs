﻿namespace InvoiceQueries.Data
{
    public class Vendor
    {
        public int VendorId { get; set; }

        public string Name { get; set; }
    }
}