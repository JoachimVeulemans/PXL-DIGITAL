﻿using System.Configuration;
using System.Data.SqlClient;

namespace Payables.Data
{
    internal static class PayablesDB
    {
        public static SqlConnection GetConnection()
        {
            //string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Payables;Integrated Security=True";
            string connectionString =
                ConfigurationManager.ConnectionStrings["PayablesConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }
    }
}
