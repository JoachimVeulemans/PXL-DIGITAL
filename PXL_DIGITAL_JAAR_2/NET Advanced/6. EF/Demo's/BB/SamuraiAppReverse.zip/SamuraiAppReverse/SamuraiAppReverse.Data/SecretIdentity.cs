﻿using System;
using System.Collections.Generic;

namespace SamuraiAppReverse.Data
{
    public partial class SecretIdentity
    {
        public int Id { get; set; }
        public string RealName { get; set; }
        public int SamuraiId { get; set; }

        public Samurais Samurai { get; set; }
    }
}
