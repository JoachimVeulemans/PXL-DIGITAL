﻿using SamuraiApp.Data;
using SamuraiApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SamuraiApp.UI
{
    class Program
    {
        private static SamuraiContext _context = new SamuraiContext();

        static void Main(string[] args)
        {
            // InsertSingleSamurai();
            // InsertMultipleSamurais();
            // InsertMultipleDifferentObjects();

            // ExecuteSimpleSamuraiQuery();
            // ExecuteOtherQueries();

            // RetrieveAndUpdateSamurai();
            // RetrieveAndUpdateMultipleSamurai();

            // DoMultipleDatabaseOperations();

            // DeleteTrackedSamurai();
            // DeleteUnTrackedSamurai();
            // DeleteMany();
            // DeleteById(5);

            Console.WriteLine();
            Console.WriteLine("Press any key to close the window.");
            Console.ReadKey(true);
        }

        private static void DeleteById(int samuraiId)
        {
            var samurai = _context.Samurais.Find(samuraiId);
            _context.Remove(samurai);
            _context.SaveChanges();
        }

        private static void DeleteMany()
        {
            var samuraisToDeleteQuery = _context.Samurais.Where(s => s.Name.Contains("i"));
            _context.Samurais.RemoveRange(samuraisToDeleteQuery); 
            //Alternative: _context.RemoveRange(samuraisToDeleteQuery);
            _context.RemoveRange();
        }

        private static void DeleteUnTrackedSamurai()
        {
            var firstSamurai = _context.Samurais.First();
            using (var otherContext = new SamuraiContext())
            {
                otherContext.Samurais.Remove(firstSamurai);
                otherContext.SaveChanges();
            }
        }

        private static void DeleteTrackedSamurai()
        {
            var firstSamurai = _context.Samurais.First();
            _context.Samurais.Remove(firstSamurai);
            _context.SaveChanges();
        }

        private static void DoMultipleDatabaseOperations()
        {
            var firstSamurai = _context.Samurais.First();
            firstSamurai.Name += "Hiro";

            _context.Samurais.Add(new Samurai { Name = "Kikuchiyo" });

            _context.SaveChanges();
        }

        private static void RetrieveAndUpdateMultipleSamurai()
        {
            var allSamurais = _context.Samurais.ToList();
            allSamurais.ForEach(s => s.Name += "San");
            _context.SaveChanges();
        }

        private static void RetrieveAndUpdateSamurai()
        {
            var firstSamurai = _context.Samurais.First();
            firstSamurai.Name += "San";
            _context.SaveChanges();
        }

        private static void ExecuteOtherQueries()
        {
            var name = "Bruce";
            var bruce = _context.Samurais.FirstOrDefault(s => s.Name == name);
            PrintSamurai(bruce);

            var primus = _context.Samurais.Find(1);
            PrintSamurai(primus);

            var matchText = "e";
            var samuraisWithE = _context.Samurais.Where(s => s.Name.Contains(matchText)).ToList();
            //Alternative: var samuraisWithE = _context.Samurais.Where(s => EF.Functions.Like(s.Name, $"%{matchText}%"));
            foreach (var samurai in samuraisWithE)
            {
                PrintSamurai(samurai);
            }

            var lastSamurai = _context.Samurais.OrderBy(s => s.Id).LastOrDefault();
            PrintSamurai(lastSamurai);
        }

        private static void ExecuteSimpleSamuraiQuery()
        {
            var allSamurais = _context.Samurais.ToList();

            //Alternative:
            //var allSamurais = (from samurai in context.Samurais
            //                  select samurai).ToList();

            foreach (var samurai in allSamurais)
            {
                PrintSamurai(samurai);
            }
        }

        private static void InsertMultipleDifferentObjects()
        {
            var bruce = new Samurai { Name = "Bruce" };
            var nagashinoBattle = new Battle
            {
                Name = "Battle of Nagashino",
                StartDate = new DateTime(985, 6, 16),
                EndDate = new DateTime(985, 6, 28),
            };

            _context.AddRange(bruce, nagashinoBattle);
            _context.SaveChanges();

        }

        private static void InsertMultipleSamurais()
        {
            var samurais = new List<Samurai>();
            samurais.Add(new Samurai { Name = "Marijke" });
            samurais.Add(new Samurai { Name = "Kris" });

            _context.Samurais.AddRange(samurais);
            _context.SaveChanges();
        }

        private static void InsertSingleSamurai()
        {
            var samurai = new Samurai { Name = "Wesley" };

            _context.Samurais.Add(samurai);
            _context.SaveChanges();
        }

        private static void PrintSamurai(Samurai samurai)
        {
            Console.WriteLine($"Samurai: {samurai.Name}");
        }
    }
}
