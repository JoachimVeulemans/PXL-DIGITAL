﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SamuraiApp.UI
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
