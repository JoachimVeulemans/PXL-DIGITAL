﻿using System.Collections.Generic;
using System.Data.SqlClient;

namespace CocktailBarData
{
    public class IngredientsRepository
    {
        public static List<Ingredient> GetAllIngredients()
        {
            // TODO: gebruik de nodige ADO classes om alle 
            // ingrediënten uit de database te lezen.
            try
            {
                SqlCommand selectCommand = new SqlCommand();
                SqlConnection con = CocktailsDB.GetConnection();
                con.Open();
                selectCommand.Connection = con;
                string selectStatement =
                    "select * from dbo.Ingredients";
                selectCommand.CommandText = selectStatement;
                SqlDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

                List<Ingredient> IngredientList = new List<Ingredient>();
                while (reader.Read())
                {
                    Ingredient cocktail = new Ingredient();
                    cocktail.Id = int.Parse(reader["Id"].ToString());
                    cocktail.Name = reader["Name"].ToString();
                    cocktail.Unit = reader["Unit"].ToString();
                    IngredientList.Add(cocktail);
                }
                return IngredientList;

            }
            catch (System.Exception ex)
            {

                throw new System.Exception("Fout bij het ophalen van de IngredientsData: " + ex.Message);
            }
        }
    }
}

