﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;

namespace CocktailBarData
{
    public static class CocktailIngredientsRepository
    {        
        public static List<CocktailIngredient> GetCocktailIngredients(int cocktailId)
        {
            // TODO: gebruik de nodige ADO.NET classes om 
            // de gegevens uit de database te lezen
            // Schrijf een SELECT query om de gegevens van de
            // CocktailIngredients tabel te lezen, samen met 
            // de naam en de eenheid van het ingredient (2 kolommen uit de Ingredients tabel)
            // Tip: null can je casten naar een nullable decimal (decimal?) als volgt: (decimal?) null
            try
            {

                SqlCommand selectCommand = new SqlCommand();
                SqlConnection con = CocktailsDB.GetConnection();
                con.Open();
                selectCommand.Connection = con;
                string selectStatement =
                    "select CI.IngredientId, ING.Name, CI.Quantity, ING.Unit, CI.CocktailId" +
                    " from dbo.CocktailIngredients CI " +
                    "JOIN dbo.Ingredients ING ON CI.IngredientId = ING.Id" +
                    " where ci.CocktailID = " + cocktailId;
                
                selectCommand.CommandText = selectStatement;
                SqlDataReader reader = selectCommand.ExecuteReader(CommandBehavior.CloseConnection);

                List<CocktailIngredient> cocktailIngedientList = new List<CocktailIngredient>();
                while (reader.Read())
                {
                    CocktailIngredient cocktail = new CocktailIngredient();
                    cocktail.IngredientId = int.Parse(reader["IngredientId"].ToString());
                    cocktail.IngredientName = reader["Name"].ToString();
                    cocktail.Quantity = (Decimal?) (reader.IsDBNull(3)?null:reader["Quantity"]);
                    cocktail.Unit =  reader["Unit"].ToString();
                    cocktail.CocktailId = int.Parse(reader["CocktailId"].ToString());

                    cocktailIngedientList.Add(cocktail);
                }
                return cocktailIngedientList;

            }
            catch (Exception ex)
            {

                throw new Exception("Fout bij het ophalen van de CocktailIngredientsData: " + ex.Message);
            }
        }
    }
}
