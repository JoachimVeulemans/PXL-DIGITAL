﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;

namespace CocktailBarData
{
    public class CocktailsRepository
    {
        public static List<Cocktail> GetAllCocktails()
        {
            // TODO: Gebruik de nodige ADO.NET classes om alle
            // cocktails uit de database te lezen.
            try
            {
                SqlCommand selectCommand = new SqlCommand();
                SqlConnection con = CocktailsDB.GetConnection();
                con.Open();
                selectCommand.Connection = con;
                string selectStatement =
                    "select * from Cocktails";
                selectCommand.CommandText = selectStatement;
                SqlDataReader reader = selectCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

                List<Cocktail> cocktailList = new List<Cocktail>();
                while (reader.Read())
                {
                    Cocktail cocktail = new Cocktail();
                    cocktail.Id = int.Parse(reader["Id"].ToString());
                    cocktail.Name = reader["Name"].ToString();
                    cocktail.Description = reader["Description"].ToString();
                    cocktail.Instructions = reader["Instructions"].ToString();
                    cocktailList.Add(cocktail);
                }
                return cocktailList;

            } 
            catch (System.Exception ex)
            {

                throw new Exception("Fout bij het ophalen van de cocktaildata: " + ex.Message);
            }
        }
    }
}

