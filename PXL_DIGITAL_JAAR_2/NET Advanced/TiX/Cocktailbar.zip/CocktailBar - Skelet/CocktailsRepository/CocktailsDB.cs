﻿using System.Configuration;
using System.Data.SqlClient;
namespace CocktailBarData
{
    public class CocktailsDB
    {
        public static SqlConnection GetConnection()
        {
            // TODO: Lees de connectionstring uit de configfile
            SqlConnection con;
            string connectionString = ConfigurationManager.ConnectionStrings["CocktailsConnectionString"].ConnectionString;
            con = new SqlConnection(connectionString);
            return con;
        }
    }
}
