﻿using CocktailBarData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CocktailBar
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //TODO Voeg hier de nodige code toe: 
        // Bij het dubbelklikken op een cocktail moet er naar
        // het CocktailDetailsWindow genavigeerd worden.
        // Wanneer er op de + wordt geklikt, moet er naar het 
        // AddCocktailWindow genavigeerd worden
        List<Cocktail> cocktailList;
        public MainWindow()
        {
            InitializeComponent();
            
           // List<Cocktail> listViewList;
            cocktailList = CocktailsRepository.GetAllCocktails();

            cocktailListView.ItemsSource = (from c in cocktailList
                                            select new
                                            {
                                                Id = c.Id,
                                                Name = c.Name,
                                                Description = c.Description
                                            }).ToList(); 
        }

        private void cocktailListView_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            CocktailDetailsWindow window = new CocktailDetailsWindow(cocktailList[cocktailListView.SelectedIndex]);
            window.Show();
        }
    }
}
