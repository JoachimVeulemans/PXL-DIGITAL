﻿using CocktailBar.Converters;
using CocktailBarData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CocktailBar
{
    /// <summary>
    /// Interaction logic for CocktailDetails.xaml
    /// </summary>
    public partial class CocktailDetailsWindow : Window
    {
        List<Ingredient> ingredientList;
        List<CocktailIngredient> detailsList;
        List<Cocktail> cocktailList;
        // TODO: Voeg de nodige code toe: zorg dat de details
        // van de cocktail, in dit venster worden getoond.
        // Zorg dat de ingrediënten van de cocktail in een listview worden getoond.
        public CocktailDetailsWindow(Cocktail cocktail)
        {
            InitializeComponent();
            ingredientList = IngredientsRepository.GetAllIngredients();
            detailsList = CocktailIngredientsRepository.GetCocktailIngredients(cocktail.Id);
            cocktailList = CocktailsRepository.GetAllCocktails();

            IngredientsListView.DataContext = (from c in ingredientList 
                                               join d in detailsList on c.Id equals d.CocktailId
                                               where cocktail.Id == c.Id
                                               select new { Name = d.IngredientName , Unit = c.Unit , Quantity = d.Quantity}
                                              ).ToList();

            cocktailname.DataContext = (from c in cocktailList
                                        where cocktail.Id == c.Id
                                        select new { Name = c.Name }).ToList();

            descriptionBox.DataContext = (from c in cocktailList
                                          where cocktail.Id == c.Id
                                          select new { Description = c.Description });

            instructionBox.DataContext = (from c in cocktailList
                                          where cocktail.Id == c.Id
                                          select new { Instruction = c.Instructions });

            ImageConverter converter = new ImageConverter();
            converter.ImagePath = cocktail.Name;
            imageBox.DataContext = converter;
        }

        private void imageBox_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            imageBox.Height = imageBox.ActualHeight * 1.7;
            imageBox.Width = imageBox.ActualWidth * 1.7;
        }
    }
}
