﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace CocktailBar.Converters
{
    public class ImageConverter
    {
        // TODO: vul deze class aan: De naam van de image is de
        // naam van de cocktail zonder de spatie(s), met ".jpg" als extensie.
        private string imagePath;

        public string ImagePath { get => imagePath; set => imagePath = createSource(value); }

        private string createSource(string name)
        {
            string imagePat = "";
            imagePat = name.Replace(" ", "");
            imagePat += ".jpg";
            return ".\\Images\\"+imagePat;
        }


    }
}
