﻿using System.Windows.Controls;

namespace WPFNavigation
{
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }
    }
}
