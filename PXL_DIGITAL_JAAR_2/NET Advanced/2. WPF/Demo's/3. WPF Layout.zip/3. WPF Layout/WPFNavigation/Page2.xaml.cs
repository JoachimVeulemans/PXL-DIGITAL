﻿using System.Windows.Controls;

namespace WPFNavigation
{
    public partial class Page2 : Page
    {
        public Page2()
        {
            InitializeComponent();
        }
    }
}
