﻿using System.Windows;

namespace PopupDemo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ShowPopupButtonClicked(object sender, RoutedEventArgs e)
        {
            if (!MyPopup.IsOpen)
            {
                MyPopup.IsOpen = true;
            }
        }

        private void ClosePopupClicked(object sender, RoutedEventArgs e)
        {
            if (MyPopup.IsOpen)
            {
                MyPopup.IsOpen = false;
            }
        }
    }
}
