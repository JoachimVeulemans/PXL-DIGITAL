﻿using System.Diagnostics;
using System.Windows;

namespace WPFContentModel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OuterButtonClick(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("The OUTER button was clicked");
        }

        private void InnerButtonClick(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("The INNER button was clicked");
        }

        private void MenuButtonClick(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("The MENU button was clicked");
        }
    }
}
