﻿using System.Windows;
using System.Windows.Media;

namespace ExampleWithStyles
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void HelloButtonClick(object sender, RoutedEventArgs e)
        {
            helloLabel.Content = "Hello WPF!";
            myGrid.Background = Brushes.Black;
        }

        private void CancelButtonClick(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
