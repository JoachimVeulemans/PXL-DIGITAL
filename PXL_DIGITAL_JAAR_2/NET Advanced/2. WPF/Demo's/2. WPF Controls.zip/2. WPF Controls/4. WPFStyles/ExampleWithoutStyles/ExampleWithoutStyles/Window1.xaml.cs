﻿using System.Windows;

namespace ExampleWithoutStyles
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void btnHello_Click(object sender, RoutedEventArgs e)
        {
            lblHello.Content = "Hello WPF!";
        }
    }
}
