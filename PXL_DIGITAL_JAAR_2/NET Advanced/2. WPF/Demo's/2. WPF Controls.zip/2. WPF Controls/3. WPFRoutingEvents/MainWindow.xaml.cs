﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace WPFRoutingEvents
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // MouseEnter: Direct Event
            this.MouseEnter += MouseEnterHandler;
            myBorder.MouseEnter += MouseEnterHandler;
            myPanel.MouseEnter += MouseEnterHandler;
            myEllipse.MouseEnter += MouseEnterHandler;
            myRectangle.MouseEnter += MouseEnterHandler;

            // MouseDown: Bubbling Event
            this.MouseDown += MouseDownHandler;
            myBorder.MouseDown += MouseDownHandler;
            myPanel.MouseDown += MouseDownHandler;
            myEllipse.MouseDown += MouseDownHandler;
            myRectangle.MouseDown += MouseDownHandler;

            // PreviewMouseDown: Tunneling Event
            this.PreviewMouseDown += PreviewMouseDownHandler;
            myBorder.PreviewMouseDown += PreviewMouseDownHandler;
            myPanel.PreviewMouseDown += PreviewMouseDownHandler;
            myEllipse.PreviewMouseDown += PreviewMouseDownHandler;
            myRectangle.PreviewMouseDown += PreviewMouseDownHandler;


            // Add five buttons to the panel
            for (int i = 0; i < 5; ++i)
            {
                Button button = new Button
                {
                    Content = "Button" + (i+1)
                };
                myPanel.Children.Add(button);
                //button.Click += PanelButtonClick;
            }

            //Alternative for setting the event handler in XAML:
            //myPanel.AddHandler(ButtonBase.ClickEvent, new RoutedEventHandler(PanelButtonClick));
        }


        void PanelButtonClick(object sender, RoutedEventArgs e)
        {
            //  Button clickedButton = (Button)sender;
            Button clickedButton = (Button)e.Source;
            clickedButton.Background = Brushes.Green;
        }


        public void MouseEnterHandler(object sender, MouseEventArgs e)
        {
            Debug.WriteLine("MouseEnter: " + sender);
        }

        public void MouseDownHandler(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("MouseDown: " + sender);
            e.Handled = true;
        }

        public void PreviewMouseDownHandler(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("PreviewMouseDown: " + sender);
        }
    }
}
